# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-10-04 02:32:37', '2014-10-04 02:32:37', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_communications`
#

DROP TABLE IF EXISTS `wp_m_communications`;


#
# Table structure of table `wp_m_communications`
#

CREATE TABLE `wp_m_communications` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `periodunit` int(11) DEFAULT NULL,
  `periodtype` varchar(5) DEFAULT NULL,
  `periodprepost` varchar(5) DEFAULT NULL,
  `lastupdated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` int(11) DEFAULT '0',
  `periodstamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_communications (0 records)
#

#
# End of data contents of table wp_m_communications
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_coupons`
#

DROP TABLE IF EXISTS `wp_m_coupons`;


#
# Table structure of table `wp_m_coupons`
#

CREATE TABLE `wp_m_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) DEFAULT '0',
  `couponcode` varchar(250) DEFAULT NULL,
  `discount` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(5) DEFAULT NULL,
  `discount_currency` varchar(5) DEFAULT NULL,
  `coupon_startdate` datetime DEFAULT NULL,
  `coupon_enddate` datetime DEFAULT NULL,
  `coupon_sub_id` bigint(20) DEFAULT '0',
  `coupon_uses` int(11) DEFAULT '0',
  `coupon_used` int(11) DEFAULT '0',
  `coupon_apply_to` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `couponcode` (`couponcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_coupons (0 records)
#

#
# End of data contents of table wp_m_coupons
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_levelmeta`
#

DROP TABLE IF EXISTS `wp_m_levelmeta`;


#
# Table structure of table `wp_m_levelmeta`
#

CREATE TABLE `wp_m_levelmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level_id` (`level_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_levelmeta (0 records)
#

#
# End of data contents of table wp_m_levelmeta
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_member_payments`
#

DROP TABLE IF EXISTS `wp_m_member_payments`;


#
# Table structure of table `wp_m_member_payments`
#

CREATE TABLE `wp_m_member_payments` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) DEFAULT NULL,
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_order` int(11) DEFAULT NULL,
  `paymentmade` datetime DEFAULT NULL,
  `paymentexpires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_member_payments (0 records)
#

#
# End of data contents of table wp_m_member_payments
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_membership_levels`
#

DROP TABLE IF EXISTS `wp_m_membership_levels`;


#
# Table structure of table `wp_m_membership_levels`
#

CREATE TABLE `wp_m_membership_levels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_title` varchar(250) DEFAULT NULL,
  `level_slug` varchar(250) DEFAULT NULL,
  `level_active` int(11) DEFAULT '0',
  `level_count` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_membership_levels (0 records)
#

#
# End of data contents of table wp_m_membership_levels
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_membership_news`
#

DROP TABLE IF EXISTS `wp_m_membership_news`;


#
# Table structure of table `wp_m_membership_news`
#

CREATE TABLE `wp_m_membership_news` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `newsitem` text,
  `newsdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_membership_news (0 records)
#

#
# End of data contents of table wp_m_membership_news
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_membership_relationships`
#

DROP TABLE IF EXISTS `wp_m_membership_relationships`;


#
# Table structure of table `wp_m_membership_relationships`
#

CREATE TABLE `wp_m_membership_relationships` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT '0',
  `sub_id` bigint(20) DEFAULT '0',
  `level_id` bigint(20) DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `order_instance` bigint(20) DEFAULT '0',
  `usinggateway` varchar(50) DEFAULT 'admin',
  PRIMARY KEY (`rel_id`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `usinggateway` (`usinggateway`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_membership_relationships (0 records)
#

#
# End of data contents of table wp_m_membership_relationships
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_membership_rules`
#

DROP TABLE IF EXISTS `wp_m_membership_rules`;


#
# Table structure of table `wp_m_membership_rules`
#

CREATE TABLE `wp_m_membership_rules` (
  `level_id` bigint(20) NOT NULL DEFAULT '0',
  `rule_ive` varchar(20) NOT NULL DEFAULT '',
  `rule_area` varchar(20) NOT NULL DEFAULT '',
  `rule_value` text,
  `rule_order` int(11) DEFAULT '0',
  PRIMARY KEY (`level_id`,`rule_ive`,`rule_area`),
  KEY `rule_area` (`rule_area`),
  KEY `rule_ive` (`rule_ive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_membership_rules (0 records)
#

#
# End of data contents of table wp_m_membership_rules
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_ping_history`
#

DROP TABLE IF EXISTS `wp_m_ping_history`;


#
# Table structure of table `wp_m_ping_history`
#

CREATE TABLE `wp_m_ping_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ping_id` bigint(20) DEFAULT NULL,
  `ping_sent` timestamp NULL DEFAULT NULL,
  `ping_info` text,
  `ping_return` text,
  PRIMARY KEY (`id`),
  KEY `ping_id` (`ping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_ping_history (0 records)
#

#
# End of data contents of table wp_m_ping_history
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_pings`
#

DROP TABLE IF EXISTS `wp_m_pings`;


#
# Table structure of table `wp_m_pings`
#

CREATE TABLE `wp_m_pings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pingname` varchar(250) DEFAULT NULL,
  `pingurl` varchar(250) DEFAULT NULL,
  `pinginfo` text,
  `pingtype` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_pings (0 records)
#

#
# End of data contents of table wp_m_pings
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_subscription_transaction`
#

DROP TABLE IF EXISTS `wp_m_subscription_transaction`;


#
# Table structure of table `wp_m_subscription_transaction`
#

CREATE TABLE `wp_m_subscription_transaction` (
  `transaction_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_subscription_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_user_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_sub_ID` bigint(20) DEFAULT '0',
  `transaction_paypal_ID` varchar(30) DEFAULT NULL,
  `transaction_payment_type` varchar(20) DEFAULT NULL,
  `transaction_stamp` bigint(35) NOT NULL DEFAULT '0',
  `transaction_total_amount` bigint(20) DEFAULT NULL,
  `transaction_currency` varchar(35) DEFAULT NULL,
  `transaction_status` varchar(35) DEFAULT NULL,
  `transaction_duedate` date DEFAULT NULL,
  `transaction_gateway` varchar(50) DEFAULT NULL,
  `transaction_note` text,
  `transaction_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`transaction_ID`),
  KEY `transaction_gateway` (`transaction_gateway`),
  KEY `transaction_subscription_ID` (`transaction_subscription_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_subscription_transaction (0 records)
#

#
# End of data contents of table wp_m_subscription_transaction
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_subscriptionmeta`
#

DROP TABLE IF EXISTS `wp_m_subscriptionmeta`;


#
# Table structure of table `wp_m_subscriptionmeta`
#

CREATE TABLE `wp_m_subscriptionmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_id` (`sub_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_subscriptionmeta (0 records)
#

#
# End of data contents of table wp_m_subscriptionmeta
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_subscriptions`
#

DROP TABLE IF EXISTS `wp_m_subscriptions`;


#
# Table structure of table `wp_m_subscriptions`
#

CREATE TABLE `wp_m_subscriptions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(200) DEFAULT NULL,
  `sub_active` int(11) DEFAULT '0',
  `sub_public` int(11) DEFAULT '0',
  `sub_count` bigint(20) DEFAULT '0',
  `sub_description` text,
  `sub_pricetext` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_subscriptions (0 records)
#

#
# End of data contents of table wp_m_subscriptions
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_subscriptions_levels`
#

DROP TABLE IF EXISTS `wp_m_subscriptions_levels`;


#
# Table structure of table `wp_m_subscriptions_levels`
#

CREATE TABLE `wp_m_subscriptions_levels` (
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_period` int(11) DEFAULT NULL,
  `sub_type` varchar(20) DEFAULT NULL,
  `level_price` decimal(11,2) DEFAULT '0.00',
  `level_currency` varchar(5) DEFAULT NULL,
  `level_order` bigint(20) DEFAULT '0',
  `level_period_unit` varchar(1) DEFAULT 'd',
  KEY `sub_id` (`sub_id`),
  KEY `level_id` (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_subscriptions_levels (0 records)
#

#
# End of data contents of table wp_m_subscriptions_levels
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------


#
# Delete any existing table `wp_m_urlgroups`
#

DROP TABLE IF EXISTS `wp_m_urlgroups`;


#
# Table structure of table `wp_m_urlgroups`
#

CREATE TABLE `wp_m_urlgroups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(250) DEFAULT NULL,
  `groupurls` text,
  `isregexp` int(11) DEFAULT '0',
  `stripquerystring` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_m_urlgroups (0 records)
#

#
# End of data contents of table wp_m_urlgroups
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4813 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (216 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://bootstoshoes2014.azurewebsites.net', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'home', 'http://bootstoshoes2014.azurewebsites.net', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'blogname', 'Boots To Shoes', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'blogdescription', 'Helping 21st Century Veterans Capture 21st Century Jobs', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'admin_email', 'durkinch@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (111, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (121, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (131, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (151, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (161, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (171, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (181, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (191, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (201, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (211, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (221, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (231, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (241, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (251, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (261, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (271, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (281, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (291, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (301, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (311, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (321, 'active_plugins', 'a:7:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:35:"add-from-server/add-from-server.php";i:2;s:19:"akismet/akismet.php";i:3;s:51:"configure-login-timeout/configure-login-timeout.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:37:"user-role-editor/user-role-editor.php";i:6;s:41:"wordpress-importer/wordpress-importer.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (331, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (341, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (351, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (361, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (371, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (381, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (391, 'recently_edited', 'a:5:{i:0;s:66:"D:\\home\\site\\wwwroot/wp-content/themes/klasik/page-list-events.php";i:2;s:55:"D:\\home\\site\\wwwroot/wp-content/themes/klasik/style.css";i:3;s:71:"D:\\home\\site\\wwwroot/wp-content/themes/klasik/page-list-custom-type.php";i:4;s:54:"D:\\home\\site\\wwwroot/wp-content/themes/klasik/page.php";i:5;s:56:"D:\\home\\site\\wwwroot/wp-content/themes/klasik/header.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (401, 'template', 'klasik', 'yes') ; 
INSERT INTO `wp_options` VALUES (411, 'stylesheet', 'klasik', 'yes') ; 
INSERT INTO `wp_options` VALUES (421, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (431, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (441, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (451, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (461, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (471, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (481, 'db_version', '29630', 'yes') ; 
INSERT INTO `wp_options` VALUES (491, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (501, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (511, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (521, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (531, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (541, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (551, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (561, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (571, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (581, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (591, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (601, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (611, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (621, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (631, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (641, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (651, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (661, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (671, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (681, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (691, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (701, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (711, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (721, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (731, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (741, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (751, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (761, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (771, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (781, 'widget_categories', 'a:2:{s:12:"_multiwidget";i:1;i:1;a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (791, 'widget_text', 'a:4:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:11:"Newsletters";s:4:"text";s:78:"<ul>
<li>September 2014</li>
<li>August 2014</li>
<li>July 2014</li>
</ul>";s:6:"filter";b:0;}i:3;a:3:{s:5:"title";s:12:"Get Involved";s:4:"text";s:206:"<p><a href="donate">Donate Now</a></p>
<p><a href="sign-up-for-a-mentor">Sign Up For a Mentor</a></p>
<p><a href="be-a-mentor">Volunteer As A Mentor</a></p>
<p><a href="other-volunteers">Other Volunteers";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (801, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (811, 'uninstall_plugins', 'a:1:{s:31:"advanced-access-manager/aam.php";a:2:{i:0;s:3:"aam";i:1;s:9:"uninstall";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (821, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (831, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (841, 'page_on_front', '5221', 'yes') ; 
INSERT INTO `wp_options` VALUES (851, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (861, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (871, 'initial_db_version', '29630', 'yes') ; 
INSERT INTO `wp_options` VALUES (881, 'wp_user_roles', 'a:6:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";i:1;s:17:"manage_categories";i:1;s:12:"manage_links";i:1;s:12:"upload_files";i:1;s:15:"unfiltered_html";i:1;s:10:"edit_posts";i:1;s:17:"edit_others_posts";i:1;s:20:"edit_published_posts";i:1;s:13:"publish_posts";i:1;s:10:"edit_pages";i:1;s:4:"read";i:1;s:7:"level_7";i:1;s:7:"level_6";i:1;s:7:"level_5";i:1;s:7:"level_4";i:1;s:7:"level_3";i:1;s:7:"level_2";i:1;s:7:"level_1";i:1;s:7:"level_0";i:1;s:17:"edit_others_pages";i:1;s:20:"edit_published_pages";i:1;s:13:"publish_pages";i:1;s:12:"delete_pages";i:1;s:19:"delete_others_pages";i:1;s:22:"delete_published_pages";i:1;s:12:"delete_posts";i:1;s:19:"delete_others_posts";i:1;s:22:"delete_published_posts";i:1;s:20:"delete_private_posts";i:1;s:18:"edit_private_posts";i:1;s:18:"read_private_posts";i:1;s:20:"delete_private_pages";i:1;s:18:"edit_private_pages";i:1;s:18:"read_private_pages";i:1;}}s:20:"privatecontentviewer";a:2:{s:4:"name";s:22:"Private Content Viewer";s:12:"capabilities";a:4:{s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (891, 'widget_search', 'a:2:{s:12:"_multiwidget";i:1;i:1;a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (901, 'widget_recent-posts', 'a:2:{s:12:"_multiwidget";i:1;i:1;a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (911, 'widget_recent-comments', 'a:2:{s:12:"_multiwidget";i:1;i:1;a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (921, 'widget_archives', 'a:2:{s:12:"_multiwidget";i:1;i:1;a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (931, 'widget_meta', 'a:2:{s:12:"_multiwidget";i:1;i:1;a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (941, 'sidebars_widgets', 'a:11:{s:19:"wp_inactive_widgets";a:0:{}s:12:"post-sidebar";a:2:{i:0;s:6:"text-3";i:1;s:24:"klasik-sponsors-widget-2";}s:10:"contenttop";a:0:{}s:13:"contentbottom";a:0:{}s:7:"maintop";a:0:{}s:10:"mainbottom";a:0:{}s:12:"homefeatures";a:3:{i:0;s:22:"klasik-action-widget-2";i:1;s:22:"klasik-action-widget-3";i:2;s:22:"klasik-action-widget-4";}s:12:"homeshowcase";a:3:{i:0;s:28:"klasik-testimonials-widget-2";i:1;s:22:"klasik-events-widget-3";i:2;s:6:"text-2";}s:13:"homehighlight";a:0:{}s:6:"footer";a:1:{i:0;s:10:"nav_menu-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (951, 'cron', 'a:12:{i:1412480063;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1412481182;a:1:{s:40:"membership_perform_cron_processes_hourly";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1412481600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:12:"hmbkp_hourly";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:3600;}}}i:1412483937;a:1:{s:26:"importer_scheduled_cleanup";a:1:{s:32:"69646310a85a6ea27f82a78a395ebe66";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:4991;}}}}i:1412492640;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1412519580;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1412564075;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1412884370;a:1:{s:19:"publish_future_post";a:1:{s:32:"a231f6f463211d0b6538db31fd46baa6";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:7061;}}}}i:1413082800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1413316430;a:1:{s:19:"publish_future_post";a:1:{s:32:"e8d527f64f6f719e5b35640ac77cb699";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:7081;}}}}i:1413316485;a:1:{s:19:"publish_future_post";a:1:{s:32:"e2937af6fc3edd334d83448399033a71";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:7111;}}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (971, 'auth_salt', 'HhrI=in4Ve<f juTy,3Am$0YI_RjDPj@yu-DJ7sgv@?}`}h4-`m?ne])ha;CF7Qq', 'yes') ; 
INSERT INTO `wp_options` VALUES (981, '_transient_random_seed', '68cd62164ccf6ed4ee2d3fa30301dec8', 'yes') ; 
INSERT INTO `wp_options` VALUES (991, 'logged_in_key', '?OcxLcpNWAQx2KjH`EGJcNdP]JSGn_o7%#hk4{W^)TwKnzC%Jvspdv}Tnx}gxY@+', 'yes') ; 
INSERT INTO `wp_options` VALUES (1011, 'logged_in_salt', 'lHvi=@3o^OMRliEi#NGK>>G6KAh<rN/-=n8tsu6;nvyvlUczKFA%2=3r6[wR?LI/', 'yes') ; 
INSERT INTO `wp_options` VALUES (1061, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.0.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.0.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.0-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.0-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.0";s:7:"version";s:3:"4.0";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1412477578;s:15:"version_checked";s:3:"4.0";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1112, '_site_transient_timeout_browser_37a8d5eb041a12687e2a2a45a54eb138', '1412994802', 'yes') ; 
INSERT INTO `wp_options` VALUES (1122, '_site_transient_browser_37a8d5eb041a12687e2a2a45a54eb138', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"37.0.2062.124";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1131, 'nonce_key', 'b6Y`sVB4WtVgA$?GC?#aFBV#7u:ha]l+gXRrf.d=9l;cHi:Mo,RL%Bs@o:=V[Ce5', 'yes') ; 
INSERT INTO `wp_options` VALUES (1141, 'nonce_salt', '12AG!Oi45]):N?PX:$m?dnw|7]h]UU^KblB#kMA~2E.]nE/z669I#:s7-fscFHBH', 'yes') ; 
INSERT INTO `wp_options` VALUES (1151, '_transient_timeout_plugin_slugs', '1412552081', 'no') ; 
INSERT INTO `wp_options` VALUES (1161, '_transient_plugin_slugs', 'a:12:{i:0;s:35:"add-from-server/add-from-server.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:19:"akismet/akismet.php";i:3;s:35:"backupwordpress/backupwordpress.php";i:4;s:51:"configure-login-timeout/configure-login-timeout.php";i:5;s:59:"content-views-query-and-display-post-page/content-views.php";i:6;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:7;s:27:"quick-setup/quick-setup.php";i:8;s:45:"limit-login-attempts/limit-login-attempts.php";i:9;s:31:"page-links-to/page-links-to.php";i:10;s:37:"user-role-editor/user-role-editor.php";i:11;s:41:"wordpress-importer/wordpress-importer.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1171, 'recently_activated', 'a:6:{s:59:"content-views-query-and-display-post-page/content-views.php";i:1412455048;s:17:"backup/backup.php";i:1412450006;s:35:"redux-framework/redux-framework.php";i:1412442085;s:31:"advanced-access-manager/aam.php";i:1412441915;s:39:"options-framework/options-framework.php";i:1412441295;s:25:"membership/membership.php";i:1412393811;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1211, 'can_compress_scripts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (1221, '_site_transient_timeout_browser_36aad282fc408e8d008cae19346cbbd8', '1412995195', 'yes') ; 
INSERT INTO `wp_options` VALUES (1231, '_site_transient_browser_36aad282fc408e8d008cae19346cbbd8', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:17:"Internet Explorer";s:7:"version";s:4:"10.0";s:10:"update_url";s:51:"http://www.microsoft.com/windows/internet-explorer/";s:7:"img_src";s:45:"http://s.wordpress.org/images/browsers/ie.png";s:11:"img_src_ssl";s:44:"https://wordpress.org/images/browsers/ie.png";s:15:"current_version";s:1:"9";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1421, '_site_transient_timeout_browser_3a0daf6e042b28d4d8a48c4f87720f52', '1412995499', 'yes') ; 
INSERT INTO `wp_options` VALUES (1431, '_site_transient_browser_3a0daf6e042b28d4d8a48c4f87720f52', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"37.0.2062.124";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1441, '_site_transient_timeout_popular_importers_en_US', '1412563669', 'yes') ; 
INSERT INTO `wp_options` VALUES (1451, '_site_transient_popular_importers_en_US', 'a:2:{s:9:"importers";a:8:{s:7:"blogger";a:4:{s:4:"name";s:7:"Blogger";s:11:"description";s:86:"Install the Blogger importer to import posts, comments, and users from a Blogger blog.";s:11:"plugin-slug";s:16:"blogger-importer";s:11:"importer-id";s:7:"blogger";}s:9:"wpcat2tag";a:4:{s:4:"name";s:29:"Categories and Tags Converter";s:11:"description";s:109:"Install the category/tag converter to convert existing categories to tags or tags to categories, selectively.";s:11:"plugin-slug";s:18:"wpcat2tag-importer";s:11:"importer-id";s:9:"wpcat2tag";}s:11:"livejournal";a:4:{s:4:"name";s:11:"LiveJournal";s:11:"description";s:82:"Install the LiveJournal importer to import posts from LiveJournal using their API.";s:11:"plugin-slug";s:20:"livejournal-importer";s:11:"importer-id";s:11:"livejournal";}s:11:"movabletype";a:4:{s:4:"name";s:24:"Movable Type and TypePad";s:11:"description";s:99:"Install the Movable Type importer to import posts and comments from a Movable Type or TypePad blog.";s:11:"plugin-slug";s:20:"movabletype-importer";s:11:"importer-id";s:2:"mt";}s:4:"opml";a:4:{s:4:"name";s:8:"Blogroll";s:11:"description";s:61:"Install the blogroll importer to import links in OPML format.";s:11:"plugin-slug";s:13:"opml-importer";s:11:"importer-id";s:4:"opml";}s:3:"rss";a:4:{s:4:"name";s:3:"RSS";s:11:"description";s:58:"Install the RSS importer to import posts from an RSS feed.";s:11:"plugin-slug";s:12:"rss-importer";s:11:"importer-id";s:3:"rss";}s:6:"tumblr";a:4:{s:4:"name";s:6:"Tumblr";s:11:"description";s:84:"Install the Tumblr importer to import posts &amp; media from Tumblr using their API.";s:11:"plugin-slug";s:15:"tumblr-importer";s:11:"importer-id";s:6:"tumblr";}s:9:"wordpress";a:4:{s:4:"name";s:9:"WordPress";s:11:"description";s:130:"Install the WordPress importer to import posts, pages, comments, custom fields, categories, and tags from a WordPress export file.";s:11:"plugin-slug";s:18:"wordpress-importer";s:11:"importer-id";s:9:"wordpress";}}s:10:"translated";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1521, 'M_Installed', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (1531, 'membership_options', 'a:6:{s:17:"registration_page";i:31;s:12:"account_page";i:41;s:14:"nocontent_page";i:51;s:25:"membershipadminshortcodes";a:0:{}s:24:"membershipdownloadgroups";a:1:{i:0;s:7:"default";}s:10:"masked_url";s:9:"downloads";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1541, 'M_Newsstream_Installed', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1571, 'WPLANG', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1611, 'clt_normal_auth_timeout', '3600', 'yes') ; 
INSERT INTO `wp_options` VALUES (1631, 'clt_normal_num', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1651, 'clt_normal_unit', 'hours', 'yes') ; 
INSERT INTO `wp_options` VALUES (1671, 'clt_remember_me_auth_timeout', '1209600', 'yes') ; 
INSERT INTO `wp_options` VALUES (1691, 'clt_remember_me_num', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (1711, 'clt_remember_me_unit', 'weeks', 'yes') ; 
INSERT INTO `wp_options` VALUES (1771, '_site_transient_timeout_browser_14335ad3f53fe013c1f04c17949f169c', '1412997613', 'yes') ; 
INSERT INTO `wp_options` VALUES (1781, '_site_transient_browser_14335ad3f53fe013c1f04c17949f169c', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:17:"Internet Explorer";s:7:"version";s:2:"11";s:10:"update_url";s:51:"http://www.microsoft.com/windows/internet-explorer/";s:7:"img_src";s:45:"http://s.wordpress.org/images/browsers/ie.png";s:11:"img_src_ssl";s:44:"https://wordpress.org/images/browsers/ie.png";s:15:"current_version";s:1:"9";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1792, '_site_transient_timeout_browser_484aa690c75cc1d091aceb531dd59833', '1412998118', 'yes') ; 
INSERT INTO `wp_options` VALUES (1802, '_site_transient_browser_484aa690c75cc1d091aceb531dd59833', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"37.0.2062.124";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1891, 'membership_active', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (1991, 'frmsvr_last_folder', 'd:/home/site/wwwroot/wp-content/uploads/2014/07', 'yes') ; 
INSERT INTO `wp_options` VALUES (2091, 'category_children', 'a:1:{i:1;a:1:{i:0;i:21;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2121, '_transient_twentyfourteen_category_count', '3', 'yes') ; 
INSERT INTO `wp_options` VALUES (2181, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1412398448;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2191, 'current_theme', 'Klasik', 'yes') ; 
INSERT INTO `wp_options` VALUES (2201, 'theme_mods_organic_nonprofit', 'a:6:{i:0;b:0;s:12:"header_image";s:103:"http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/04/cropped-BTSlogo-DkBlue21stCen2.gif";s:17:"header_image_data";a:5:{s:13:"attachment_id";i:5071;s:3:"url";s:103:"http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/04/cropped-BTSlogo-DkBlue21stCen2.gif";s:13:"thumbnail_url";s:103:"http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/04/cropped-BTSlogo-DkBlue21stCen2.gif";s:5:"width";i:958;s:6:"height";i:106;}s:16:"background_color";s:6:"95abc6";s:18:"nav_menu_locations";a:1:{s:11:"header-menu";i:31;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1412440679;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:13:"right-sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:10:"footer-one";a:0:{}s:10:"footer-two";a:0:{}s:12:"footer-three";N;s:11:"footer-four";N;s:11:"footer-five";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2211, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2221, 'woocommerce_thumbnail_image_width', '192', 'yes') ; 
INSERT INTO `wp_options` VALUES (2231, 'woocommerce_thumbnail_image_height', '192', 'yes') ; 
INSERT INTO `wp_options` VALUES (2241, 'woocommerce_single_image_width', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (2251, 'woocommerce_single_image_height', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (2261, 'woocommerce_catalog_image_width', '140', 'yes') ; 
INSERT INTO `wp_options` VALUES (2271, 'woocommerce_catalog_image_height', '140', 'yes') ; 
INSERT INTO `wp_options` VALUES (2291, 'optionsframework', 'a:2:{s:2:"id";s:6:"klasik";s:12:"knownoptions";a:1:{i:0;s:6:"klasik";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2311, 'aam_updated', '2.8.4', 'yes') ; 
INSERT INTO `wp_options` VALUES (2321, 'organicnonprofit', 'a:28:{s:23:"category_slideshow_home";s:2:"21";s:25:"postnumber_slideshow_home";s:2:"20";s:19:"transition_interval";s:4:"6000";s:16:"display_home_mid";s:1:"1";s:13:"mid_page_left";s:2:"40";s:12:"mid_page_mid";s:2:"32";s:14:"mid_page_right";s:3:"130";s:16:"display_home_bot";s:1:"1";s:11:"bottom_page";s:3:"349";s:15:"category_tabber";s:2:"11";s:17:"postnumber_tabber";s:1:"1";s:14:"display_search";b:0;s:20:"display_feature_post";b:0;s:20:"display_feature_blog";b:0;s:22:"display_slideshow_info";s:1:"1";s:18:"background_stretch";b:0;s:17:"enable_responsive";s:1:"1";s:13:"category_blog";s:1:"0";s:15:"postnumber_blog";s:1:"5";s:19:"display_social_blog";b:0;s:19:"display_social_post";b:0;s:12:"twitter_user";s:13:"organicthemes";s:18:"enable_presstrends";s:1:"1";s:10:"link_color";s:7:"#a53501";s:16:"link_hover_color";s:7:"#4a33e0";s:18:"heading_link_color";s:7:"#a02703";s:24:"heading_link_hover_color";s:7:"#555c8c";s:15:"highlight_color";s:7:"#913101";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2331, '_transient_timeout_presstrends_theme_cache_data', '1412485221', 'no') ; 
INSERT INTO `wp_options` VALUES (2341, '_transient_presstrends_theme_cache_data', 'a:15:{s:3:"url";s:34:"bootstoshoes2014.azurewebsites.net";s:5:"posts";s:1:"9";s:5:"pages";s:2:"22";s:8:"comments";i:1;s:8:"approved";s:1:"1";s:4:"spam";i:0;s:9:"pingbacks";s:1:"0";s:15:"post_conversion";s:2:"11";s:13:"theme_version";s:5:"4.0.6";s:10:"theme_name";s:17:"Organic+NonProfit";s:9:"site_name";s:12:"BootsToShoes";s:7:"plugins";i:7;s:6:"plugin";s:235:"%26Add+From+Server%26Advanced+Access+Manager%26Akismet%26Backup%26BackUpWordPress%26Configure+Login+Timeout%26Custom+Post+Type+UI%26Go+Daddy+Quick+Setup%26Limit+Login+Attempts%26Options+Framework%26Page+Links+To%26WordPress+Importer%26";s:9:"wpversion";s:3:"4.0";s:11:"api_version";s:3:"2.4";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2371, 'aam_menu_role_editor', 'a:14:{s:9:"index.php";s:1:"0";s:8:"edit.php";s:1:"0";s:12:"post-new.php";s:1:"0";s:31:"edit-tags.php?taxonomy=category";s:1:"0";s:31:"edit-tags.php?taxonomy=post_tag";s:1:"0";s:10:"upload.php";s:1:"0";s:13:"media-new.php";s:1:"0";s:15:"add-from-server";s:1:"0";s:23:"edit.php?post_type=page";s:1:"0";s:27:"post-new.php?post_type=page";s:1:"0";s:17:"edit-comments.php";s:1:"0";s:9:"users.php";s:1:"0";s:11:"profile.php";s:1:"0";s:9:"tools.php";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2381, 'aam_role_editor_modified_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2382, 'aam_security_login_cache', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2401, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2541, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2551, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:26:"https://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 18 Sep 2014 16:20:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/?v=4.1-alpha-20141002";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 4.0 “Benny”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/09/benny/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/09/benny/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Sep 2014 17:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3296";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:370:"Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23566:"<p>Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader <a href="http://en.wikipedia.org/wiki/Benny_Goodman">Benny Goodman</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience we think you&#8217;ll enjoy.</p>
<div id="v-bUdzKMro-1" class="video-player"><embed id="v-bUdzKMro-1-video" src="https://v0.wordpress.com/player.swf?v=1.03&amp;guid=bUdzKMro&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 4.0 &quot;Benny&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<hr />
<h2 style="text-align: center">Manage your media with style</h2>
<p><img class="alignnone size-full wp-image-3316" src="https://wordpress.org/news/files/2014/09/media.jpg" alt="Media Library" width="1000" height="586" />Explore your uploads in a beautiful, endless grid. A new details preview makes viewing and editing any amount of media in sequence a snap.</p>
<hr />
<h2 style="text-align: center">Working with embeds has never been easier</h2>
<div style="width: 632px; height: 445px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3296-1" width="632" height="445" autoplay="true" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/embed.mp4?_=1" /><source type="video/webm" src="//s.w.org/images/core/4.0/embed.webm?_=1" /><source type="video/ogg" src="//s.w.org/images/core/4.0/embed.ogv?_=1" /><a href="//s.w.org/images/core/4.0/embed.mp4">//s.w.org/images/core/4.0/embed.mp4</a></video></div>
<p>Paste in a YouTube URL on a new line, and watch it magically become an embedded video. Now try it with a tweet. Oh yeah — embedding has become a visual experience. The editor shows a true preview of your embedded content, saving you time and giving you confidence.</p>
<p>We’ve expanded the services supported by default, too — you can embed videos from CollegeHumor, playlists from YouTube, and talks from TED. <a href="https://codex.wordpress.org/Embeds">Check out all of the embeds</a> that WordPress supports.</p>
<hr />
<h2 style="text-align: center">Focus on your content</h2>
<div style="width: 632px; height: 356px; " class="wp-video"><video class="wp-video-shortcode" id="video-3296-2" width="632" height="356" autoplay="true" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/focus.mp4?_=2" /><source type="video/webm" src="//s.w.org/images/core/4.0/focus.webm?_=2" /><source type="video/ogg" src="//s.w.org/images/core/4.0/focus.ogv?_=2" /><a href="//s.w.org/images/core/4.0/focus.mp4">//s.w.org/images/core/4.0/focus.mp4</a></video></div>
<p>Writing and editing is smoother and more immersive with an editor that expands to fit your content as you write, and keeps the formatting tools available at all times.</p>
<hr />
<h2 style="text-align: center">Finding the right plugin</h2>
<p><img class="aligncenter size-large wp-image-3309" src="https://wordpress.org/news/files/2014/09/add-plugin1-1024x600.png" alt="Add plugins" width="692" height="405" /></p>
<p>There are more than 30,000 free and open source plugins in the WordPress plugin directory. WordPress 4.0 makes it easier to find the right one for your needs, with new metrics, improved search, and a more visual browsing experience.</p>
<hr />
<h2 style="text-align: center">The Ensemble</h2>
<p>This release was led by <a href="http://helenhousandi.com">Helen Hou-Sandí</a>, with the help of these fine individuals. There are 275 contributors with props in this release, a new high. Pull up some Benny Goodman on your music service of choice, as a bandleader or in one of his turns as a classical clarinetist, and check out some of their profiles:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/alexanderrohmann">Alexander Rohmann</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/amit">Amit Gupta</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andrezrv">Andres Villarreal</a>, <a href="https://profiles.wordpress.org/zamfeer">Andrew Mowe</a>, <a href="https://profiles.wordpress.org/sumobi">Andrew Munro (sumobi)</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/arnee">arnee</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/filosofo">Austin Matzko</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/kau-boy">Bernhard Kau</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="https://profiles.wordpress.org/bramd">bramd</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/camdensegal">Camden Segal</a>, <a href="https://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="https://profiles.wordpress.org/mackensen">Charles Fulton</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisl27">chrisl27</a>, <a href="https://profiles.wordpress.org/caxelsson">Christian Axelsson</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/boda1982">Christopher Spires</a>, <a href="https://profiles.wordpress.org/clifgriffin">Clifton Griffin</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/ghost1227">Dan Griffiths</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/danielhuesken">Daniel Husken</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/dkotter">Darin Kotter</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/dllh">Daryl L. L. Houston (dllh)</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/dnaber-de">David Naber</a>, <a href="https://profiles.wordpress.org/davidthemachine">DavidTheMachine</a>, <a href="https://profiles.wordpress.org/debaat">DeBAAT</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/donncha">Donncha O Caoimh</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustyn">Dustyn Doyle</a>, <a href="https://profiles.wordpress.org/eddiemoya">Eddie Moya</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/edwin-at-studiojoyocom">Edwin Siebel</a>, <a href="https://profiles.wordpress.org/ehg">ehg</a>, <a href="https://profiles.wordpress.org/tmeister">Enrique Chavez</a>, <a href="https://profiles.wordpress.org/erayalakese">erayalakese</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/eherman24">Evan Herman</a>, <a href="https://profiles.wordpress.org/fab1en">Fab1en</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garhdez">garhdez</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/garza">garza</a>, <a href="https://profiles.wordpress.org/gauravmittal1995">gauravmittal1995</a>, <a href="https://profiles.wordpress.org/gavra">Gavrisimo</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/bordoni">Gustavo Bordoni</a>, <a href="https://profiles.wordpress.org/harrym">harrym</a>, <a href="https://profiles.wordpress.org/hebbet">hebbet</a>, <a href="https://profiles.wordpress.org/hinnerk">Hinnerk Altenburg</a>, <a href="https://profiles.wordpress.org/hlashbrooke">Hugh Lashbrooke</a>, <a href="https://profiles.wordpress.org/iljoja">iljoja</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/issuu">issuu</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/jacobdubail">Jacob Dubail</a>, <a href="https://profiles.wordpress.org/janhenkg">JanHenkG</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jwenerd">Jared Wenerd</a>, <a href="https://profiles.wordpress.org/jaza613">Jaza613</a>, <a href="https://profiles.wordpress.org/jeffstieler">Jeff Stieler</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="https://profiles.wordpress.org/slimndap">Jeroen Schmit</a>, <a href="https://profiles.wordpress.org/jerrysarcastic">Jerry Bates (jerrysarcastic)</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/engelen">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jesper800">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jessepollak">Jesse Pollak</a>, <a href="https://profiles.wordpress.org/jgadbois">jgadbois</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnzanussi">John Zanussi</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jonnyauk">jonnyauk</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/softmodeling">Jordi Cabot</a>, <a href="https://profiles.wordpress.org/jjeaton">Josh Eaton</a>, <a href="https://profiles.wordpress.org/tai">JOTAKI Taisuke</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/greenshady">Justin Tadlock</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/ixkaito">Kaito</a>, <a href="https://profiles.wordpress.org/kapeels">kapeels</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevinlangleyjr">Kevin Langley</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/krogsgard">krogsgard</a>, <a href="https://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="https://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="https://profiles.wordpress.org/lritter">lritter</a>, <a href="https://profiles.wordpress.org/lukecarbis">Luke Carbis</a>, <a href="https://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/funkatronic">Manny Fleurmond</a>, <a href="https://profiles.wordpress.org/targz-1">Manuel Schmalstieg</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/sivel">Matt Martz</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheweppelsheimer">Matthew Eppelsheimer</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/meekyhwang">meekyhwang</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/midxcat">mi_cat</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michalzuber">michalzuber</a>, <a href="https://profiles.wordpress.org/mauteri">Mike Auteri</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikejolley">Mike Jolley</a>, <a href="https://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikeyarce">Mikey Arce</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="https://profiles.wordpress.org/mrmist">mrmist</a>, <a href="https://profiles.wordpress.org/m_uysl">Mustafa Uysal</a>, <a href="https://profiles.wordpress.org/muvimotv">MuViMoTV</a>, <a href="https://profiles.wordpress.org/nabil_kadimi">nabil_kadimi</a>, <a href="https://profiles.wordpress.org/namibia">Namibia</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nd987">nd987</a>, <a href="https://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="https://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/schoenwaldnils">Nils Schonwald</a>, <a href="https://profiles.wordpress.org/ninos-ego">Ninos</a>, <a href="https://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="https://profiles.wordpress.org/compute">Patrick Hesselberg</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="https://profiles.wordpress.org/paulschreiber">Paul Schreiber</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/philipjohn">Philip John</a>, <a href="https://profiles.wordpress.org/senlin">Piet</a>, <a href="https://profiles.wordpress.org/psoluch">Piotr Soluch</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/purzlbaum">purzlbaum</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/rclations">RC Lations</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/rob1n">rob1n</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="https://profiles.wordpress.org/harmr">RobertHarm</a>, <a href="https://profiles.wordpress.org/rohan013">Rohan Rawat</a>, <a href="https://profiles.wordpress.org/rhurling">Rouven Hurling</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/sammybeats">Sam Brodie</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sathishn">Sathish Nagarajan</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergejmueller">Sergej Muller</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shanebp">shanebp</a>, <a href="https://profiles.wordpress.org/sharonaustin">Sharon Austin</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/simonp303">simonp303</a>, <a href="https://profiles.wordpress.org/slobodanmanic">Slobodan Manic</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sphoid">sphoid</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stompweb">Steven Jones</a>, <a href="https://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="https://profiles.wordpress.org/5um17">Sumit Singh</a>, <a href="https://profiles.wordpress.org/t4k1s">t4k1s</a>, <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="https://profiles.wordpress.org/taylorde">Taylor Dewey</a>, <a href="https://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="https://profiles.wordpress.org/tillkruess">Till Kruss</a>, <a href="https://profiles.wordpress.org/codenameeli">Tim \'Eli\' Dalbey</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tjnowell">Tom J Nowell</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/torresga">torresga</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/treyhunner">treyhunner</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="https://profiles.wordpress.org/vlajos">vlajos</a>, <a href="https://profiles.wordpress.org/voldemortensen">voldemortensen</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/winterdev">winterDev</a>, <a href="https://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/katzwebdesign">Zack Katz</a>, <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>, and <a href="https://profiles.wordpress.org/zoerooney">Zoe Rooney</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video, and Helen with <a href="http://adriansandi.com">Adrián Sandí</a> for the music.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.1!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/09/benny/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.0 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Aug 2014 12:20:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3287";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:321:"The first release candidate for WordPress 4.0 is now available! In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the Beta 1 announcement post for more details on those features. We hope to ship WordPress 4.0 next week, but we need your help to get there. If you [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2134:"<p>The first release candidate for WordPress 4.0 is now available!</p>
<p>In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">Beta 1 announcement post</a> for more details on those features. We hope to ship WordPress 4.0 <em>next week</em>, but we need your help to get there. If you haven’t tested 4.0 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="https://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="https://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 4.0 RC1, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 4.0, visit the awesome About screen in your dashboard (<strong><img src="https://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar).</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 4.0 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.0 before next week. If you find compatibility problems, please be sure to post any issues to the support forums so we can figure those out before the final release. You also may want to <a href="https://make.wordpress.org/core/2014/08/21/introducing-plugin-icons-in-the-plugin-installer/">give your plugin an icon</a>, which we launched last week and will appear in the dashboard along with banners.</p>
<p><em>It is almost time</em><br />
<em> For the 4.0 release</em><br />
<em> And its awesomeness</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:06:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3280";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made more than 250 changes in the past month, including: Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes. Better handling of small screens in the media library modals. A separate bulk selection mode [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2003:"<p>The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?rev=29496&amp;stop_rev=29229&amp;limit=300">more than 250 changes</a> in the past month, including:</p>
<ul>
<li>Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes.</li>
<li>Better handling of small screens in the media library modals.</li>
<li>A separate bulk selection mode for the media library grid view.</li>
<li>Improvements to the installation language selector.</li>
<li>Visual tweaks to plugin details and customizer panels.</li>
</ul>
<p><strong>We need your help</strong>. We’re still aiming for a release this month, which means the next week will be critical for identifying and squashing bugs. If you’re just joining us, please see <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven’t tested WordPress 4.0 yet, now is the time — and be sure to update the “tested up to” version for your plugins so they’re listed as compatible with 4.0.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta4.zip">download the beta here</a> (zip).</p>
<p><em>We are working hard</em><br />
<em>To finish up 4.0<br />
</em><em>Will you help us too?</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.9.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/08/wordpress-3-9-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/08/wordpress-3-9-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Aug 2014 19:04:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3269";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:377:"WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately. This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by Nir Goldshlager of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2353:"<p>WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately.</p>
<p>This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by <a href="https://twitter.com/nirgoldshlager">Nir Goldshlager</a> of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress security team and David Rothstein of the <a href="https://www.drupal.org/SA-CORE-2014-004">Drupal security team</a>. This is the first time our two projects have coordinated joint security releases.</p>
<p>WordPress 3.9.2 also contains other security changes:</p>
<ul>
<li>Fixes a possible but unlikely code execution when processing widgets (WordPress is not affected by default), discovered by <a href="http://www.buayacorp.com/">Alex Concha</a> of the WordPress security team.</li>
<li>Prevents information disclosure via XML entity attacks in the external GetID3 library, reported by <a href="http://onsec.ru/en/">Ivan Novikov</a> of ONSec.</li>
<li>Adds protections against brute attacks against CSRF tokens, reported by <a href="http://systemoverlord.com/">David Tomaschik</a> of the Google Security Team.</li>
<li>Contains some additional security hardening, like preventing cross-site scripting that could be triggered only by administrators.</li>
</ul>
<p>We appreciated responsible disclosure of these issues directly to our security team. For more information, see the <a href="https://codex.wordpress.org/Version_3.9.2">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/3.9?stop_rev=29383&amp;rev=29411">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.9.2 within 12 hours. (If you are still on WordPress 3.8.3 or 3.7.3, you will also be updated to 3.8.4 or 3.7.4. We don&#8217;t support older versions, so please update to 3.9.2 for the latest and greatest.)</p>
<p>Already testing WordPress 4.0? The third beta is <a href="https://wordpress.org/wordpress-4.0-beta3.zip">now available</a> (zip) and it contains these security fixes.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/08/wordpress-3-9-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Jul 2014 21:15:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3261";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:374:"WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). For more of what’s new in version 4.0, check out [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1745:"<p>WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta2.zip">download the beta here</a> (zip).</p>
<p>For more of what’s new in version 4.0, <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Further refinements for the the plugin installation and media library experiences.</li>
<li>Updated TinyMCE, which now includes better indentation for lists and the restoration of the color picker.</li>
<li>Cookies are now tied to a session internally, so if you have trouble logging in, <a href="https://core.trac.wordpress.org/ticket/20276">#20276</a> may be the culprit.</li>
<li>Various bug fixes (there were <a href="https://core.trac.wordpress.org/log?rev=29228&amp;stop_rev=29060&amp;limit=200">nearly 170 changes</a> since last week).</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4031:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="https://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="https://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3106:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="https://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="https://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23206:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>

<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'https://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'https://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'https://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; height: 448px; " class="wp-video"><video class="wp-video-shortcode" id="video-3154-3" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=3" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/adelval">adelval</a>, <a href="https://profiles.wordpress.org/ajay">Ajay</a>, <a href="https://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="https://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="https://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/barry">Barry</a>, <a href="https://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="https://profiles.wordpress.org/bassgang">bassgang</a>, <a href="https://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="https://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="https://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="https://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="https://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="https://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="https://profiles.wordpress.org/bramd">bramd</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="https://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="https://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="https://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="https://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="https://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="https://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="https://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/ciantic">ciantic</a>, <a href="https://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="https://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="https://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="https://profiles.wordpress.org/dpe415">DaveE</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="https://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="https://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="https://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="https://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="https://profiles.wordpress.org/plocha">edik</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/enej">enej</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Lewis</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="https://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/fboender">fboender</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/genkisan">genkisan</a>, <a href="https://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="https://profiles.wordpress.org/hakre">hakre</a>, <a href="https://profiles.wordpress.org/hanni">hanni</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/janrenn">janrenn</a>, <a href="https://profiles.wordpress.org/jaycc">JayCC</a>, <a href="https://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="https://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="https://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="https://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="https://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kerikae">kerikae</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/klihelp">klihelp</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/ldebrouwer">ldebrouwer</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lpointet">lpointet</a>, <a href="https://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="https://profiles.wordpress.org/lkwdwrd">Luke Woodward</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/marventus">Marventus</a>, <a href="https://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="https://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="https://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/meloniq">meloniq</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="https://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="https://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="https://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="https://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="https://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="https://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="https://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="https://profiles.wordpress.org/olivm">olivM</a>, <a href="https://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="https://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="https://profiles.wordpress.org/patricknami">patricknami</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="https://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="https://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="https://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="https://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="https://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="https://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="https://profiles.wordpress.org/richard2222">Richard</a>, <a href="https://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/robmiller">robmiller</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="https://profiles.wordpress.org/roothorick">roothorick</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="https://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/sdasse">sdasse</a>, <a href="https://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="https://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="https://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="https://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="https://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="https://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="https://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="https://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="https://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="https://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="https://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="https://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="https://profiles.wordpress.org/tbrams">tbrams</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/topquarky">topquarky</a>, <a href="https://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="https://profiles.wordpress.org/toru">Toru Miki</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="https://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="https://profiles.wordpress.org/wawco">wawco</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="https://profiles.wordpress.org/xsonic">xsonic</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="https://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="https://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2341:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="https://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:32:"https://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 04 Oct 2014 16:16:30 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:37:"https://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 18 Sep 2014 16:20:10 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2561, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2571, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1412439391', 'no') ; 
INSERT INTO `wp_options` VALUES (2581, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2591, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"WPTavern: Contributing Back to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31765";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wptavern.com/contributing-back-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8837:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg" rel="prettyphoto[31765]"><img class="size-full wp-image-31713" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg?resize=1024%2C522" alt="Photo by Vladimir Kaladan Petkov" /></a>Photo by Vladimir Kaladan Petkov
<p>During a session at <a title="http://2014.europe.wordcamp.org/" href="http://2014.europe.wordcamp.org/">WordCamp Europe</a>, Matt Mullenweg was asked how companies contribute back to WordPress, how they&#8217;re doing it, and what companies should do more of. He responded to the question in-depth in a blog post entitled <a title="http://ma.tt/2014/09/five-for-the-future/" href="http://ma.tt/2014/09/five-for-the-future/">Five for the Future</a>. In the post, he outlines 5% as being a good rule of thumb to avoid the <a title="http://en.wikipedia.org/wiki/Tragedy_of_the_commons" href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons">tragedy of the commons</a>. The post ignited a healthy discussion throughout the WordPress community.</p>
<p>While his post is more about WordPress organizations, companies, and agencies and how they can grow their part of the pie and WordPress as a whole, I&#8217;m going to focus on individual contributions.</p>
<h2>What is a WordPress Contribution?</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ContributionBox.png" rel="prettyphoto[31765]"><img class="size-full wp-image-31791" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ContributionBox.png?resize=640%2C213" alt="Contribution Box" /></a>photo credit: <a href="https://www.flickr.com/photos/chrstopher/341538188/">Chrstopher</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>The definition of what classifies as a contribution to WordPress is subjective. In the broadest sense of the term, I define contribution as anything that furthers the WordPress project. I seperate contributions to WordPress into two groups, <strong>direct</strong> and <strong>indirect</strong>. Direct contributions are those that deal with the core of WordPress such as patches, leading a release, and commits. These have a direct impact on WordPress and the millions of people who use it.</p>
<p>Indirect contributions are those that further the project without using code. Examples include meetups, WordCamps, and tech support. These are what I think make up the vast majority of contributions to WordPress.</p>
<h2>Contributing to WordPress Without Realizing it</h2>
<p>As I thought about the 5% goal and whether or not I meet the criteria, I had an epiphany. <em>Thousands of people likely contribute to WordPress everyday without realizing it</em>.</p>
<ul>
<li>A friend emails you and needs WordPress support. You help fix their problem.</li>
<li>Someone needs a particular plugin to fulfill a need and you offer a suggestion that works.</li>
<li>You&#8217;re at a local meetup and help someone figure out how to use a particular feature in WordPress.</li>
</ul>
<p>All of the examples above are <strong>indirect</strong> ways of contributing to WordPress but are things millions of people do everyday. In these moments, users are helping each other while in the background, they&#8217;re contributing to WordPress. This is important because it means a lot of individuals are probably closer to the 5% goal than they might realize.</p>
<h2>The Impact of Contributions</h2>
<p>One of the first comments to Mullenweg&#8217;s article is a question <a title="http://ma.tt/2014/09/five-for-the-future/#comment-578864" href="http://ma.tt/2014/09/five-for-the-future/#comment-578864">asked by bftrick</a>, &#8220;I like the idea of having a full-time employee that works on WordPress core but I think I’d rather have everyone on board and contributing 5% of their time. What do you think about that?&#8221; Mullenweg&#8217;s response is as follows:</p>
<blockquote><p>Any percent that people can pitch in is fantastic! Some tasks divide into smaller pieces better than others, I’m sure over time you’ll find the balance that maximizes your impact. That actually brings up a good point, it’s good to look at what impact you’re having — I’ve seen companies dedicate a person full-time that hasn’t really had a big impact, and people working just a few hours a week that have had a big one. Look at the outcomes and results of what you contribute objectively, and if it’s not working try something different.</p></blockquote>
<p>I find it fascinating that some companies devoting time and effort to work on WordPress can end up having little impact. Mullenweg&#8217;s comment is a good reminder to look at the impact your contributions are having.</p>
<h2>The Value of Contributions</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ValueOfContributions.png" rel="prettyphoto[31765]"><img class="aligncenter wp-image-31792 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ValueOfContributions.png?resize=641%2C222" alt="Value Of Contributions" /></a></p>
<p>After years of being involved in the community, it&#8217;s my understanding that every contribution counts no matter how small it is. In December of 2013, I explained with the help of a few mentors, <a title="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too" href="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too">how I contributed to the core</a> of WordPress for the first time. I corrected a typo inside the default theme. I&#8217;d almost classify this as an indirect contribution but since it deals with the core of WordPress, I consider it a direct contribution. Due to the typo I fixed, my name was added to the credits page of WordPress 3.8.</p>
<p>There are hundreds of ways for people to contribute to WordPress but few that receive public acknowledgement. This is one of the reasons why badges have been added to WordPress.org user profiles.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-profile.png" rel="prettyphoto[31765]"><img class="aligncenter size-full wp-image-20468" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-profile.png?resize=1025%2C460" alt="wordpress-profile" /></a>If you&#8217;ve organized or have spoken at a WordCamp, which I classify as an indirect contribution, you&#8217;ll be publicly acknowledged with a badge.</p>
<p>On the surface, all contributions to WordPress no matter how small appear to be valued equally. However, WordPress is code that is written and maintained by humans. If direct contributions from volunteers decline to nothing, all of the indirect contributions become a moot point. While I think writing about WordPress is definitely a worthy contribution to the project, the reality is, <em>code is what gets the job done</em>.</p>
<h2>Contributing Back to WordPress Just Makes Sense</h2>
<p>While Automattic makes a significant contribution to the WordPress project, I&#8217;d hate to see it become the <strong>only</strong> large contributor. Development of WordPress 4.1 is being <a title="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead" href="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead">lead by John Blackbourn</a>, who is employed by the agency, <a title="http://codeforthepeople.com/" href="http://codeforthepeople.com/">Code For The People</a>. It&#8217;s the second release in a row to be lead by an individual not employed by Audrey Capital or Automattic. This is a welcome trend and something I&#8217;d like to see continue into the future.</p>
<p>For companies, agencies, and anyone else who rely on WordPress to put food on the table, contributing back to the project seems like common sense. WordPress is 11 years old but if those with a vested interest don&#8217;t contribute back at least 5% as suggested by Mullenweg, there&#8217;s a chance we might not be able to celebrate WordPress&#8217; 21st birthday.</p>
<h2>Related Material</h2>
<ul>
<li>Post Status &#8211; <a href="http://www.poststat.us/contribution-culture/">Contribution Culture </a></li>
<li>Ben Metcalf &#8211; <a title="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/" href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/">The feasibility and governance concerns behind 5% contribution to WordPress Core</a></li>
<li>Tony Perez &#8211; <a href="http://perezbox.com/2014/10/wordpress-the-vision-of-five-and-what-it-means/">The Vision of Five and What it Means</a>.</li>
<li>Dries Buytaert &#8211; <a title="http://buytaert.net/scaling-open-source-communities" href="http://buytaert.net/scaling-open-source-communities">Scaling Open Source Communities</a></li>
</ul>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 03 Oct 2014 05:57:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WordPress.tv Blog: Build your audience:  Recent WordCamp videos from experienced content creators";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.wordpress.tv/?p=398";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2710:"<p>Building an audience and growing traffic on your blog is an evergreen topic at WordCamps everywhere. Here are some recent videos from <a href="http://wordpress.tv/event/wordcamp-cape-town-2013/" target="_blank">WordCamp Capetown</a> and <a href="http://wordpress.tv/event/wordcamp-calgary-2014/" target="_blank">WordCamp Calgary </a> on how you can raise the profile of your blog with the power of content!</p>
<h2>How to build an audience in 743 difficult steps</h2>
<div id="v-revo65sd-1" class="video-player">
</div>
<p>Rian van der Merwe shares why it is better to stay away from the easy ways and choose the difficult ways instead, and how a struggling blog with an insignificant number of readers can become not only a source of great joy and expression, but also a source of non-insignificant income.</p>
<p><a href="http://wordpress.tv/2014/10/01/rian-van-der-merwe-how-to-build-an-audience-in-743-difficult-steps/" target="_blank">View on WordPress.tv</a></p>
<h2>Finding Your Voice – Learnings From 6 years of Failure</h2>
<div id="v-tS1GsW4N-1" class="video-player">
</div>
<p>In this talk, Ernest Barbaric discusses how  6 years of failure, and trying thousands of tips, tricks and best practices helped him to build an audience and a blog presence and how finally the right words came out through the keyboard, they connected with the right people, traffic quadrupled almost instantly, Publications came knocking and business started coming in from across the globe.</p>
<p><a href="http://wordpress.tv/2014/09/30/ernest-barbaric-finding-your-voice-learnings-from-6-years-of-failure/" target="_blank">View on WordPress.tv</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptvblog.wordpress.com/398/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptvblog.wordpress.com/398/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.wordpress.tv&blog=5310177&post=398&subd=wptvblog&ref=&feed=1" width="1" height="1" /><div><a href="http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/"><img alt="WordCamp Cape Town 2013 &#8211; Rian van der Merwe &#8211; How to build an audience in 743 difficult steps.mp4" src="http://videos.videopress.com/revo65sd/video-e29d41ae2b_scruberthumbnail_0.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/"><img alt="Ernest Barbaric: Finding Your Voice – Learnings From 6 years of Failure" src="http://videos.videopress.com/tS1GsW4N/video-5e3790afbe_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 03 Oct 2014 01:32:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Jerry Bates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: 5 WordPress Conferences Taking Place This Weekend";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31778";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wptavern.com/5-wordpress-conferences-taking-place-this-weekend";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5511:"<p>This weekend is a busy time for WordPress conferences. One event to keep an eye on is WordCamp Tampa. They have been selected as one of the first to participate in a live stream pilot program using new equipment purchased by the WordPress Foundation.</p>
<p>Depending on the outcome of the experiment at this and other events, live streaming may become a regular feature of future WordCamps. Here&#8217;s a recap of the events taking place this weekend and how you can enjoy some of them from the comfort of your home.</p>
<h2>PodsCamp</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/PodsCampFeaturedImage.png" rel="prettyphoto[31778]"><img class="size-full wp-image-29491" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/PodsCampFeaturedImage.png?resize=697%2C284" alt="The First Ever Podscamp" /></a>The First Ever Podscamp
<p>PodCamp is being held in Dallas, TX on October 3rd, 2014, a day before <a title="http://2014.dfw.wordcamp.org/" href="http://2014.dfw.wordcamp.org/">WordCamp DFW</a> (Dallas/Fort Worth) with a ticket price of $50. Each ticket grants you access to the event, BBQ for lunch, and direct access to the developers of Pods Framework. This will be the first time every member of the Pods development team will be in the same physical location. There are <a title="http://podscamp.org/tickets/" href="http://podscamp.org/tickets/">12 tickets remaining</a>.</p>
<h2>PrestigeConf</h2>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/PrestigeConfLogo.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-27630" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/PrestigeConfLogo.png?resize=275%2C233" alt="Prestige Conference Logo" /></a></p>
<p>Prestige is a <a title="http://prestigeconf.com/" href="http://prestigeconf.com/">new conference </a>taking place on October 3rd-5th, 2014 in downtown Minneapolis, Minnesota and is being organized by Josh Broton and Kiko Doran. Unlike WordCamps, Prestige only has one track and is devoted to the business of WordPress. There are <a title="http://prestigeconf.com/tickets/" href="http://prestigeconf.com/tickets/">17 tickets remaining</a> for October 4th. However, there are 32 tickets remaining at $49 each to view a live stream of the event. Prestige also has a <a title="http://prestigeconf.wparmchair.com" href="http://prestigeconf.wparmchair.com">WP Armchair site</a> to monitor the hashtag assigned to the event.</p>
<h2>WordCamp DFW (Dallas/Fort Worth)</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampDallas2014Header.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-31782" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampDallas2014Header.png?resize=503%2C265" alt="WordCamp Dallas 2014 Header" /></a></p>
<p>For the first time <a title="http://central.wordcamp.org/wordcamps/dallas-2009/" href="http://central.wordcamp.org/wordcamps/dallas-2009/">since 2009</a>, there is a <a title="http://2014.dfw.wordcamp.org/" href="http://2014.dfw.wordcamp.org/">WordCamp being held</a> in the Dallas/Forth Worth area. WordCamp Dallas is a two-day event beginning on October 4th. The first day will have sessions covering various aspects of WordPress while Sunday, October 5th is contributor day. Tickets are sold out but you can keep tabs on the event via <a title="http://wcdfw.wparmchair.com/" href="http://wcdfw.wparmchair.com/">http://wcdfw.wparmchair.com/</a>.</p>
<h2>WordCamp Ann Arbor</h2>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampAnnArbor2014.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-31783" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampAnnArbor2014.png?resize=680%2C265" alt="WordCamp Ann Arbor 2014 Header" /></a></p>
<p><a title="http://2014.annarbor.wordcamp.org/" href="http://2014.annarbor.wordcamp.org/">WordCamp Ann Arbor</a> is a one day event in downtown Ann Arbor, Michigan near the University of Michigan. For just $12, attendees will have an entire day of sessions to choose from to learn WordPress. It&#8217;s the first event of its kind in for Ann Arbor and tickets are sold out. I&#8217;ll be at this event so if you see me, stop and say hi.</p>
<h2>WordCamp Tampa</h2>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampTampa2014Header.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-31784" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampTampa2014Header.png?resize=458%2C225" alt="WordCamp Tampa 2014 Header" /></a></p>
<p><a title="http://2014.tampa.wordcamp.org/" href="http://2014.tampa.wordcamp.org/">WordCamp Tampa</a>, Florida, is a two-day event beginning on October 4th. Tickets are sold out but you can watch the event from home if you purchase a <a title="http://2014.tampa.wordcamp.org/live-streaming/" href="http://2014.tampa.wordcamp.org/live-streaming/">live stream ticket</a>. There are 954 tickets remaining at a cost of $5 each. WordCamp Tampa is part of a pilot program to experiment with new equipment purchased by the WordPress Foundation to generate a high quality live stream. Depending on the results of the experiment at this and other events, live streaming may become a common feature at future WordCamps. Alternatively, you can follow along via <a title="http://wctpa.wparmchair.com/" href="http://wctpa.wparmchair.com/">http://wctpa.wparmchair.com/</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 22:33:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: WPWeekly Episode 164 – Interview With Lester “GaMerZ” Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=31769&preview_id=31769";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wptavern.com/wpweekly-episode-164-interview-with-lester-gamerz-chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4336:"<p>In this episode of WordPress Weekly, <a href="http://marcuscouch.com/" title="http://marcuscouch.com/">Marcus Couch</a> and I travel to Singapore to interview <a href="http://lesterchan.net/" title="http://lesterchan.net/">Lester &#8220;GaMerZ&#8221; Chan</a>. Chan has <a href="https://profiles.wordpress.org/gamerz/#content-plugins" title="https://profiles.wordpress.org/gamerz/#content-plugins">23 different plugins</a> in the plugin directory, amassing an incredible total download count of <strong>12,241,325</strong>! This accounts for approximately <strong>1.6%</strong> of all plugin downloads from the directory.</p>
<p>Chan explains how he handles support for 23 different plugins and offers suggestions to improve WordPress.org to make providing support easier. One of his suggestions is to give plugin authors the ability to close threads in their plugin&#8217;s support forums. Chan describes what the WordPress scene is like in Singapore and informs us that there a shortage of WordPress developers. Last but not least, he explains his role as &#8220;Tech Guy&#8221; for the <a href="http://www.techinasia.com/" title="http://www.techinasia.com/">Tech In Asia</a> website which is powered by WordPress.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/reader-poll-what-are-your-favorite-features-in-wordpress-4-0" title="http://wptavern.com/reader-poll-what-are-your-favorite-features-in-wordpress-4-0">Reader Poll: What Are Your Favorite Features In WordPress 4.0?</a><br />
<a href="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead" title="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead">Meet John Blackbourn, WordPress 4.1 Release Lead</a><br />
<a href="http://wptavern.com/ben-gillbanks-announces-the-end-of-timthumb" title="http://wptavern.com/ben-gillbanks-announces-the-end-of-timthumb">Ben Gillbanks Announces The End of TimThumb</a><br />
<a href="http://wptavern.com/godaddy-and-media-temple-engage-in-strategic-partnership-with-wp101" title="http://wptavern.com/godaddy-and-media-temple-engage-in-strategic-partnership-with-wp101">GoDaddy and Media Temple Engage in Strategic Partnership With WP101</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/gravity-forms-personality-quiz-add-on/" title="https://wordpress.org/plugins/gravity-forms-personality-quiz-add-on/">Gravity Forms Personality Quiz Add-On</a> lets you create simple, un-scored personality quizzes (think Buzzfeed-style quizzes). While there is an official quiz add-on for Gravity Forms, it is focused on graded quizzes like those you might take in school. This add-on lets you easily create quizzes that return a result rather than a grade, like &#8220;How Texan are you?&#8221; or &#8220;What Disney character would you be?&#8221;</p>
<p><a href="https://wordpress.org/plugins/ttt-crop/" title="https://wordpress.org/plugins/ttt-crop/">TTT Crop</a> This is an easy and fast way to crop any uploaded image into WordPress. No more complicated graphical editors, photos of people without heads, or products with a wrong view. Select the thumbnail, edit the crop area, and save a new thumbnail image.</p>
<p><a href="https://wordpress.org/plugins/family-tree/" title="https://wordpress.org/plugins/family-tree/">WP Family Tree</a> is a graphically formatted family tree generator for WordPress. Family members are registered as custom post types through which you can manage things such as name, birthday, the person&#8217;s picture, occupation, etc. You can also establish relationship associations, such as who a person&#8217;s mother and father are or their spousal relationship.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, October 8th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #164:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 21:21:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: Matt Mullenweg on Ensuring the Future of WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31712";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wptavern.com/matt-mullenweg-on-ensuring-the-future-of-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:17398:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg" rel="prettyphoto[31712]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg?resize=1024%2C522" alt="Photo by Vladimir Kaladan Petkov" class="size-full wp-image-31713" /></a>Photo by Vladimir Kaladan Petkov
<p>Matt Mullenweg made waves this past weekend during his Q&amp;A session at <a href="http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014" target="_blank">WordCamp Europe</a> when he strongly advocated the importance of companies contributing back to WordPress. He offered a rule of thumb for companies that benefit from the software and want to invest in the future of WordPress:</p>
<blockquote><p>I think a good rule of thumb that will scale with the community as it continues to grow is that organizations that want to grow the WordPress pie (and not just their piece of it) <strong>should dedicate 5% of their people to working on something to do with core</strong> — be it development, documentation, security, support forums, theme reviews, training, testing, translation or whatever it might be that helps move WordPress mission forward.</p></blockquote>
<p>He cites the <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons" target="_blank">tragedy of the commons</a> as an example fate that he hopes WordPress can avoid.</p>
<p>The <a href="http://ma.tt/2014/09/five-for-the-future/" target="_blank">5% statement</a> was instantly controversial, sparking a number of heated discussions on <a href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/" target="_blank">blogs</a>, <a href="http://www.poststat.us/contribution-culture/" target="_blank">news sites</a>, and Twitter. Some took exception to the wording of his suggestion, as the use of &#8220;should&#8221; implies a moral obligation, complicated further by the fact that the statement originates from a person in a position of power, who many perceive as the person most likely to benefit from increased contributions.</p>
<p>Granted, Mullenweg is at the helm of what is undeniably the most successful WordPress-based company in operation. Automattic is one of many companies that are entirely reliant on this software for their continued existence. Though all may not benefit equally from contribution, it does not negate the fact that the WordPress project is 100% dependent on contribution and would not exist without it. If we want to see it grow, there must be continued contribution, and in the end it doesn&#8217;t matter if that motivation is practical or ideological.</p>
<p>Open source businesses are free to act on Mullenweg&#8217;s suggestion of 5% contribution or to throw it out entirely. The issue cuts close to home. It&#8217;s a personal question of philosophy as much as it is a business consideration.</p>
<p>For Mullenweg, the suggestion of a 5% contribution originates out of a desire to ensure the future of WordPress. The project started out much like your average garage band. Mullenweg <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/" target="_blank">wanted a place to blog and post photos</a>, so with the help of a handful of contributors, WordPress was born. Since the very early days, he has been unwavering when it comes to protecting user freedoms with the GPL and established the project&#8217;s mission to democratize publishing through open source software.</p>
<p>Before you decide to contribute, it&#8217;s a good idea to consider the future of WordPress. Where does Matt see the project going? Do you want to be a part of taking it there? I had the opportunity to speak with him at WordCamp Europe to press further into his vision of WordPress for the next decade.</p>
<h2>Mobile</h2>
<p>You&#8217;ve probably heard it before: mobile is a big part of the future of WordPress. Mullenweg emphasizes this in nearly every recent interview I&#8217;ve read and Automattic is aggressively hiring mobile developers. For many internet users, their mobile device is the only way they access the web. This is particularly true for users in countries like <a href="http://en.wikipedia.org/wiki/List_of_countries_by_number_of_mobile_phones_in_use" target="_blank">China and India</a>. If WordPress is to gain penetration in these geographical regions, it must provide a solid mobile experience.</p>
<p>This puts the WordPress mobile apps in a singular place of influence, which results in a bit of controversy at the moment. Currently, the apps are packed full of WordPress.com features that provide functionality beyond the core publishing experience. Many self-hosted WordPress users <a href="http://wptavern.com/poll-who-uses-reader-in-the-wordpress-mobile-apps" target="_blank">find the Reader in particular to be irrelevant</a>.</p>
<p>Mullenweg explained Automattic&#8217;s approach to the mobile apps:</p>
<blockquote><p>The goal with the mobile apps is first and foremost to get as many mobile app users as possible, because I think that ensures WordPress development for years to come. They are open source projects and people can contribute code to make them do a lot of different things. The team is focused on developing the things that will be most compelling to people on the mobile side. That&#8217;s notifications, stats, and the reader.</p></blockquote>
<p>Since the apps are open source, developers can fork them and remove unwanted features if they want to. However, this seems a bit counterintuitive for self-hosted WordPress users who don&#8217;t use WordPress.com features. The recent <a href="http://wptavern.com/wordpress-com-publishes-first-ever-video-ad-entitled-welcome-home" target="_blank">video ad</a> produced by Automattic does not put the spotlight on the Reader but rather features the mobile apps in use for publishing media. Won&#8217;t people be using the publishing features more often than the Reader? Mullenweg doesn&#8217;t think so.</p>
<blockquote><p>By definition, people read more than they write. You read far more than you write.  The average blogger doesn&#8217;t post every day. They read blogs every day. In fact, they read WordPress blogs every day, over a billion per month. By connecting more of those to the active users with this thing we call WordPress, I think it opens the door for more publishing in the future, which is really exciting.</p></blockquote>
<p>The apps are technically open source. If there&#8217;s a strong contingency of developers who don&#8217;t agree with the preeminence of WordPress.com&#8217;s Reader in the app, they can work to change that through contribution. The reality is that mobile developers are few and far between. At the moment, Automattic drives nearly 100% of the contribution on the apps and its agenda is unrivaled. These apps wouldn&#8217;t exist without the company&#8217;s contributions.</p>
<p>I asked Mullenweg if other contributing commercial entities are free to push their own features through the official mobile apps. &#8220;Yeah they could,&#8221; he said, but followed it up with more insight on what he believes to be Automattic&#8217;s roll in the mobile apps:</p>
<blockquote><p>I think that in many ways, Automattic is a shepherd. When you type in WordPress into a search engine, we&#8217;re the thing that pops up first. We&#8217;re the gateway drug, the thing that brings in the billions of people who don&#8217;t use WordPress yet. That&#8217;s our responsibility.</p></blockquote>
<p>He believes that, as more users easily gain access through WordPress.com, it will mean a greater number of those who transition to self-hosted sites, as people graduate from the service. &#8220;We&#8217;ll even help them move on,&#8221; he said. Obviously, you cannot simply download PHP files to your phone and get started.</p>
<p>&#8220;We want you to be able to start a blog and engage with the world of blogging 100% from the mobile device,&#8221; he said. &#8220;That requires WordPress.com and Jetpack features. Will it forever? Maybe not, but, as an idealist in a practical world, while that is not what I&#8217;d choose as a perfect solution &#8211; I&#8217;d love for you to be able to run WordPress on your phone and the world could access it, but that&#8217;s not reality today.&#8221;</p>
<p>So why doesn&#8217;t Automattic simply rename the apps to reflect the fact that the it heavily features WordPress.com? &#8220;We could rename it to WordPress.com App, but then there would be no WordPress app.&#8221; Automattic only has 15 mobile engineers at present and there aren&#8217;t many on the outside lining up to contribute to the open source apps. For Mullenweg, the ease of starting a free blog via the app is something that will help to ensure the future of WordPress:</p>
<blockquote><p>It&#8217;s difficult to build an open source thing on a closed source platform. I see it as a gateway drug and it gives people more options down the road. If we don&#8217;t do anything on mobile, five years from now, when everyone is only using mobile devices, they will all have Squarespace&#8217;s or Weebly&#8217;s. WordPress is still around but it just doesn&#8217;t matter. This allows us to matter five years from now.</p></blockquote>
<p>Mullenweg sees the apps as an easy onramp to the WordPress software in general, but recognizes that the method isn&#8217;t the most ideal situation for everyone. &#8220;The direction we&#8217;re moving is to make them more modular, so people can fork the apps more easily in the future,&#8221; he said. &#8220;If you talk to anyone on the mobile team, you will find a passion for open source.&#8221; This means that there&#8217;s the potential for the focus of the app&#8217;s development to change in the future.</p>
<h2>Internationalization and Global Adoption</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/wp-croatia-serbia-slovenia-communities.png" rel="prettyphoto[31712]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/wp-croatia-serbia-slovenia-communities.png?resize=1025%2C509" alt="Croatian, Serbian and Slovenian WP communities with @photomatt @nacin at #WCEU - photo credit: Konstantin Tatar" class="size-full wp-image-31716" /></a>Croatian, Serbian and Slovenian WP communities with @photomatt @nacin at #WCEU &#8211; photo credit: Konstantin Tatar
<p>WordCamp Europe is unique in that it brings together many WordPress users whose primary language is not English. Mullenweg could not hide his excitement about the recent and upcoming changes related to internationalization. &#8220;If WordPress is representative of the world, then English should be a minority of the interactions, contributions and even plugins,&#8221; he said, and remarked further on how we&#8217;re still in the old mindset of taking English plugins and themes and then translating them into another language.</p>
<blockquote><p>Personally, I am far and away most excited about the internationalization improvements, because the fact that WordPress has that many users at all in these other languages where there&#8217;s not very much documentation, no plugins, very few themes, it&#8217;s kind of amazing. Basically we have lots of usage in other countries but it&#8217;s primarily built by English-speaking people. So when that starts to change to where you can, for example, login to your dashboard in Spanish, installation, plugins and themes in Spanish, I think it could substantially change WordPress&#8217; adoption rate.</p></blockquote>
<p>He believes that internationalization improvements will be key to improving WordPress&#8217; global adoption and may perhaps be more of an influential factor than the software&#8217;s incremental improvement on features:</p>
<blockquote><p>Honestly, incremental features in WordPress probably aren&#8217;t going to change its adoption rate (the number of people starting a WP blog every day). At this point, that&#8217;s primarily driven by our reputation and existing users. What will substantively change that is if WordPress opens up to vastly more audiences than it was before, be that platforms, languages, or cost. At the moment WordPress.com is free but it&#8217;s not fully available to all languages.</p></blockquote>
<p>WordPress already receives many contributions from contributors who do not speak English as their first language. Mullenweg believes it may be quite a ways down the road from now before WordPress core development requires translators to effectively incorporate contributions from what may someday be a larger contingency of non-English speaking lead developers.</p>
<p>&#8220;Maybe there&#8217;s a full-time translator working with Nacin,&#8221; he commented, imagining how internationalization could change the project in the future. With WordPress fully opened up to more languages, the software has the potential to improve at an exponentially faster rate than it does now. It&#8217;s an exciting prospect to consider.</p>
<h2>The Value of Experimentation</h2>
<p>In his quest to ensure the future of WordPress, Mullenweg often looks outside of the project for inspiration. He&#8217;s devoted a team at Automattic to experimenting with non-WordPress technologies. This was the team that created the <a href="http://wptavern.com/automattics-planned-gravatar-app-morphs-into-a-selfies-app-for-android" target="_blank">Selfies app</a>, released earlier this year.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/selfies.jpg" rel="prettyphoto[31712]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/selfies.jpg?resize=582%2C267" alt="selfies" class="aligncenter size-full wp-image-26965" /></a></p>
<p>The app wasn&#8217;t built on WordPress and didn&#8217;t appear to be as polished as other Automattic products. I asked Mullenweg why they chose to release the app in its unpolished state. He highlighted the importance of experimentation:</p>
<blockquote><p>One thing that&#8217;s difficult in a company, as it grows, is to not just work on the thing that&#8217;s most successful. WordPress, WordPress.com, Jetpack, these are ridiculously successful by any measure. It would be very easy for all 272 people at Automattic to only work on that. One of the things we did this year is create a team that is almost like our version of Google X, except we&#8217;re not going to space. As a smaller company our ambitions are a little more modest, but we do want that sense of experimentation, and that it&#8217;s ok to release something that&#8217;s not 100% polished.</p></blockquote>
<p>This further clarifies the release of the Selfies app, which the team presented as an accident wherein the planned Gravatar App morphed into Selfies. &#8220;There&#8217;s no one working on a Gravatar app right now,&#8221; Mullenweg said, confirming that the idea was considered and then scrapped. What they learned in the process was more valuable than delivering on the original idea.</p>
<blockquote><p>Usage is oxygen for ideas, right? The things that we know and learn by releasing stuff, we never could have learned otherwise, so look for more of that. That team has lots of things planned &#8211; their charter is specifically not to do things that integrate with WordPress. I&#8217;d love for it to be a much larger team, actually.</p></blockquote>
<p>This spirit of experimentation is what sets Automattic apart from many other companies that simply focus on their successful products. Perhaps it will someday translate into technology that can work alongside WordPress, especially when the software adopts more modern APIs.</p>
<h2>The Mission</h2>
<p>In recent press, Automattic has received considerable attention due to the fact that the company doesn&#8217;t work from one centralized office. The idea is brand new to those who have only experienced more traditional workplaces. I asked Mullenweg what he believes is truly unique about his company. He cited a few things, such as the hiring process, the reliability of WordPress.com&#8217;s technical architecture, the dedication to experimentation. But in the end, for him, everything loops back around to the mission of democratizing publishing.</p>
<blockquote><p>I don&#8217;t think there&#8217;s anything that doesn&#8217;t exist in any other company. Obviously we&#8217;re really deeply involved with WordPress. So is 10up and many other WP consultancies. We do a ton of open source but so does Canonical, Acquia, Redhat, and everyone else. I think it&#8217;s just the combination of all of these things, the truly distributed nature, and the mission, which isn&#8217;t just about bottom lines. It has an altruistic aspect as well.</p></blockquote>
<p>Mullenweg&#8217;s <a href="http://ma.tt/2014/09/five-for-the-future/" target="_blank">Five for the Future</a> post compelling open source companies to strive to contribute 5% back to the core software is a hotly debated topic in the WordPress ecosystem right now. Those who do not share the same practical convictions or altruistic ideals feel that the idea comes with an implication of people &#8220;working for free.&#8221; The folks at Automattic are hoping to lead the way in proving that commercial success can go hand-in-hand with an altruistic mission. For Mullenweg, it&#8217;s part of a larger vision and an unwavering commitment to ensure the future of WordPress for all.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 18:31:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: Singapore Suites Class";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44174";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2014/10/singapore-suites-class/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1153:"<p>Derek Low on What It&#8217;s like to Fly the $23,000 Singapore Airlines Suites Class [link removed, see end]. I&#8217;ve been on the <a href="http://thepointsguy.com/2014/01/flight-review-emirates-first-class-a380-dubai-new-york-jfk/">Emirates First Class A380 with the shower before</a>, but this looks like an entirely other level. I also must confess I think Emirates has rather gaudy design. <a href="http://www.svenblogt.de/review-first-class-airbus-a330-with-swiss-air/">The best I&#8217;ve seen design-wise is actually from Swiss Air</a>, as you&#8217;d expect. Update: Apparently the original link <a href="http://www.reddit.com/r/singapore/comments/2huw34/what_its_like_to_fly_the_23000_singapore_airlines/">borrowed pretty heavily</a> from another blogger, so here are links to the original author&#8217;s posts: <a href="http://andystravelblog.com/2013/04/22/sia-singapore-airlines-suites-class-a380-frankfurt-singapore/">one</a>, <a href="http://andystravelblog.com/2013/05/05/singapore-airlines-777-first-class-private-room/">two</a>, <a href="http://andystravelblog.com/2013/05/09/cathay-pacific-first-class-747-hkg-sfo/">three</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 11:27:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Akismet: September Stats Roundup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1705";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.akismet.com/2014/10/01/september-stats-roundup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3602:"<p><img class="alignright wp-image-1716" src="http://akismet.files.wordpress.com/2014/10/akisbot-party1.jpg?w=500&h=291" alt="akisbot-party" width="500" height="291" />T&#8217;was an exciting month around Akismet headquarters. <strong>We caught over 300 million spam messages in just one day for the first time</strong>, on September 26. And if that wasn&#8217;t enough, we saw over 300 million comments in one day again on September 30.</p>
<p>But wait, there&#8217;s more&#8230; we also broke our daily record a total of 4 times this month. Our last daily record was 269 million spam messages on August 21, here&#8217;s what happened since then:</p>
<ul>
<li>We broke the daily record on <strong>September 4th</strong> with 280 million spam comments</li>
<li>And then again on <strong>September 7th</strong> with 284 million spam messages</li>
<li>And then again on <strong>September 26th</strong> with the groundbreaking 312 million comments</li>
<li>And finally, just yesterday &#8211; on <strong>September 30</strong> -we broke our record again with 366 million spam comments</li>
</ul>
<p>Phew. What a ride. <span class="wp-smiley emoji emoji-mrgreen" title=":mrgreen:">:mrgreen:</span></p>
<p>There were two other times in Akismet history when we broke the daily record this many times in one month. In November 2011 we broke the daily record 8 times (!) and in December 2012, we broke it 6 times. Though, the numbers were much easier to beat then &#8211; 90 to 100 million daily spam comments in November 2011, and 177 to 196 million in December 2012.</p>
<p>Here are the daily numbers for September, with the previous record marked for comparison:</p>
<div id="attachment_1719" class="wp-caption alignnone"><a href="http://akismet.files.wordpress.com/2014/10/akismet-spam-and-ham-stats-sept-2014.png"><img class="wp-image-1719 size-large" src="http://akismet.files.wordpress.com/2014/10/akismet-spam-and-ham-stats-sept-2014.png?w=700&h=436" alt="We saw 7,955,568,000 spam comments go through this month, and 357,739,000 real comments." /></a><p class="wp-caption-text">We saw 7,955,568,000 spam comments go through this month, and 357,739,000 real comments.</p></div>
<p>You may have also seen a rise in your own spam comments this month. If you&#8217;re noticing a larger number of comments than usual being missed by Akismet, please do get in touch through <a href="http://akismet.com/contact/">our contact form</a> so we can help out. Let us know what your API key is, and on what website you&#8217;re seeing the increase, and we&#8217;ll be happy to take a look.</p>
<p>Our slowest day this month was September 14, with a mere 218 million spam comments going through. Compared with September of last year, the number of spam comments going through Akismet increased by 112%, and it increased from last month by 10%. This month, we missed about 1 in every 4,574 spams.</p>
<p>As usual, real comments make up only a small portion of the total comments we see coming through &#8211; at 4% this month.</p>
<p><em>This post is part of a monthly series summarizing some stats and figures from the Akismet universe. Feel free to browse <a href="http://blog.akismet.com/category/monthly-roundup/">all of the posts in the series</a>.</em></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1705/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1705/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1705&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 01:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Valerie";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: WordPress Theme Review Team Gains 27 New Reviewers at WordCamp Europe Contributor Day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31680";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wptavern.com/wordpress-theme-review-team-gains-27-new-reviewers-at-wordcamp-europe-contributor-day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4310:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/wceu-contributor-day.png" rel="prettyphoto[31680]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/wceu-contributor-day.png?resize=1025%2C495" alt="wceu-contributor-day" class="aligncenter size-full wp-image-31687" /></a></p>
<p>The contributor day following <a href="http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014" target="_blank">WordCamp Europe</a> was a tremendous success, bringing approximately 180 people to the <a href="http://www.siteground.com/" target="_blank">SiteGround</a> offices in Sofia. A healthy mixture of veteran contributors were in attendance, as well as many folks who were brand new to contributing.</p>
<p>At the beginning of the day, contributors split off into smaller groups to focus on translations, core, documentation, theme review, support, GlotPress, and Rosetta. When Theme Review Team member Tammie Lister put out a call for theme reviewers, hands shot up all over the room. Automattic donates Lister&#8217;s time two or three days per week specifically for helping with WordPress.org theme review.</p>
<p>After the event, she reported that 27 new people were added to the <a href="https://make.wordpress.org/themes/" target="_blank">WordPress Theme Review Team</a>. They started by introducing themselves and discussing why one might want to get involved. Those who had some experience shared their individual processes. After this, they dove straight into reviewing and each person was given a theme.</p>
<p>&#8220;The current idea is that during the month of October we will be focusing on how we do contribution days now, so we&#8217;re having experiments and thinking about ways to improve that,&#8221; Lister said. During the last <a href="https://make.wordpress.org/themes/2014/09/24/weekly-meeting-notes-2/" target="_blank">weekly meeting</a>, the Theme Review Team identified the pain points in adding reviewers and brainstormed ideas for onboarding new reviewers during contributor days. This includes the possibility of creating a doing_it_wrong() theme, as a project at WordCamp San Francisco, that can be used for education and testing. Lister said they will be playing with a few ideas at upcoming contribution days in San Francisco and Toronto.</p>
<h3>A Room Full of Themers</h3>
<p>The best part of getting a record number of new reviewers together was packing a room full of themers who were all buzzing about the craft of WordPress theming. &#8220;What was really exciting about today is that it wasn&#8217;t just developers,&#8221; Lister said. &#8220;We had some people who didn&#8217;t know much HTML, some who were newer to theming, and some who were doing it the right way.&#8221;</p>
<p>The key thing for new reviewers is to take your time, Lister said. &#8220;I think the thing is that you just have to take it slowly when you start theme reviewing. You go through the process and you get faster.&#8221;</p>
<p>New reviewer <a href="https://twitter.com/andrew_liyanage" target="_blank">Andrew Liyanage</a> decided to jump in and join the Theme Review Team in order to sharpen his professional skills. &#8220;I wanted to get into theme design. I thought before designing a theme, I could get into review in order to get to know what the do&#8217;s and the don&#8217;ts are,&#8221; he said. &#8220;I&#8217;m already reviewing a theme right now, and it&#8217;s going better than I thought it would.&#8221;</p>
<p>Lister plans to match each new reviewer with someone from the new <a href="http://wptavern.com/wordpress-theme-review-team-to-launch-mentoring-program" target="_blank">mentoring program</a>, established last month. Although most of the communication happens on trac, there are more people than ever to help out with the process.</p>
<p>&#8220;A lot of it is trac focused, because it has to be, but we now have mentors, more admins, and trusted reviewers. So there&#8217;s a lot more people but there&#8217;s a lot more people looking after those people,&#8221; Lister said.</p>
<p>With a record number of new theme reviewers added in one day, the team now has 27 more people who are familiar with the guidelines. This is bound to make a significant dent in the queue and lighten the load for the rest of the team.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 09:52:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Post Status: Contribution as culture";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7153";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://www.poststat.us/contribution-culture/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12488:"<p><img class="aligncenter size-large wp-image-7157" src="http://www.poststat.us/wp-content/uploads/2014/10/five-percent-752x250.gif" alt="five-percent" width="627" height="208" /></p>
<p><em>This post spends a lot of time analyzing and referencing two other blog posts. Excuse me for that, but also be sure to read both, as they are relevant for this post and also interesting in their own right.</em></p>
<p>Matt Mullenweg wrote a blog post called <a href="http://ma.tt/2014/09/five-for-the-future/">Five for the Future</a> yesterday that advocates his belief that WordPress-centric companies should aim to utilize 5% of their company resources toward contributing back to the project.</p>
<p>He noted in the post that <a href="http://automattic.com">Automattic</a> isn&#8217;t quite to this point, but that they are working on it, and describes why he believes it&#8217;s important. He closes with this:</p>
<blockquote><p>It’s a big commitment, but I can’t think of a better long-term investment in the health of WordPress overall. <strong>I think it will look incredibly modest in hindsight.</strong> This ratio is probably the bare minimum for a sustainable ecosystem, avoiding the <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons">tragedy of the commons</a>. I think the 5% rule is one that all open source projects and companies should follow, at least if they want to be vibrant a decade from now.</p></blockquote>
<p>This was followed up by one of the co-founders of one of the very hosting companies Matt partially referenced in his post &#8212; WP Engine&#8217;s Ben Metcalfe &#8212; who responded with a blog post of his own: <a href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/">WordPress: What exactly do they get for their 5%?</a></p>
<p>I think I was immediately thrown off by Ben&#8217;s post title, but so many times throughout reading it I was shocked at how he made assumptions of Matt&#8217;s intentions or missed what I would call &#8220;the point&#8221;.</p>
<h3>5% is not a decree</h3>
<p>Obviously, Matt is not speaking from the mountaintop with a proclamation of law. This is his recommendation &#8212; one that he believes will reward the firms that strive for it.</p>
<p>I believe that the community has already shown us that those that invest into WordPress are rewarded from it. We improve our understanding of a foundational software of our careers, improve our skills, are more marketable, more attractive to employers, and create natural opportunities for developing industry relationships.</p>
<p>How should 5% of &#8220;people&#8221; be defined? I&#8217;m pretty sure Matt would agree that 5% of people or 5% of revenue toward people doesn&#8217;t really matter to him; yet Ben makes a continuous sticking point about the cost of &#8212; and need for &#8212; engineers.</p>
<p>Additionally, while Matt utilizes full-time employees, the same (or better) effect could be had with shared time from more employees.</p>
<p>I&#8217;m not big into absolutes, so it&#8217;s important to remember that while I&#8217;m advocating that Matt&#8217;s recommendation of 5% time, I think it&#8217;s simply a good recommendation. This is a free economy and companies can do what they want. But I think in the current and long term, contribution will be key to greater corporate success for those that choose to do so.</p>
<h3>What does 5% cost, and who does it require?</h3>
<p><span id="more-7153"></span></p>
<blockquote><p>While Matt was careful to include numerous non-engineering roles companies could help with, ultimately what drives the open source project is source code contribution by software engineers. &#8230;</p>
<p>A reasonable engineer in the US costs $100k/y, and if you factor in benefits <em>(tax funded health-care, anyone?)</em> and overheads you could easily be looking at $130k or more per person, per year. &#8230;</p>
<p>A 200+ person web hosting company would need to hire 10 engineers to meet a 5% goal, requiring a budget of anything between $1MM-1.3MM+ per year. Those engineers probably need a manager – to mentor them, provide career development etc. Those 11 people also put pressure on human resources, finance, legal, facilities etc – probably equating to another person again. Now we’re talking probably more like $1.25-$1.5m annually.</p></blockquote>
<p>First, I believe Ben has spent too much time in the world&#8217;s largest cities if he believes engineers cost $100,000 per year on average. In my experience (yes, I interview people myself), that&#8217;s not the case, and based on my decent view of the ecosystem it&#8217;s not an appropriate going rate &#8212; especially if the offer on the table is a particularly desirable position.</p>
<p>More importantly, <strong>the project needs far more non-technical contributors</strong>. Ben&#8217;s assertion that &#8220;ultimately&#8221; software engineers drive the project is not true. Users drive the project. A technically savvy user-minded contributor can be a beacon of light to a group of software developers. And given the user-facing nature of WordPress itself, non-engineer contributors could drastically improve the less code-sexy parts of the WordPress ecosystem: project management, docs, training, testing, support, translation, etc.</p>
<p>Additional to &#8220;core&#8221; contributions, WordCamps, plugins, themes, communities, and many other venues are outstanding places where contributors &#8212; yes, they&#8217;re still contributors! &#8212; can impact the overall project.</p>
<p>Finally, as I noted above, I think companies could quite effectively contribute parts of employees&#8217; time versus dedicated 100% time, which would also prevent the need to have dedicated managers for open source contributors.</p>
<h3>Foundational software to your business</h3>
<p>Ben spends a chunk of time saying that big companies like GoDaddy get a &#8220;get out of jail free card&#8221; and that obviously Matt wouldn&#8217;t expect they dedicate 5% of their thousands of employees.</p>
<p>GoDaddy definitely benefits from WordPress and they also contribute to it; and no, they don&#8217;t contribute 5% I&#8217;m sure. But WordPress is not foundational to GoDaddy&#8217;s business. They have a dedicated sub-product for it, and they also have many contributors to it.</p>
<p>WP Engine, and many others (including mine), are almost completely or completely reliant on WordPress as a platform. WordPress and its underlying technologies are foundational to our careers and businesses.</p>
<p>It is simply a different story to compare a company that would continue on pretty much fine without WordPress and one that would have to seriously reconsider their entire business model.</p>
<p>For example, let&#8217;s compare the scenario to a publisher. <a href="http://recode.net">Re/code</a> is built on WordPress. They have a staff of 20+. Do they <em>completely rely</em> on WordPress for their website? Yes. For their business model? No. In their scenario, it makes sense for them &#8212; and could benefit them pretty directly &#8212; to allocate some time of some employees to WordPress, but if WordPress disappears they can and will migrate to a different platform.</p>
<h3>Contributing to the full stack</h3>
<p>It was questioned to me on Twitter, after my initial reaction to Ben&#8217;s post, whether I contribute 5% of my time to open source projects like PHP, MySQL, and other tools that WordPress relies on.</p>
<p>This is a good question and point, but it does not cause me to stumble in my opinions. I believe open source contributions in general benefit the entire software stack.</p>
<p>In my scenario, I can be more impactful on the WordPress project than others. But I believe contributions can take many shapes, in both directions.</p>
<p>Some folks, like Daniel Bachhuber, greatly contribute to the project as a whole by supporting upstream projects like <a href="http://wp-cli.org">WP CLI.</a></p>
<p>Automattic is a fantastic example of a company that has both upstream and downstream contributions. They are active contributors to, employers of contributors or founders, or monetary sponsors to a huge number of downstream projects: WordPress, PHP, Nginx, jQuery, Elastic Search, Node, Socket.io, and probably a bunch I can&#8217;t think of or don&#8217;t know about. Additionally, they are a driving force behind dozens of upstream, open source themes and plugins.</p>
<p><em>Edit: Matt <a href="https://twitter.com/photomatt/status/517270097355091968">says in a Tweet</a> where Andrey Savchenko asked for clarification about PHP contributions that Automattic doesn&#8217;t actively contribute to PHP. Though I think I define contribution a bit more loosely than Matt does.</em></p>
<p>Whether a company is contributing to their foundational piece of software, a downstream or upstream application, or on an adjacent aspect that leads to the betterment of the platform that is foundational to their business objectives, then I believe it will in turn be beneficial to their bottom line.</p>
<h3>Contribution as culture</h3>
<p>Contribution should not be considered an isolated cost, but an enabling investment.</p>
<p>If I run a business that relies on a foundational piece of software like WordPress, then it benefits me greatly for my employees &#8212; no matter what role they play within the company &#8212; to be intimately familiar with that software.</p>
<p>In my last job, I was tasked with guiding a transition of my company from developing mostly on a proprietary CMS to WordPress. I consistently preached the importance for everyone in the company to understand some fundamentals of WordPress itself. During my time there and since I&#8217;ve moved on, I&#8217;ve seen other members of that company learn the software, get involved in our local community, and even contribute back to WordPress itself; and both they and the company are better off for it.</p>
<p>Whether an employee is in sales, customer service, design, development, management, or wherever else &#8212; every employee knowing your product is important. I firmly believe this. I would want anyone in an organization I&#8217;m part of to be able to discuss our product in detail and with confidence to anyone.</p>
<p>When your company relies on a foundational piece of software &#8212; such as those we&#8217;re discussing in this post &#8212; that&#8217;s in effect part of your product. We are building products and services around and for WordPress. How important should it be that our company&#8217;s employees understand it?</p>
<p>And how can they understand it better? By contributing of course!</p>
<p>Have a new support rep? Show them the WordPress.org forums to get their feet wet. New designer or front-end developer? Have them sit in on default theme conversations or read through the Make UI blog. New sales person? Get them involved at your local meetup and WordCamp. This list can go on.</p>
<p>Avenues for contribution are an incredible gateway for learning WordPress. Blogging about WordPress (another avenue of contribution) has greatly enabled me to be better at my job, and therefore made me significantly more valuable to the companies I&#8217;ve worked with.</p>
<h3>Five for now</h3>
<p>Matt called his post Five for the Future, and talked specifically about how a 5% investment by a company will ensure a greater future for WordPress and therefore said company. I disagree.</p>
<p>Contributing now will benefit the company and its employees <em>right now</em>. And while both Matt and Ben focused on individuals within the company being targeted contributors, I think it&#8217;s much more beneficial to have a much larger percentage of a company contributing a portion of their time (even if small). I&#8217;d rather see 2 of 200 employees be full time contributors and then have 80 10% contributors than have 10 full time contributors.</p>
<p>I think we&#8217;ve seen many, many examples of contributors (people and companies) reaping tangible and intangible benefits from when they contribute &#8212; whether that contribution is to the codebase or the community. Contributors in this ecosystem come out on top.</p>
<p>Contributions are not an isolated cost or burden. Nor should their effects be limited to good faith investments to the sustainability of the ecosystem.</p>
<p>Contributions benefit the bottom line, and they benefit the bottom line right now.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 06:17:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: Interview With Stream Project Lead, Frankie Jarrett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31664";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wptavern.com/interview-with-stream-project-lead-frankie-jarrett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9745:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/FrankieJarretFeaturedImage.png" rel="prettyphoto[31664]"><img class="aligncenter size-full wp-image-31673" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/FrankieJarretFeaturedImage.png?resize=651%2C246" alt="Frankie Jarrett Featured Image" /></a></p>
<p>Stream 2.0 is a <a title="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service" href="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service">significant update</a> that changes the stand alone plugin into a service. But not everyone is happy with the change. Those who use Stream in enterprise environments have voiced disappointment regarding the latest update. The following is feedback from a user on the <a title="https://www.facebook.com/groups/advancedwp/?fref=nf" href="https://www.facebook.com/groups/advancedwp/?fref=nf">Advanced WordPress Facebook group</a>. &#8220;Heads up if you use Stream. The 2.0 upgrade now stores everything in the cloud instead of the local database and requires a WordPress.com account to use it. It&#8217;s a great plugin but this new functionality is not optional and I can no longer use it with our enterprise data.&#8221;</p>
<p>I reached out to Stream project lead, <a title="http://frankiejarrett.com/" href="http://frankiejarrett.com/">Frankie Jarrett</a>, and asked why the team decided to rely on third-party services. I also inquired whether users have any options to house data on their own servers or connect it to a service of their choosing. Jarrett gives insight into the future of Stream as a Service and let&#8217;s us know if they are working on a version that is compatible with enterprise environments.</p>
<h2>Interview With Frankie Jarrett</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressLogging.png" rel="prettyphoto[31664]"><img class="size-full wp-image-31670" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressLogging.png?resize=640%2C200" alt="WordPRess Logging" /></a>photo credit: <a href="https://www.flickr.com/photos/astro-dudes/1492818224/">Claire L. Evans</a> &#8211; <a href="http://creativecommons.org/licenses/by-nd/2.0/">cc</a>
<p><strong>Jeff &#8211; Why the decision to use an external service by default to offload Stream activity data?</strong></p>
<p>Over the past 10 months we’ve learned a lot about logging events, specifically logging actions taken inside the WordPress Admin. As time went on, some of the biggest concerns we had revolved around the topics of performance and security. It became clear to us that Stream needed to be more than just a plugin to advance into a solid solution, it needed to be a service that was self-contained and lived alongside WordPress instead of trying to force it to work inside the WordPress architecture and never truly being scalable or secure.</p>
<p>MySQL is nice solution for storing content with simple querying, this is how WordPress uses it, but MySQL is actually bad for storing logs, especially if you want to retain them for a long time and/or run complex queries on them while also expecting those queries to be fast. Not to mention, you don’t want the performance of your website’s content to be affected at all. Since the primary purpose of the MySQL database is to store and serve up content to your website visitors, it was our view that should never be hindered by event logging.</p>
<p>Now that Stream is a service, we can use brand new technologies like <a title="http://www.elasticsearch.org/" href="http://www.elasticsearch.org/">Elasticsearch</a>, that are better suited for (and even designed for) querying huge numbers of logs. The result is a more powerful querying performance, the possibility for users to do even more complex queries in the future (for their Reports), and have no worries about keeping logs for a very, very long time. The things we are now doing in Stream 2.0, and plan to do in the future, require the power of Elasticsearch and don’t translate into MySQL storage solutions.</p>
<p>In regards to security, websites and databases get hacked all the time. Unfortunately that’s just the way it is. Since all of Stream’s records had previously lived inside the website, it too was as vulnerable as the website itself. This means that any hacker that gained access could mess up a site and then cover up their tracks by simply deleting the Stream log data. This was a bad thing and meant those logs weren’t really a true security audit trail at all. Now that Stream is a service, those logs are untouchable by an intruder. Once an action is performed, it’s forever in the event history, so the site owner knows without a doubt what things have happened on their site and can go through an undo the damage.</p>
<p><strong>Jeff &#8211; Why the connection between Stream and WordPress.com ID logins?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressStreamConnection.png" rel="prettyphoto[31664]"><img class="size-full wp-image-31671" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressStreamConnection.png?resize=639%2C200" alt="WordPress Stream Connection" /></a>photo credit: <a href="https://www.flickr.com/photos/manchester-monkey/5432450932/">Manchester-Monkey</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>This was an easy decision for us, actually. Over the past few years there have been several WordPress companies that have had their sites hacked and user passwords have been compromised as a result. It’s a sad and unfortunate thing that can be avoided by simply not storing them. Our solution for this was to use SSO (Single sign on) powered by <a title="https://wordpress.com/" href="https://wordpress.com/">WordPress.com</a>.</p>
<p>This means Stream doesn’t have to store any login details for any customer and customers don’t have to sign up for yet another account somewhere. Furthermore, <a title="http://en.support.wordpress.com/security/two-step-authentication/" href="http://en.support.wordpress.com/security/two-step-authentication/">WP.com SSO supports two-factor authentication</a>. This is a huge win for folks who are really concerned about the security of their logins, and we wanted Stream to have this capability.</p>
<p>The reason why we chose WP.com SSO was because of its status and reach in the WordPress community. Stream is a WordPress product and service, so it only makes sense to reach as many WordPress users as possible. When you think about all the people who use Jetpack, Gravatar, Akismet, VaultPress and Polldaddy &#8211; that’s a lot of people. Maybe not everyone, but again, we wanted to make a decisive decision not to store user login credentials at all, and that could mean some people might not be able to use it, but it’s for the good of all our users. WordPress.com SSO was also very easy to implement on our WordPress-powered site compared with the Facebook, Twitter or Google SSO alternatives.</p>
<p><strong>Jeff &#8211; Is the connection between Stream and WordPress.com similar to Jetpack in that some things won’t work without the connection?</strong></p>
<p>The only time Stream needs to talk to WordPress.com is during sign up, for login credentials. Stream doesn’t <em>ping</em> back to your website like Jetpack does. This means your site doesn’t have to be publicly accessible for Stream to work and can be run on a local/development environment without any problems or extra steps needed.</p>
<p><strong>Jeff &#8211; Overall, what are the future plans for Stream now that it’s morphed into a service?</strong></p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/FutureOfStream.png" rel="prettyphoto[31664]"><img class="size-full wp-image-31672" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/FutureOfStream.png?resize=639%2C200" alt="Future of Stream" /></a>photo credit: <a href="https://www.flickr.com/photos/wwarby/9641216546/">wwarby</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a>
<p>Now that we have some scalability, performance and security milestones behind us, we are very much looking forward to making Stream even better in the coming months and years. You might have already noticed, but Stream 2.0 featured built-in integration with eight popular WordPress plugins. We intend to continue making Stream compatible out-of-the-box with tracking things that many other popular plugins do.</p>
<p>Another thing we plan to do is open up a <strong>REST API</strong> for people to be able to access their data and do anything they want with it. This is a very exciting prospect. Finally, we are working on ways to have a complete “mash-up” of all of your Stream data in one place. This is based on a lot of feedback we’ve been getting from folks who run not just multi-site, but multiple single-site installs for their clients and want to see everything that’s happening in one place. We think that will be another huge benefit to people and something that is only possible because Stream is now a service.</p>
<p><strong>Jeff &#8211; One of the complaints I&#8217;ve seen is that Stream&#8217;s reliance on third-party services makes it incompatible with enterprise environments. What is the team doing to address this issue?</strong></p>
<p>The new Stream relies on the power of Elasticsearch for performance and complex queries, but we are exploring ways for the Stream service stack to be run <em>on-premise</em> for Enterprise organizations who have strict internal policies that would require that. We don’t have have an ETA on when this type of solution will be ready, but we are actively pursuing it.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 04:07:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: Stream Morphs From a Plugin Into a Service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31615";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wptavern.com/stream-morphs-from-a-plugin-into-a-service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6231:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2013/12/stream-banner.jpg" rel="prettyphoto[31615]"><img class="aligncenter size-full wp-image-12902" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2013/12/stream-banner.jpg?resize=772%2C250" alt="stream plugin banner" /></a></p>
<p>Stream 2.0 is <a title="https://wp-stream.com/the-new-stream-is-here/" href="https://wp-stream.com/the-new-stream-is-here/">available for download</a> and includes a plethora of enhancements. This version features a rewrite from the ground up with a focus on <em>scalability, security</em>, and <em>activity</em>. As part of the rewrite, Stream activity data is stored in the cloud using <a title="http://aws.amazon.com/" href="http://aws.amazon.com/">Amazon Web Services</a> with <a title="http://www.elasticsearch.org/" href="http://www.elasticsearch.org/">Elasticsearch</a>. This is the same type of setup Jetpack uses to power its <a title="http://jetpack.me/support/related-posts/" href="http://jetpack.me/support/related-posts/">Related Posts</a> module.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConnectToStream.png" rel="prettyphoto[31615]"><img class="size-full wp-image-31654" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConnectToStream.png?resize=989%2C120" alt="Connect To Stream Service" /></a>Request For a WordPress.com ID
<p>The data is stored over an SSL connection making it hard to tap into your activity stream. The Stream team explains the plugin as being the <em>black box</em> of a WordPress site that even the NSA can&#8217;t penetrate. As part of the security enhancements, <span class="wp-stream-tooltip">Stream uses your WordPress.com ID to authorize your account. </span></p>
<p><span class="wp-stream-tooltip">After connecting my WordPress.com ID to Stream, it loaded a <a title="https://wp-stream.com/pricing/" href="https://wp-stream.com/pricing/">Plans and Pricing page</a> in place of the backend instead of just connecting my account. This is unexpected behavior and a disappointing user experience. I ended up having to load the WordPress backend in a new browser tab. </span></p>
<p>I ran into a loop where each time I logged into the backend of WordPress, I&#8217;d see the <strong>Connect to Stream</strong> notification. Each time I clicked the button, it would load the Plans and Pricing page. As it turns out, the reason for the endless loop is because I didn&#8217;t have a subscription registered with the Stream website. Once I completed the process of registering for a free account, the WordPress backend loaded the Stream records screen.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/SuccessfulConnectionToStream.png" rel="prettyphoto[31615]"><img class="size-full wp-image-31655" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/SuccessfulConnectionToStream.png?resize=765%2C336" alt="Successful Connection To Stream" /></a>Successful Connection To Stream
<p>I recommend text be added to the top of the Plans and Pricing page. The text should explain that in order to complete the connection to Stream, a subscription plan needs to be selected. It&#8217;s not obvious and gave me the impression the plugin is broken.</p>
<h2>Support For SMS Notifications Thanks to an Outside Source</h2>
<p>One of the neat features in 2.0 is the ability to set up SMS notifications. For instance, every time a theme, plugin, or WordPress is updated, you can configure Stream to send you a text message.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConfiguringSMSNotifcations.png" rel="prettyphoto[31615]"><img class="size-full wp-image-31656" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConfiguringSMSNotifcations.png?resize=1025%2C552" alt="Configuring SMS Notifications In Stream" /></a>Configuring SMS Notifications In Stream
<p>SMS notifications ended up in 2.0 thanks to the contributing efforts of <a title="https://jeffmatson.net/" href="https://jeffmatson.net/">Jeff Matson</a>. Matson is the author of the <a title="http://wordpress.org/plugins/wp-sms-notifications/" href="http://wordpress.org/plugins/wp-sms-notifications/">WP SMS Notifications</a> plugin <a title="http://wptavern.com/keep-track-of-changes-to-your-wordpress-site-with-the-wp-sms-notifications-plugin" href="http://wptavern.com/keep-track-of-changes-to-your-wordpress-site-with-the-wp-sms-notifications-plugin">we highlighted on the Tavern</a> back in July. Matson explains why he decided to contribute to the Stream project, &#8220;When I created WP SMS Notifications, the biggest comment I received was that I should work with Stream to add my functionality to their plugin. The team behind Stream agreed and I was given access to their Github account. Now, I can proudly say that my code is behind one of the greatest activity tracking plugins out there.&#8221; However, the only way to take advantage of SMS notifications is to use the Pro account which is available for <strong>$2 per month</strong>.</p>
<h2>Older Version of Stream Will Remain Available For Download</h2>
<p>Stream has undergone major changes and is now a service versus a stand alone plugin. For those who don&#8217;t want to update to the new version, the Stream Team is leaving the <a title="https://github.com/wp-stream/stream/releases/tag/1.4.9" href="https://github.com/wp-stream/stream/releases/tag/1.4.9">previous version online</a> via Github. Versions 1.4.9 and below won&#8217;t receive any more updates outside of patching major bugs or security vulnerabilities.</p>
<h2>Overall, a Solid Update</h2>
<p>Stream 2.0 is a solid update. The latest edition supports activity tracking for eight of the most popular WordPress plugins out-of-the box including: Advanced Custom Fields, bbPress, BuddyPress, Easy Digital Downloads, Gravity Forms, Jetpack, WooCommerce and WordPress SEO by Yoast. SMS notification is a great enhancement and I think it&#8217;s respectable of the team to keep 1.4.9 available for those that don&#8217;t like the new direction Stream is heading in.</p>
<p>Are you satisfied with the latest update to Stream? Does using WordPress.com and Amazon Web Services turn you off from using it?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 02:46:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:107:"WPTavern: WordPress Plugin Checks if The Server Hosting Your Site is Vulnerable to The “ShellShock” Bug";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31659";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:111:"http://wptavern.com/wordpress-plugin-checks-if-the-server-hosting-your-site-is-vulnerable-to-the-shellshock-bug";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2910:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockFeaturedImage.png" rel="prettyphoto[31659]"><img class="size-full wp-image-31661" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockFeaturedImage.png?resize=636%2C300" alt="ShellShock Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/tbuser/6076934115/">Tony Buser</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>In recent days, a <a title="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-6271" href="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-6271">security vulnerability</a> in Bash known as &#8220;ShellShock&#8221; has put millions of servers at risk. Without going into too much detail, the vulnerability allows an attacker to execute any code on a vulnerable server. The amount of servers at risk is far greater than the <a title="http://heartbleed.com/" href="http://heartbleed.com/">Heartbleed bug</a> discovered earlier this year. The founder of <a title="https://managewp.com" href="https://managewp.com">ManageWP</a>, Vladimir Prelovac, has released a <a title="https://wordpress.org/plugins/shellshock-check/" href="https://wordpress.org/plugins/shellshock-check/">new WordPress plugin</a> that helps determine if the server hosting your website is vulnerable to the ShellShock bug.</p>
<p>The plugin checks for both disclosed ShellShock vulnerabilities <a href="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-6271">CVE-2014-6271</a> and <a href="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-7169">CVE-2014-7169</a>. Simply download the plugin, activate it, and browse to <strong>Settings &gt; Shellshock.</strong> Click the <strong>Run Test</strong> button. After the test is completed, a notice displays whether the server is vulnerable or not. In the following  screenshot, the server I tested is not vulnerable.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockTestResults.png" rel="prettyphoto[31659]"><img class="size-full wp-image-31660" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockTestResults.png?resize=890%2C229" alt="ShellShock Test Results" /></a>ShellShock Test Results
<p>If the server is vulnerable, take a screenshot and contact your host as soon as possible. Create a trouble ticket. Then, inform the support representative you tested the server and the results show it&#8217;s vulnerable. Attach the screenshot to the trouble ticket with a link to <a title="http://www.troyhunt.com/2014/09/everything-you-need-to-know-about.html" href="http://www.troyhunt.com/2014/09/everything-you-need-to-know-about.html">this article by Troy Hunt</a>, which explains everything they need to know about the bug. After filing the report, create a full back up of your site in case the server is attacked before it&#8217;s patched.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 01:41:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: A New Project by Nick Haskins, WP Status Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31609";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wptavern.com/a-new-project-by-nick-haskins-wp-status-page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3570:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/WPStatusPageFeaturedImage.png" rel="prettyphoto[31609]"><img class="size-full wp-image-31651" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/WPStatusPageFeaturedImage.png?resize=640%2C200" alt="WP Status Page Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/lrosa/560296859/">Luigi Rosa has moved to Ipernity</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>The creator of <a title="http://nickhaskins.com/2014/09/wp-status-page/" href="http://nickhaskins.com/2014/09/wp-status-page/">Aesop Story Engine</a>, Nick Haskins, wants to know if there is <a title="http://nickhaskins.com/2014/09/wp-status-page/" href="http://nickhaskins.com/2014/09/wp-status-page/">any interest in a WordPress plugin</a> that would provide a project status page. After browsing the WordPress plugin directory and coming up empty, Haskins is developing his own solution in the form of a plugin.</p>
<p>He describes the plugin will have a similar setup to <a title="https://www.statuspage.io/" href="https://www.statuspage.io/">StatusPage.io</a>. &#8220;It would definitely have a mechanism to determine if a supplied URL and/or database is down or not. But the page would be more &#8220;alive&#8221; then a static <strong>coming soon page</strong> with the ability to send notifications (email/SMS) to users in addition to showing real-time status updates with a history of events,&#8221; Haskins told the Tavern.</p>
<div>Haskins explains how the plugin would work. &#8220;You&#8217;d provide a subset of items like maybe a URL, database , API endpoint, and we&#8217;d ping that and return the status in a pretty way. I think the key making this really work would be to provide some level of automation as in, a developer could push a commit to Github or Bitbucket with a specific tag that would then automatically update a message status on the status page.</div>
<div></div>
<p>An example of a status page is the Amazon Web Services health dashboard. Haskins says his page will look similar but will have a better design.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/AmazonWebServicesStatusPage.png" rel="prettyphoto[31609]"><img class="size-full wp-image-31649" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/AmazonWebServicesStatusPage.png?resize=814%2C690" alt="Amazon Web Services Status Page" /></a>Amazon Web Services Status Page
<p>One of the issues he brings up is where to host the plugin. It doesn&#8217;t make sense to host a status page on the same server as the project. Instead of forcing users to sign up for a cheap hosting account, Haskins may turn it into a hosted service. One option to consider is using <a title="https://www.openshift.com/" href="https://www.openshift.com/">OpenShift Online</a>. OpenShift has free accounts available and is Red Hat&#8217;s public cloud application development and hosting platform.</p>
<p>If you&#8217;d like to know when the plugin is ready for testing, <a title="http://wpstatuspage.com/" href="http://wpstatuspage.com/">WP Status Page</a> has a splash page available where you can enter your email address to receive updates on the <em>project&#8217;s status</em>.</p>
<p>Is this something you&#8217;d be interested in using? What other ideas or features would you like to see in a status page generation plugin? If you already use a service or have custom coded a solution to provide a status page for your project, please share it in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 21:14:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: Five for the Future";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44176";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/09/five-for-the-future/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3121:"<p>On <a href="http://2014.europe.wordcamp.org/">Sunday at WordCamp Europe</a> I got a question about how companies contribute back to WordPress, how they&#8217;re doing, and what companies should do more of.</p>
<p>First on the state of things: there are more companies genuinely and altruistically contributing to growing WordPress than ever before. In our ecosystem web hosts definitely make the most revenue and profits, and it&#8217;s been great to see them stepping up their game, but also the consultancies and agencies around WordPress have been pretty amazing about their people contributions, as demonstrated most recently by the fact the 4.0 and 4.1 release leads both hail from WP agencies (<a href="http://10up.com/">10up</a> and <a href="http://codeforthepeople.com/">Code for the People</a>, respectively).</p>
<p>I think a good rule of thumb that will scale with the community as it continues to grow is that organizations that want to grow the <a href="http://wordpress.org/">WordPress</a> pie (and not just their piece of it) should <strong>dedicate 5% of their people to working on something to do with core</strong> &#8212; be it development, documentation, security, support forums, theme reviews, training, testing, translation or whatever it might be that helps move WordPress mission forward.</p>
<p>Five percent doesn&#8217;t sound like much, but it adds up quickly. As of today <a href="http://automattic.com/">Automattic</a> is 277 people, which means we should have about 14 people contributing full-time. That&#8217;s a lot of people to not have on things that are more direct or obvious drivers of the business, and we&#8217;re not quite there today, but I&#8217;m working on it and hope Automattic can set a good example for this in the community. I think it&#8217;s just as hard for a 20-person organization to peel 1 person off.</p>
<p>It&#8217;s a big commitment, but I can&#8217;t think of a better long-term investment in the health of WordPress overall. <strong>I think it will look incredibly modest in hindsight.</strong> This ratio is probably the bare minimum for a sustainable ecosystem, avoiding the <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons">tragedy of the commons</a>. I think the 5% rule is one that all open source projects and companies should follow, at least if they want to be vibrant a decade from now.</p>
<p><strong>Further reading:</strong> There&#8217;s been a number of nice blog follow-ups. Post Status has <a href="http://www.poststat.us/contribution-culture/">a nice post on Contribution Culture</a>. Ben Metcalf responded but <a href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/">I disagree with pretty much everything</a> even though I&#8217;m glad he wrote it. Tony Perez wrote <a href="http://perezbox.com/2014/10/wordpress-the-vision-of-five-and-what-it-means/">The Vision of Five and What it Means</a>. Dries Buytaert, the founder of Drupal, pointed out his essay <a href="http://buytaert.net/scaling-open-source-communities">Scaling Open Source Communities</a> which I think is really good.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 19:05:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: WordPress Beyond Boundaries: A Recap of WordCamp Europe 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31620";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9081:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-2014.jpg" rel="prettyphoto[31620]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-2014.jpg?resize=1025%2C469" alt="WordCamp Europe 2014 - photo credit: Vladimir Kaladan Petkov" class="size-full wp-image-31627" /></a>WordCamp Europe 2014 &#8211; photo credit: Vladimir Kaladan Petkov
<p>This weekend, 794 WordPress professionals and enthusiasts from all over the world descended upon Sofia, Bulgaria to participate in Europe&#8217;s largest WordCamp to date. WordCampers arrived excited to soak up new information and connect with others in the European community.</p>
<p>Sofia&#8217;s graffiti-lined streets are peppered with leftovers of communist architecture, contrasting the Neo-Bohemian culture that energizes the city. The event was held in the National Palace of Culture, a magnificent venue situated in the center of Bulgaria&#8217;s capital, designed nearly a decade before the fall of the Iron Curtain. Its halls are lined with murals and dark colors, which created an interesting backdrop for a conference devoted to a bright and growing free software community.</p>
<p>The warm hospitality of the organizers of WordCamp Europe lent an intimate atmosphere to what otherwise might have seemed like an impersonally large event. Attendees enjoyed a world class lineup of WordPress speakers and had the opportunity to try delicious local specialties during breaks and lunch.</p>
<h3>Organizing WordCamp Europe 2014</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-volunteers.jpg" rel="prettyphoto[31620]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-volunteers.jpg?resize=1025%2C485" alt="wceu-volunteers" class="aligncenter size-full wp-image-31631" /></a></p>
<p>WordCamp Europe is an event that requires many months of planning and an army of volunteers to make it happen. Local organizer <a href="https://twitter.com/petyeah" target="_blank">Petya Raykovska</a> helped to organize WordCamp Sofia&#8217;s 300 attendees last year, in addition to being part of the WCEU organizing team. She commented on how welcoming and helpful the Bulgarian community has been in hosting the event. &#8220;We have a bunch of local volunteers who have been amazing. Everybody wants to help,&#8221; she said. <strong>&#8220;But that is WordPress everywhere, not just in Bulgaria. People in WordPress share these same values in common.&#8221;</strong></p>
<p>Out of the event&#8217;s 950 attendees, 240 were Bulgarian, with the vast majority of others from outside the country. WordCamp Europe is made up of an international team of organizers, strategically chosen to unite the different areas of the Europe. The location of the event changes every year and potential host cities have the opportunity to compete for the spot by submitting a proposal and demonstrating support from the local community, much like the Olympics. This year it was a close competition between Lisbon and Sofia.</p>
<p>&#8220;Any local community that has had a WordCamp before has the opportunity to bid,&#8221; explained <a href="https://twitter.com/DeFries" target="_blank">Remkus de Vries</a>, a leader in the Dutch WordPress community and one of the original organizers of WCEU. &#8220;They have to have experience and know how to manage everything.&#8221;</p>
<p>In its first year, WordCamp Europe was held in Leiden, located in Western Europe. &#8220;It&#8217;s not just who has the best story,&#8221; De Vries commented on the selection process. <strong>&#8220;We have an agenda, and the agenda is to unite Europe as best as we can and to have open source be the vehicle.</strong></p>
<p>&#8220;We picked Sofia because we thought it would be good to have Eastern Europe be a part of it. We have a large WordPress community in Romania, Bulgaria, and a few neighboring countries like Serbia and Croatia,&#8221; he said. For them it&#8217;s relatively easy to come here and we wanted to have them here.&#8221;</p>
<h3>No Boundaries: Uniting People Across Borders with WordPress</h3>
<p>The European WordPress community has a checkered history of division. De Vries and fellow organizers founded the event in 2013, with the hopes of uniting different languages, nationalities, and cultures in a way that only WordPress can.</p>
<p>&#8220;Diversity,&#8221; is the one word answer De Vries gave when asked about the distinguishing characteristics of the community. &#8220;We&#8217;ve had a lot of issues with countries not liking each other in the last seven years, and that, in some regard, is somewhat always there,&#8221; he said. &#8220;<a href="https://twitter.com/zedejose" target="_blank">Zé</a> and I had the idea in 2009/2010 that we should have a European WordCamp, for the simple reason that when we went to the other EU WordCamps, we saw that there was the beginning of people looking outside their borders when it came to the WordPress community.&#8221;</p>
<p>De Vries highlighted a few of the differences that the EU community has to overcome. &#8220;If you just look at the way we write, from the Cyrillic alphabet to the Greek to the Latin ones, that&#8217;s a big difference,&#8221; he said. &#8220;Additionally, there are cultural differences between Eastern, Western, Northern and Southern Europe. Obviously you have stuff like that in America as well but this is truly different in a lot of senses. One of our goals was that the local communities would start looking outside of themselves. That&#8217;s exactly what happened.&#8221;</p>
<p>Prior to the first WordCamp Europe, many across the continent kept to their own small communities and didn&#8217;t often travel to connect with each other. De Vries shared an example of how things have changed:</p>
<blockquote><p>I would say Germany is a beautiful example. Germany is a very close knit community, one of the strongest running and one of the oldest, other than the US. Earlier this year WordCamp Hamburg had many foreigners in attendance. That didn&#8217;t happen in Germany in the past. That&#8217;s the big difference. Now they&#8217;re looking outside.</p></blockquote>
<p>Once everyone comes together around WordPress, differences disappear. &#8220;There&#8217;s a funny thing about the people who enjoy WordPress, in the raw sense of the word, is that they tend to be people who like each other in real life,&#8221; De Vries said. &#8220;Which is why I think WordCamps are such a huge success. I can&#8217;t speak that much for other open source communities but I do have a feeling that that&#8217;s something special about the WordPress community.&#8221;</p>
<p>WordCamp Europe is so well-supported that within two or three days, every single sponsor package was sold out, despite the fact that they weren&#8217;t featured very well in the previous year. Companies are still lining up to offer support, because they recognize the value of a unifying event like this in Europe.</p>
<h3>Looking to the Future of WordCamp Europe</h3>
<p>De Vries and many of the core organizing team are in it for the foreseeable future. He&#8217;s addicted to the high of connecting people who might not otherwise have the opportunity to connect with their peers. &#8220;Yes, it costs a lot of time. I have a busy company as well, but I just think it&#8217;s worth it,&#8221; he said.</p>
<p>Why does he continue to put so much time into WordPress? De Vries put it simply. &#8220;WordPress saved my life. It allowed me to come out of a very dark place to make money to provide for my family at a time when I was experiencing something very rough,&#8221; he said. He wouldn&#8217;t have been able to get there without the community surrounding the project.</p>
<p>&#8220;It is the way the software is structured and the way the community is structured around that,&#8221; he said. &#8220;It makes it very easy to jump in anytime. If you put in the hours and you want to learn and understand what it&#8217;s about and translate that into your work, I would say that WordPress is as good as a community can get. So for me, giving back is also part of that. &#8221;</p>
<p>The first year WordCamp Europe sold 750 tickets. This year it reached 950, despite the fact that travel to Bulgaria is more difficult for some. With the exception of a few direct flights, most everyone else has two or three connecting flights to make it to Sofia. &#8220;To see that the attendance has actually risen, I think is a testament to what we&#8217;re doing here,&#8221; De Vries remarked.</p>
<p>When asked if they will expand the event&#8217;s attendance next year, he replied, &#8220;Maybe 1200 would be nice. I think if we pick a location that&#8217;s even more of a direct flight, attendance could go in that direction.&#8221;</p>
<p>But for De Vries, attendance is of less importance than the unifying power of the WordCamp. <strong>&#8220;Attendance is not the end goal. The goal is people of different countries and backgrounds realizing that, in this community, there are no boundaries.&#8221;</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 14:48:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: No Longer Use TimThumb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44172";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2014/09/no-longer-use-timthumb/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:195:"<p>Ben Gillbanks, the co-author of TimThumb, says <a href="http://www.binarymoon.co.uk/2014/07/dont-use-timthumb-instead/">I No Longer Use TimThumb &#8212; Here&#8217;s What I do Instead</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 06:24:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: GoDaddy and Media Temple Engage in Strategic Partnership With WP101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31536";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wptavern.com/godaddy-and-media-temple-engage-in-strategic-partnership-with-wp101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:13362:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101Logo.png" rel="prettyphoto[31536]"><img class="alignright size-full wp-image-31599" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101Logo.png?resize=186%2C96" alt="WP101 Logo" /></a>Customers who host sites with <a title="https://www.godaddy.com/" href="https://www.godaddy.com/">GoDaddy</a> or <a title="http://mediatemple.net/" href="http://mediatemple.net/">Media Temple</a> will see a new WordPress resource in their control panel. Thanks to a <a title="https://www.wp101.com/wp101-godaddy-mediatemple/" href="https://www.wp101.com/wp101-godaddy-mediatemple/">strategic partnership</a> with WP101, GoDaddy and Media Temple customers can watch a 20-part WordPress 101 video tutorial series, directly within the WordPress dashboard.</p>
<p>I reached out to <a title="https://www.wp101.com/" href="https://www.wp101.com/">WP101</a> founder, Shawn Hesketh, to learn more about the partnership and what his thoughts are on the state of WordPress training. He also shares the valuable lessons he learned during the process. Near the end of the interview, he provides a list of resources for those interested in learning WordPress.</p>
<h2>Interview With WP101 Founder, Shawn Hesketh</h2>
<p><strong>Jeff &#8211; How difficult has been for you to keep up with WordPress development through your training videos?</strong></p>
<p>To be perfectly honest with you, I was a bit nervous when I first heard Matt Mullenweg <a title="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/" href="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/">outline a strategy</a> for increasingly rapid releases, eventually leading to constant background updates to WordPress at some point in the near future. But so far, it&#8217;s been fairly manageable, as we&#8217;ve only seen an additional one or two revision cycles in a given year.</p>
<p>I&#8217;ve given a great deal of thought to how we might continue to keep the <a title="https://www.wp101.com/courses/wordpress101/" href="https://www.wp101.com/courses/wordpress101/">WordPress 101 tutorial series</a> up-to-date should WordPress move to more transparent and automatic updates. But for the time being, we should be able to continue updating and re-recording our videos with each major release.</p>
<p>I continually monitor the WordPress development blog, Trac, and the IRC channel, which helps me stay abreast of coming changes and prepare ahead of time as much as possible. Without access to those invaluable resources, it would be quite a challenge.</p>
<p><strong>Jeff &#8211; As WordPress continues to grow, WordPress Training continues to be a business in high demand. How have you differentiated yourself from the other trainers/coaches out there?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/CMSMarketShareWordPress.png" rel="prettyphoto[31536]"><img class="size-full wp-image-31603" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/CMSMarketShareWordPress.png?resize=698%2C291" alt="CMS MarketShare report" /></a>Marketshare via OpensourceCMS.com 9/29/2014
<p>It certainly helps that WP101 was one of the first WordPress video tutorial series to be launched, way back in 2008, at a time when almost no one was providing high-quality WordPress tutorial videos. Since then, we&#8217;ve certainly seen a number of other sites emerge to address the growing need for WordPress education, not only for beginners, but also intermediate and advanced users.</p>
<p>Still, the feedback I receive almost daily is that the WP101 videos are some of the best-produced, easy-to-follow video tutorials for beginners. I&#8217;ve spoken about this in the past, but I maintain that fanatical attention to detail and careful craftsmanship can still help differentiate you from competitors, no matter what product or service you provide.</p>
<p>Finally, I don&#8217;t create my tutorials in a vacuum. Rather than simply producing what <strong>I</strong> think will work best, I&#8217;m constantly listening to input and feedback from our audience, developers, and beginners alike revising the WP101 series, improving it with each release. I think it&#8217;s this commitment to building meaningful, long-term relationships and serving our audience that continues to set WP101 apart.</p>
<p><strong>Jeff &#8211; What challenges did you face in making this strategic partnership a reality?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101-GoDaddy-MediaTemple.jpg" rel="prettyphoto[31536]"><img class="size-full wp-image-31601" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101-GoDaddy-MediaTemple.jpg?resize=900%2C500" alt="WP101 Partnership" /></a>Image Courtesy of WP101
<p>The partnership with GoDaddy and Media Temple is a great example of the importance of long-term relationship building. We spent the first several weeks in conversations about the challenges they faced with regard to on-boarding new WordPress users. It was only after I had a clear understanding of their challenges that we began to explore the best way to put the WP101 videos to work for their customers.</p>
<p>Although it may appear on the surface to be a relatively simple solution, it was actually the product of several months of hard work, both in terms of developing the custom software required and arriving at a pricing model that worked for both parties.</p>
<p>To be honest, I didn’t expect the process to take several months to fully materialize, but this was never about a quick win. From the beginning, we were all working toward the best solution, not just for our two companies, but ultimately for their customers.</p>
<p><strong>Jeff &#8211; Did you learn any lessons that others can use when trying to partner with large, well-established brands and or companies?</strong></p>
<p><em>Have patience</em>. Don&#8217;t underestimate the amount of time you (or your legal team) will spend carefully crafting an agreement that is truly a win/win.</p>
<p>It&#8217;s true that the best agreements are those in which <em>both</em> parties feel that they came out ahead. But as with anything of lasting value, it takes time. Time spent in conversations that results in a clear understanding of the desired outcome. Time spent carefully crafting a custom solution, rather than simply applying a quick fix. And throughout the entire process, keeping an eye firmly fixed on the end goal, which is ultimately to better serve the customer.</p>
<p><em>Communicate clearly</em>. When there are large teams of people involved, it&#8217;s easy to get lines crossed. I’m a big fan of UIHD (<a title="http://unlessiheardifferently.com/" href="http://unlessiheardifferently.com/">Unless I Hear Differently</a>). It helps everyone involved stay crystal clear on roles and timeframes, who’s doing what, and when. It helps eliminate downtime due to unnecessary communication cycles. Keep emails simple, limited to just one question at a time, and close every communication with, &#8220;<em>Unless I hear differently…</em>&#8221;</p>
<p>Finally, don&#8217;t underestimate the importance of finding a great attorney, which also takes time. I&#8217;ve worked with general business attorneys in the past, but it&#8217;s another matter altogether to find an attorney who understands the intricacies of licensing intellectual property for online distribution. I went through several recommendations before finally finding a local attorney who had the understanding and expertise to craft the agreement we needed.</p>
<p><strong>Jeff &#8211; Last but not least, when you take a step back and look at the big picture, what do you see in terms of the WordPress training landscape?</strong></p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/LandscapeHorizon.png" rel="prettyphoto[31536]"><img class="size-full wp-image-31602" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/LandscapeHorizon.png?resize=638%2C280" alt="Landscape WordPress Training Horizon" /></a>photo credit: <a href="https://www.flickr.com/photos/jixxer/8238528131/">Kristofer Williams</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>It&#8217;s an exciting time to be a WordPress educator. The increasing popularity of WordPress means there is also a growing demand for WordPress training. There have never been more educational resources available for nearly every level of expertise.</p>
<p>From written tutorials and code snippets on individual blogs to personalized, one-on-one coaching, there is a wide variety of training available for just about every learning style. The WordPress community is filled with knowledgeable, friendly people who are willing to share their knowledge with others.</p>
<p>But with so many resources out there, it can also be challenging, particularly for beginners, to separate the good from the bad. How do you know whether a tutorial is accurate, reliable, or up-to-date?</p>
<p>With powerful tools like <a title="http://screenflow.en.softonic.com/mac" href="http://screenflow.en.softonic.com/mac">ScreenFlow</a> and <a title="http://www.techsmith.com/camtasia.html" href="http://www.techsmith.com/camtasia.html">Camtasia</a>, it’s never been easier to create screencast tutorials. But it&#8217;s increasingly difficult to ensure they’re continually up to date with each new release of WordPress.</p>
<p>In the six years since I launched WP101, I&#8217;ve updated and re-recorded my WordPress 101 series <strong>12 times</strong>. During that same period of time, I’ve seen several tutorial sites come and go. Their content becomes out-of-date after just one or two release cycles. As I mentioned earlier, it’s only going to become more challenging as WordPress continues to release updates more rapidly.</p>
<p>So, it’s hard work, and quite tedious at times, but for those of us who truly enjoy the reward of teaching others how to use WordPress, it’s also a labor of love. But one of the things that excites me the most is the spirit of “co-opetition” that exists in the WordPress community.</p>
<h3>Resources Hesketh Recommends for Learning WordPress</h3>
<p>Some people learn best by reading. So I often recommend the excellent books by <a title="http://www.amazon.com/WordPress-Web-Developers-Introduction-Professionals/dp/1430258667" href="http://www.amazon.com/WordPress-Web-Developers-Introduction-Professionals/dp/1430258667">Stephanie Leary</a>, <a title="http://lisasabin-wilson.com/books/" href="http://lisasabin-wilson.com/books/">Lisa Sabin-Wilson</a>, or <a title="http://www.amazon.com/Professional-WordPress-Development-Brad-Williams/dp/111844227X" href="http://www.amazon.com/Professional-WordPress-Development-Brad-Williams/dp/111844227X">Brad Williams and team</a>.</p>
<p>Others learn best through one-on-one training, so I send them to <a href="http://bobwp.com">BobWP</a>.</p>
<p>There&#8217;s the ever-growing library of <a href="http://webdesign.com">web design webinars</a> by my friends at iThemes.</p>
<p>I’m excited about the possibilities of <a href="http://www.sidekick.pro">SIDEKICK</a> for helping developers to create custom interactive walkthroughs.</p>
<p>Nobody has a larger library of written tutorials than <a href="http://www.wpbeginner.com">WPBeginner</a>.</p>
<p>Of course, there are plugins like <a href="http://www.videousermanuals.com">Video User Manuals</a>, or our own <a href="http://wp101plugin.com">WP101 Plugin</a> that enable developers to provide WordPress tutorials directly in their clients&#8217; dashboard.</p>
<p>To say nothing of learning sites like <a href="http://Lynda.com">Lynda.com</a> or <a href="http://teamtreehouse.com">Treehouse</a>.</p>
<p>With our new partnership with GoDaddy and Media Temple, we’re starting to provide valuable WordPress training right where customers need it most, in their own WordPress dashboard.</p>
<p>Not a day goes by that I don’t recommend one or more of these excellent learning resources if I feel they might be the best fit for someone and many, if not all, of these folks do the same for WP101. This creates an environment in which everyone wins. Most importantly the individuals who just want to learn how to use WordPress to build a gorgeous blog or compelling business site.</p>
<p>In a perfect world, WordPress would be so intuitive where no training or manual would be required. Until then, we’ll be there to help fill in the gaps, answer questions, and help folks learn how to use WordPress as quickly as possible.</p>
<h2>A Win-Win Situation</h2>
<p>As the WordPress training scene becomes increasingly crowded, it&#8217;s becoming more difficult to differentiate between all of the resources available. Partnering with a webhosting company is an excellent way for WordPress training materials to be seen by thousands of customers who might not otherwise be aware of their existence.</p>
<p>The material also provides an opportunity to lessen the support burden. As customers learn the basics of WordPress, the support team can dedicate more resources towards difficult support queries.</p>
<p>If you&#8217;re a GoDaddy or Media Temple customer, let us know what you think of the videos in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 21:31:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: Ben Gillbanks Announces The End of TimThumb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31588";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wptavern.com/ben-gillbanks-announces-the-end-of-timthumb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5202:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/TimThumbEndsFeaturedImage.png" rel="prettyphoto[31588]"><img class="size-full wp-image-31592" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/TimThumbEndsFeaturedImage.png?resize=637%2C289" alt="TimThumb Ends Development " /></a>photo credit: <a href="https://www.flickr.com/photos/katy_bird/6661402027/">katybird</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>The once popular image resizing script known as TimThumb is <a title="http://www.binarymoon.co.uk/2014/09/timthumb-end-life/" href="http://www.binarymoon.co.uk/2014/09/timthumb-end-life/">no longer supported</a> according to co-creator, Ben Gillbanks. In 2011, <a title="http://www.binarymoon.co.uk/2011/08/timthumb-2/" href="http://www.binarymoon.co.uk/2011/08/timthumb-2/">TimThumb made headlines</a> when a major security vulnerability was discovered and used to hack into several websites.</p>
<blockquote><p>The exploit that was found was a bug with the external image resize functionality and the fact it could be used to download and execute files. There was code in place that restricted the downloads to a whitelist of clean sites, but it wasn’t strict enough and so a hole was found that could inject php onto your server.</p></blockquote>
<p>In 2009, <a title="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/" href="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/">Gillbanks estimated</a> that 95% of commercial WordPress themes supported TimThumb. Several major commercial theme companies such as WooThemes, <a title="http://www.woothemes.com/2011/08/timthumb-security-flaw-patch/" href="http://www.woothemes.com/2011/08/timthumb-security-flaw-patch/">used the script</a> in most of its products. This set the stage for thousands of sites to be affected by the vulnerability.</p>
<p>The outcome of the event has weighed heavily on Gillbanks and is one of the primary reasons he&#8217;s giving up development.</p>
<blockquote><p>In particular in 2010 there was <a href="http://www.binarymoon.co.uk/2011/08/timthumb-2/">a major security exploit</a> found and it hurt a lot of websites, my own included. There are still people who are suffering because of it. I’ve felt incredibly guilty about this for years now, and so my enthusiasm for TimThumb has dropped to nothing.</p>
<p>Because of this lack of enthusiasm, and a fear of doing something else wrong, I have barely touched the code in years.</p></blockquote>
<p>If you&#8217;re using TimThumb, Gillbanks <a title="http://www.binarymoon.co.uk/2014/07/dont-use-timthumb-instead/" href="http://www.binarymoon.co.uk/2014/07/dont-use-timthumb-instead/">recommends removing it</a> and using something else. An excellent alternative is the <a title="http://matthewruddy.github.io/Wordpress-Timthumb-alternative/" href="http://matthewruddy.github.io/Wordpress-Timthumb-alternative/">WordPress TimThumb Alternative</a> on Github. Created by Matthew Ruddy, the function uses WordPress&#8217; native resizing functions to mimic TimThumb resizing.</p>
<h2>Timeline of Notable Events</h2>
<p>The following is a timeline of notable events surrounding TimThumb. Feel free to add more in the comments.</p>
<ul>
<li>March 27th, 2008 &#8211; TimThumb added to <a title="https://code.google.com/p/timthumb/source/list?num=25&start=20" href="https://code.google.com/p/timthumb/source/list?num=25&start=20">Google Code</a></li>
<li>July 6th, 2009 &#8211; Ben Gillbanks <a title="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/" href="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/">takes over development</a> of the script</li>
<li>August 1st, 2011 &#8211; Mark Mauder reports a major vulnerability in TimThumb and <a title="http://markmaunder.com/2011/08/01/zero-day-vulnerability-in-many-wordpress-themes/" href="http://markmaunder.com/2011/08/01/zero-day-vulnerability-in-many-wordpress-themes/">releases WordThumb</a>, a fork of TimThumb with the necessary patched files. The patches are merged into TimThumb during the development of 2.0</li>
<li>August 8th, 2011 &#8211; Matt Mullenweg <a title="http://ma.tt/2011/08/the-timthumb-saga/" href="http://ma.tt/2011/08/the-timthumb-saga/">chimes in</a> on the TimThumb saga</li>
<li>August 11th, 2011 &#8211; <a title="http://www.binarymoon.co.uk/2011/08/timthumb-2/" href="http://www.binarymoon.co.uk/2011/08/timthumb-2/">TimThumb 2.0 Released</a></li>
<li>June 24th, 2014 &#8211; Zero-Day vulnerability <a title="http://wptavern.com/wordpress-security-alert-new-zero-day-vulnerability-discovered-in-timthumb-script" href="http://wptavern.com/wordpress-security-alert-new-zero-day-vulnerability-discovered-in-timthumb-script">discovered</a> in TimThumb script dealing with Webshots</li>
<li>September 27th, 2014 &#8211; Ben Gillbanks announces that he will no longer support or maintain TimThumb</li>
</ul>
<p>With the development of TimThumb being discontinued, it&#8217;s the end of an era for WordPress theme development. Are you happy or sad to see it go? Since TimThumb has an open source license, will developers pick up where Gillbanks left off?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 19:19:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: Hemingway on Writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44162";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2014/09/hemingway-on-writing/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:664:"<blockquote><p>I believe that basically you write for two people; yourself to try to make it absolutely perfect; or if not that then wonderful. Then you write for who you love whether she can read or write or not and whether she is alive or dead.</p></blockquote>
<p><cite>&#8212; Ernest Hemingway to Arthur Mizener, 1950 Selected Letters, p. 694.</cite></p>
<p>I got it from <a href="http://smile.amazon.com/dp/B000FC0O1I/">Hemingway on Writing</a> which is a short and pleasant read I&#8217;m going through right now. It turns out <a href="http://ma.tt/2014/01/intrinsic-blogging/">Hemingway was 64 years ahead of me in his advice about who to write for</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 13:46:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"Lorelle on WP: Research on the WordPress, Web Development, and Web Design Job Market";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11928";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:108:"http://lorelle.wordpress.com/2014/09/29/research-on-the-wordpress-web-development-and-web-design-job-market/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:499:"In 2012 and 2013, I did extensive research for the grant program to develop and rewrite the Web Developer degree program at Clark College. This research included an analysis of current and future job opportunities for students graduating with that degree with a solid understanding of WordPress. Now that the program has completed its first [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11928&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 11:35:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Meet John Blackbourn, WordPress 4.1 Release Lead";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31547";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5717:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/john-blackbourn.png" rel="prettyphoto[31547]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/john-blackbourn.png?resize=1025%2C473" alt="John Blackbourn speaking at WordCamp London 2013 - WordPress.tv" class="size-full wp-image-31552" /></a>John Blackbourn speaking at WordCamp London 2013 &#8211; <a href="http://wordpress.tv/2014/02/28/john-blackbourne-developing-for-the-new-media-manager/">WordPress.tv</a>
<p>Nine years ago, <a href="https://johnblackbourn.com/" target="_blank">John Blackbourn</a> was stocking shelves at a supermarket 40 hours per week and returning home to do another 20 hours of freelance work on the side. His journey with WordPress started much like many others, when his first patch was accepted seven years ago. This past weekend at WordCamp Europe, Blackbourn was named <a href="https://make.wordpress.org/core/2014/09/27/john-blackbourn-is-leading-wordpress-4-1-and-announcing-new-committers/" target="_blank">WordPress 4.1 release lead</a>.</p>
<p>&#8220;I&#8217;m sure my first contribution was because I found a bug that annoyed me, so I thought I&#8217;ll patch that up and get it in there,&#8221; he said. Submitting bug reports led him to learn about Subversion, patching files, and the trac ticket manager. &#8220;That&#8217;s actually a great way for people to get into version control &#8211; when someone turns around and says &#8216;Write a patch for it,&#8217; and you have to go off and figure out how to do it.&#8221;</p>
<p>It started off as a hobby, Blackbourn said, &#8220;building my own websites and playing around a bit.&#8221; After awhile his freelance work started to take off. &#8220;Then I was lucky enough to be able to drop my hours down to part time while I ramped up my freelance work,&#8221; he said. A couple years later, he got a job at <a href="http://codeforthepeople.com/" target="_blank">Code For The People</a>, a WordPress development agency and WordPress.com VIP partner.</p>
<p>Code for the People is made up of a flock of regular contributors to WordPress core, with founders who are passionately committed to giving back to open source software. When Blackbourn was put forward to lead the 4.1 release, his agency was behind him 110%.</p>
<p>&#8220;I had previously talked to Andrew Nacin about leading 3.9 and 4.0 and he&#8217;d already spoken to my bosses at Code For The People. They said, &#8216;Yeah go for it &#8211; we&#8217;ll give you time off work, adequate resources, and time to lead it.\'&#8221;</p>
<p>Simon Wheatley, one of the founders of CFTP, spoke at WordCamp Europe about running an open source business, during which his co-founder, Simon Dickson, <a href="https://twitter.com/simond/status/515834467781730304" target="_blank">commented</a> on donating Blackbourn&#8217;s time to core. <strong>&#8220;CFTP is a small team. Contributing John Blackbourn to WP Core won&#8217;t make our lives easy. But it&#8217;s important to us. We&#8217;ll find a way,&#8221;</strong> he said.</p>
<h3>What&#8217;s on the horizon for WordPress 4.1?</h3>
<p>This will be the first time that Blackbourn has led a release, although he has been a core committer for both 3.9 and 4.0. WordPress 4.1 will be a short release cycle, with less than three months, due around December 12th. He shared a few ideas with us about where he thinks 4.1 will be heading.</p>
<blockquote><p>We&#8217;re going to try to reign in expectations for the release so we&#8217;re going to get a few nice things to do with session management and password security, etc. If we keep the potential features reigned in a bit, then hopefully we won&#8217;t be needing to take weeks off work. I expect to be doing a couple days a week that I would normally be working.</p></blockquote>
<p>Blackbourn hopes to further extend the improvements to sessions that were made in the previous release. &#8220;The new thing in WP 4.0 is the sessions &#8211; when you log in, you actually get assigned a session now, so you can forcibly log one of your sessions out,&#8221; he explained. &#8220;So if I&#8217;m logged in on my laptop and my phone I can kick myself out of one or the other.&#8221; This now exists in WordPress on an API level and Blackbourn is hopeful that 4.1 will add a UI for it.</p>
<p>He has extensive experience working with multisite on a daily basis at CFTP. &#8220;We haven&#8217;t got many clients who don&#8217;t use multisite these days,&#8221; he said. When asked if there are any multisite improvements planned for 4.1, he said that there may not be much time to make significant strides on the <a href="https://make.wordpress.org/core/2013/10/06/potential-roadmap-for-multisite/" target="_blank">roadmap</a>. However, he&#8217;s optimistic about including improvements related to <a href="http://wptavern.com/wordpress-4-0-targeted-to-fix-multisite-new-user-password-security-issues" target="_blank">multisite password resets</a>.</p>
<p>Since it&#8217;s his first time to lead a release, Blackbourn plans to meet with several past release leads in attendance at WordCamp Europe in order to get an overview of how it&#8217;s done. He&#8217;s one of the most humble, talented people I had the privilege of meeting at the event. <a href="http://wptavern.com/query-monitor-a-remarkably-comprehensive-debugging-plugin-for-wordpress" target="_blank">Query Monitor</a>, his comprehensive WordPress debugging plugin, is truly a work of art, and many developers can no longer live without it. Blackbourn is a benefit to the project and an excellent example of a WordPress professional who has become a high-end expert by sharpening his skills through contribution to core.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 28 Sep 2014 22:18:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Matt: 4.0 Recap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44167";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:31:"http://ma.tt/2014/09/4-0-recap/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:410:"<p>If you want to see some of the thought and care that went into the <a href="https://wordpress.org/news/2014/09/benny/">WordPress 4.0 release</a>, check out <a href="http://scotty-t.com/2014/09/04/wordpress-4-0-under-the-hood/">Scott Taylor&#8217;s peek under the hood</a> and <a href="http://helenhousandi.com/2014/09/wordpress-4-0-an-easter-egg/">Helen Hou-Sandi&#8217;s reveal of a 4.0 Easter egg</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 28 Sep 2014 05:10:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: Sedaris on Fitbit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44160";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2014/09/sederis-on-fitbit/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:229:"<p><a href="http://www.newyorker.com/magazine/2014/06/30/stepping-out-3">David Sedaris in the New Yorker on how his Fitbit took over his life.</a>. <cite>Hat tip: <a href="http://jeremeyduvall.com/">Jeremey Duvall</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 27 Sep 2014 12:03:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: WPWeekly Episode 163 – Interview With Andrea Middleton of WordCamp Central";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=31451&preview_id=31451";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wptavern.com/wpweekly-episode-163-interview-with-andrea-middleton-of-wordcamp-central";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3942:"<p>In this episode,<a title="http://marcuscouch.com/" href="http://marcuscouch.com/"> Marcus Couch</a> and I are joined by <a title="http://wine-scamp.com/" href="http://wine-scamp.com/">Andrea Middleton</a> who manages <a title="http://central.wordcamp.org/" href="http://central.wordcamp.org/">WordCamp Central</a>. She tells us what it means to be a &#8220;dot organizer&#8221; within Automattic and what her day to day duties are managing WordCamp Central. We discuss whether the WordCamp Guidelines allow for differentiation between WordCamps. Middleton explains the various initiatives in place to help first-time organizers with planning their event. Last but not least, we talk about the importance of sponsorships and how they&#8217;ve enabled WordCamps to be affordable to the general public.</p>
<p><strong>WordCamp Resource Material</strong>:</p>
<ul>
<li><a title="http://central.wordcamp.org/schedule/" href="http://central.wordcamp.org/schedule/">Upcoming WordCamps</a></li>
<li><a title="http://plan.wordcamp.org/" href="http://plan.wordcamp.org/">WordCamp Planning Site</a></li>
<li><a title="http://plan.wordcamp.org/forums/" href="http://plan.wordcamp.org/forums/">WordCamp Forums</a></li>
</ul>
<h2>Stories Discussed:</h2>
<p><a title="http://wptavern.com/buddypress-2-1-patsy-released" href="http://wptavern.com/buddypress-2-1-patsy-released">BuddyPress 2.1 Patsy Released</a><br />
<a title="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords" href="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords">iThemes Suffers Security Breach, Customers Urged To Reset Passwords</a><br />
<a title="http://wptavern.com/netropolitan-facebook-for-rich-people-is-powered-by-wordpress-and-buddypress" href="http://wptavern.com/netropolitan-facebook-for-rich-people-is-powered-by-wordpress-and-buddypress">Netropolitan “Facebook for Rich People” is Powered by WordPress and BuddyPress</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a title="https://wordpress.org/plugins/admin-branding/" href="https://wordpress.org/plugins/admin-branding/">Admin Branding</a> &#8211; Completely brand the admin dashboard and login screen through easy and straight forward controls. You can do advanced customizations and branding by adding your own CSS and JavaScript. Fits both regular users and developers.</p>
<p><a title="https://wordpress.org/plugins/coursepress/" href="https://wordpress.org/plugins/coursepress/">CoursePress</a> &#8211; CoursePress turns WordPress into a powerful online learning platform. Set up online courses by creating learning units with quiz elements, video, audio etc. You can also assess student work, sell your courses and much more.</p>
<p><a title="https://wordpress.org/plugins/widget-menuizer/" href="https://wordpress.org/plugins/widget-menuizer/">Widget Menuizer</a> &#8211; Widget Menuizer makes it possible to embed sidebars within your site&#8217;s menus. Anything you can do with a widget can now be done inside your menus. This makes the menu system much more powerful, as it allows for easy creation of sophisticated &#8220;mega dropdowns&#8221; and other menu fanciness without completely overhauling the menu management system into something unfamiliar.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, October 1st 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #163:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 27 Sep 2014 01:39:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Reader Poll: What Are Your Favorite Features In WordPress 4.0?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31525";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wptavern.com/reader-poll-what-are-your-favorite-features-in-wordpress-4-0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2166:"<p>Since the release of WordPress 4.0, users have had nearly a month to get used to its new features. It&#8217;s time to find out which ones are your favorite. My favorite features are the sticky toolbar, oEmbed previews in the visual editor, and the overall improvements to the writing experience. I&#8217;ve found the sticky toolbar is especially useful on smaller screens.</p>
<p>If you select not listed, please use the comments to tell us what it is.</p>
Note: There is a poll embedded within this post, please visit the site to participate in this post\'s poll.
<h2>WordPress 4.1 Development to Kickoff on Monday</h2>
<p>As we get used to the improvements in 4.0, development on WordPress 4.1 is <a title="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/" href="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/">about to get underway</a>. The first meeting to discuss WordPress 4.1 will be on Monday, September 29, at 1400 UTC. Also note that the Wednesday meeting (October 1) is still on for 2000 UTC as well. Since time zones can be difficult to figure out, Andrew Nacin provided further clarification on the exact time.</p>
<ul>
<li>10am U.S. Eastern (GMT-4), 7am U.S. Pacific (GMT-7).</li>
<li>This is midnight Tuesday for the East Coast of Australia (GMT+10).</li>
<li>If you’re at WordCamp Europe’s contributor day (GMT+3), this will be 5pm.</li>
</ul>
<p>The meeting takes place on IRC in the #<strong>wordpress-dev</strong> channel. If you don&#8217;t have access to an IRC client, you can use a web-based client at <a title="http://webchat.freenode.net/" href="http://webchat.freenode.net/">webchat.freenode.net</a>. If there is a particular feature you&#8217;d like to see in 4.1 or have a plugin you&#8217;d like to see merged into core, say so in the meeting or within the <a title="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/" href="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/">comment section</a> of the announcement.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 21:56:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: WordPress.com Publishes First Ever Video Ad Entitled “Welcome Home”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31515";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wptavern.com/wordpress-com-publishes-first-ever-video-ad-entitled-welcome-home";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4258:"<p>WordPress.com released a new video on its <a title="https://www.youtube.com/channel/UCiR2d9r3QkBwuNVS8nqGNgg" href="https://www.youtube.com/channel/UCiR2d9r3QkBwuNVS8nqGNgg">YouTube account</a> entitled <a href="https://www.youtube.com/watch?v=MfW2UJMIQvQ&feature=youtu.be"><strong>Welcome Home</strong></a>. In the 15 second video, featuring music from <a title="http://childishgambino.com/" href="http://childishgambino.com/">Childish Gambino</a>, photos are taken with a iPhone in various locations. Near the end of the video, the WordPress app is opened displaying a post with one of the images captured by the phone. The central theme of the video is to <strong>create your home on the web at <a title="http://wordpress.com/" href="http://wordpress.com/">WordPress.com</a></strong>.</p>
<p><span class="embed-youtube"></span></p>
<p>My initial reaction to the video is that it puts too much emphasis on photos. It makes it seem like the WordPress app is only capable of sharing photos similar to <a title="https://www.flickr.com/" href="https://www.flickr.com/">Flickr</a> or <a title="http://instagram.com/#" href="http://instagram.com/">Instagram</a>. A home on the web has more than just photos, something that doesn&#8217;t come across in the 15 second message.</p>
<p>Something else I find odd is the choice to highlight the app versus WordPress.com. There&#8217;s no mention or video of the WordPress.com user interface or other aspects of the site. As WordPress.com likes to do, this video is likely an experiment but in my opinion, fails to deliver on their central message. It&#8217;s aimed at too narrow of an audience and doesn&#8217;t adequately show off what WordPress.com is truly capable of. Granted, we&#8217;re talking about 15 seconds of video which is why I&#8217;d like see what the team creates if given one minute to get the point across.</p>
<p>Just for the sake of comparison, watch this SquareSpace ad. It&#8217;s a minute long, more to the point, and delivers on the message of creating a home on the web or in this case, creating your own space. The ad also does a good job of showing how the service can be used on various devices. When I watch this ad, I feel like people from all walks of life are able to easily create a site through SquareSpace.</p>
<p><span class="embed-youtube"></span></p>
<h2>Jon Burke Provides Context For The Video</h2>
<p>In an effort not to cloud my judgement and reaction to the video, I reached out to Jon Burke, who works for Automattic, after publishing this post and received more information concerning the video.</p>
<p><strong>Is the video actually a commercial or more or less an experiment?</strong></p>
<p>WordPress.com has a freemium model and we run house ads. We have been running this video as a promotion on free sites. This video is part of a series. This video focuses on the utility of photos and the mobile apps. Other videos we are producing will focus on other aspects of WordPress.com.</p>
<p>The video is brief for a couple of reasons. We don&#8217;t want to interrupt the site viewers&#8217; experience for too long and we wanted it to be viewable by our visitors where English is not the primary language.</p>
<p>So it is a commercial, but we are also experimenting with different videos about WordPress.com to see how we can best get our message out in a way that is organic with the culture of Automattic and the WordPress community.</p>
<p><strong>Is it aimed towards raising awareness of the WordPress mobile app or WordPress.com?</strong></p>
<p>This video is focused on our mobile apps. The comparison to the SquareSpace video is a fair one but our ambition is to get our message across better in a dozen videos rather than in a single, longer video. We create a lot of products and have a number of services and don&#8217;t think we can cover it all well in a single short video.</p>
<h2>Now It Makes Sense</h2>
<p>The explanation provided by Burke provides the missing context surrounding the video. The video now makes perfect sense in that it&#8217;s part of a series with plans to produce more like it focusing on other areas of WordPress.com. This information completely changes my tune. Instead of failing to deliver the message, it&#8217;s on point.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 20:02:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:94:"WPTavern: Ryan Hellyer’s AWS Nightmare: Leaked Access Keys Result in a $6,000 Bill Overnight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31497";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wptavern.com/ryan-hellyers-aws-nightmare-leaked-access-keys-result-in-a-6000-bill-overnight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9568:"<p>WordPress developer <a href="http://geek.ryanhellyer.net/" target="_blank">Ryan Hellyer</a> had always wanted to open source his website. As a strong supporter of open source software and an avid plugin developer, he enjoys sharing his code and learning from others. This desire led him to put his site up on GitHub one evening, not knowing that he would wake to find himself in a security nightmare due to a simple oversight.</p>
<p>Open sourcing a website is not such an uncommon practice, as it brings with it a number of benefits. Hellyer shared his story with the Tavern and identified the main reasons wanted to make his site&#8217;s code public on GitHub:</p>
<ol>
<li>It allows people to see what plugins and themes I use</li>
<li>It makes it super easy to get help with my website, since people can see the code</li>
<li>It encourages me to use best practices across my entire website, not just the bits I post for download (custom plugins, themes etc.)</li>
<li>It is a handy way to sync the files between locations</li>
</ol>
<p><strong>&#8220;I was aware that keeping my wp-config.php file off of GitHub was critical,&#8221;</strong> Hellyer said.</p>
<p>&#8220;Leaving that open for download would also make my database credentials, security salts etc. known to attackers. To mitigate this, I simply moved it one folder down (it still works even when it&#8217;s not in the root of your site). As a double protection, I also used the .gitignore file to forcibly prevent Git from pushing it to the repository.&#8221;</p>
<p>Satisfied that his website was totally backed up and thinking that he had taken all the necessary security precautions, Hellyer pushed all the contents of his site (with the exception of the uploads directory) to a new GitHub repository. Pleased with his efforts, he dozed off to sleep.</p>
<h3>An Urgent Message Arrives from Amazon</h3>
<p>Not four hours later, Hellyer received an urgent message from Amazon, though he didn&#8217;t have the chance to read it until later in the morning.</p>
<p>&#8220;I awoke fresh the next morning, began work for the day, then decided to check my personal email account and saw the email I had received overnight,&#8221; he said. &#8220;The email was marked URGENT.&#8221;</p>
<p>Hellyer initially thought it was spam but went with his instinct and opened it anyway, as it appeared to be fairly legitimate. Amazon emailed to notify him that his account may have been compromised.</p>
<p>&#8220;I immediately went to check my AWS billing page, but thankfully it was only at US$17 for the month so far, which was about my normal usage,&#8221; he said, noting that he uses AWS (Amazon Web Services) for backing up to Amazon S3 and for providing a CDN service to his website (via Amazon Cloudfront).</p>
<p>The email specifically asked him to check his EC2 instances, which Hellyer found to be odd, since he doesn&#8217;t even use Amazon EC2.</p>
<p>&#8220;I checked anyway, and surprisingly, here were 80+ servers running. I thought &#8216;OHHH CRAP!&#8217;</p>
<p>&#8220;So I shut them all down. Problem solved I thought, and since my bill was still looking normal I figured it wasn&#8217;t a problem.&#8221;</p>
<p>Ten minutes later Hellyer discovers another 80+ servers running at a different location on EC2. Digging deeper, he found five more locations, all with 80+ servers running. After fully auditing his account, he found more sections of &#8220;reserved instances&#8221; with even more servers running.</p>
<p><strong>&#8220;In total, there seemed to be around 600 servers running. The time between realizing all this and uploading my Git repository was approximately 12 hours.&#8221;</strong></p>
<h3>Digging Out of a Hole</h3>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg" rel="prettyphoto[31497]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg?resize=1024%2C482" alt="photo credit: Code & Martini by Ivana Vasilj - cc license" class="size-full wp-image-21873" /></a>photo credit: <a href="https://flic.kr/p/dLUWMb">Code &#038; Martini</a> by <a href="https://www.flickr.com/photos/ivanavasilj/">Ivana Vasilj</a> &#8211; cc license
<p>Hellyer went into damage control mode, scrambling to find the source of the problem.</p>
<p>&#8220;My immediate thought was &#8216;YOU IDIOT! You didn&#8217;t remove the wp-config.php file which contains AWS access keys!&#8217; he said. &#8220;But I went to check the repository, and it was not there. It turned out though, that there was another file called &#8216;wp-config.php.save,&#8217; which DID contain my AWS access keys.&#8221;</p>
<p>That file also contained his database password and security salts, but so far he hasn&#8217;t found any indication that the site was compromised by those. Hellyer immediately changed the password and swapped out the config keys.</p>
<p><strong>&#8220;But those horrid little AWS access keys were sitting on the repository in view of everyone. I immediately deleted the entire repository from GitHub.&#8221;</strong></p>
<p>Unfortunately, it took him two hours to delete all of the Amazon EC2 instances created by the exploited keys. &#8220;The evil little blighters had cranked up the security protection and actually made it very awkward to shut them all down,&#8221; he explained. &#8220;I wasn&#8217;t able to just terminate them and in fact had to go through one by one and manually turn off termination protection, then stop them, then terminate them. Then I had to go through and delete many volumes which had been setup (I think this is the EC2 equivalent of a drive).&#8221;</p>
<h3>Hellyer is Slapped with a $6,000 Bill for Unauthorized Usage</h3>
<p>AWS bills don&#8217;t update in real time, and Hellyer&#8217;s bill still read $17 USD. After contacting support to find out the damage, he saw his bill jump from $17 to $3,087.97. AWS was helpful throughout the process and give him a list of tasks to complete, including deleting some hidden EC2 instances which had not previously been visible in the console.</p>
<p>&#8220;After doing all of this, I went to take a snapshot of the billing statement to show everyone my lovely US$3,087.97 bill, only to find it had shot up to US$5994.08 in the meantime,&#8221; he said.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/aws-bill.png" rel="prettyphoto[31497]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/aws-bill.png?resize=425%2C554" alt="aws-bill" class="aligncenter size-full wp-image-31503" /></a></p>
<p>Amazon followed up with the following note:</p>
<blockquote><p>We&#8217;ve submitted a concession request for the unauthorized usage charges you incurred for the current month. The concession request requires approval from levels of management therefore the process can take up to 7 &#8211; 10 working days to complete.</p></blockquote>
<p>He&#8217;s hoping that the leaked keys will not result in him having to cough up $6K for unauthorized use, but he hasn&#8217;t yet received confirmation that he won&#8217;t be held responsible.</p>
<h3>Why were his AWS Credentials in his wp-config file?</h3>
<p>If you&#8217;ve been following along with this nightmare situation, you may be wondering why Hellyer was storing his AWS credentials in wp-config.php. This was required for the <a href="http://geek.ryanhellyer.net/products/photocopy/">Photocopy</a> plugin he released a few years ago. There are many other plugins that utilize this same method. Although the plugin didn&#8217;t seem to have any security flaws, he decided to remove it from the site and discontinue development due to the unpleasant experience of having his keys leaked. &#8220;The only other option is store it in the database, but I think that&#8217;s actually worse as you would run into exactly the same problem if your database were leaked,&#8221; Hellyer said.</p>
<h3>Keep Your Keys Safe and Private</h3>
<p>This cautionary tale should serve as a reminder to keep your keys safe and private. Hellyer unknowingly sabotaged himself when trying to open source the code for his site and learned an expensive lesson:</p>
<p><strong>&#8220;Not only should you be extremely careful with your usernames, passwords, plugin and theme security etc., but you need to be even more careful about credentials for services which cost money,&#8221;</strong> he advised.</p>
<p>&#8220;I&#8217;d rather see my blog(s) hacked than to have this happen again. Hacked sites can be easily fixed. Deleted data can be restored. A $6000 bill however is something else entirely,&#8221; Hellyer said. He also noted that if the exploit had just been a few extra dollars here and there, it could have quietly leached his account indefinitely without him noticing. As it was, if Amazon hadn&#8217;t issued him an urgent notice, he probably wouldn&#8217;t have noticed until he received a $100,000 bill at the end of the month.</p>
<p>The lesson here is that if you can avoid having to store AWS credentials in wp-config.php, by all means, find another way. What started out as a well-meaning effort to open source his site, quickly became a horrible nightmare that has yet to reach a conclusion. There are people out there ready and willing to exploit stolen or leaked AWS keys, and they clearly have a sophisticated way of scouring the web to find them.</p>
<p>Hellyer sums it up: <strong>&#8220;Long story short &#8230; don&#8217;t do stupid stuff with publicly accessible code. Also, don&#8217;t store your AWS credentials unless you absolutely have to.&#8221;</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 16:38:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: Faith in Eventually";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44158";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/09/faith-in-eventually/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<blockquote><p>During the development of most any product, there are always times when things aren’t quite right. Times when you feel like you may be going backwards a bit. Times where it’s almost there, but you can’t yet figure out why it isn’t. Times when you hate the thing today that you loved yesterday. Times when what you had in your head isn’t quite what you’re seeing in front of you. Yet. That’s when you need to have faith.</p></blockquote>
<p>Jason Fried writes <a href="https://signalvnoise.com/posts/3776-faith-in-eventually">Faith in eventually</a>. Good to share with anyone who&#8217;s been working on something for a while.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 16:10:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress.tv Blog: Leveling-up with WordPress:  Great videos for developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.wordpress.tv/?p=391";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3213:"<p>WordCamps are a great place to jump-start your education in the world of WordPress development, or build upon yours current skills to make even greater plugins and themes.  Here are some recent videos from <a href="http://wordpress.tv/event/wordcamp-asheville-2014/" target="_blank">WordCamp Asheville</a> and <a href="http://wordpress.tv/event/wordcamp-vancouver-2014/" target="_blank">WordCamp Vancouver </a> focused on how you can polish your development skills</p>
<h2>Introduction to WordPress Plugin Development</h2>
<div id="v-UhGPU68X-1" class="video-player">
</div>
<p>Jonathan Daggerhart gives a basic introduction to the creation of a new plugin, including using the Codex, actions, filters, shortcodes, custom settings, and some best practices. An existing understanding of some PHP is required to get the most value from this presentation.</p>
<p><a href="http://wordpress.tv/2014/09/24/jonathan-daggerhart-introduction-to-wordpress-plugin-development/" target="_blank">View on WordPress.tv</a></p>
<h2>How To Build A Custom Widget</h2>
<div id="v-vR4M3CqR-1" class="video-player">
</div>
<p>Widgets are a great way to deliver added content or functionality to a WordPress site. In this presentation, Mel Karlik shows you how to create a simple custom widget then see how you can distribute theme with a theme or as a stand-alone plugin.</p>
<p><a href="http://wordpress.tv/2014/09/25/mel-karlik-how-to-build-a-custom-widget/" target="_blank">View on WordPress.tv</a></p>
<h2>Advanced Custom Fields – Beyond the basics</h2>
<div id="v-R3mr0Q9g-1" class="video-player">
</div>
<p>This presentation by Merrill Mayer covers the use of advanced custom fields in non-blog oriented websites, focusing on using them in custom post types as well as demonstrating custom queries along with custom prev/next posts.</p>
<p><a href="http://wordpress.tv/2014/09/25/merrill-mayer-advanced-custom-fields-beyond-the-basics-2/" target="_blank">View on WordPress.tv</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptvblog.wordpress.com/391/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptvblog.wordpress.com/391/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.wordpress.tv&blog=5310177&post=391&subd=wptvblog&ref=&feed=1" width="1" height="1" /><div><a href="http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/"><img alt="Jonathan Daggerhart: Introduction to WordPress Plugin Development" src="http://videos.videopress.com/UhGPU68X/video-882b46ac2b_scruberthumbnail_3.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/"><img alt="Mel Karlik: How To Build A Custom Widget" src="http://videos.videopress.com/vR4M3CqR/video-da912a20fb_scruberthumbnail_0.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/"><img alt="Merrill Mayer: Advanced Custom Fields – Beyond the basics" src="http://videos.videopress.com/R3mr0Q9g/video-99f3a50e95_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 00:12:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Jerry Bates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:121:"Lorelle on WP: What Does WordPress, iThemes, Goodwill, Home Depot, and Target Have in Common? Your Identity and Security.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11913";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:141:"http://lorelle.wordpress.com/2014/09/25/what-does-wordpress-ithemes-goodwill-home-depot-and-target-have-in-common-your-identity-and-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:485:"We received a new credit card in the mail today to replace our old one AGAIN. An &#8220;unsuccessful attempt&#8221; to access our secure security data happened and this is a precaution the bank is taking to protect us. I have no other information so I&#8217;m left wondering. Yesterday I received an email supposedly from Home [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11913&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 21:57:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Matt: Circa 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44156";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:29:"http://ma.tt/2014/09/circa-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:216:"<p><a href="http://cir.ca/">Circa is how I get news on my phone every day</a>, and they&#8217;ve just redesigned with some slick new features. They&#8217;re an <a href="http://audrey.co/">Audrey</a> company, too.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 20:49:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"Post Status: The anatomy of a security breach, and how to do good in a bad situation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7134";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.poststat.us/ithemes-security-breach-and-disclosure/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12133:"<p><img class="aligncenter size-large wp-image-7139" src="http://www.poststat.us/wp-content/uploads/2014/09/ithemes-dark-752x226.jpg" alt="ithemes-dark" width="627" height="188" /></p>
<p>On Tuesday, iThemes posted an announcement that they had <a href="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/">suffered from a security breach</a> of their website and servers. The attackers had reached the servers which stored customer information, including email addresses, IP addresses, full names, and yes, passwords.</p>
<p>iThemes was quick to notify customers via their blog, social media, and their full customer email list about the breach. Approximately 60,000 users were affected. They warned that passwords were vulnerable. In <a href="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/">the second update</a>, posted today, they gave more information about passwords, in response to many questions from users.</p>
<p>It turns out that passwords were stored in plaintext on iThemes&#8217; server. That is, obviously, very bad practice.</p>
<blockquote>
<h3>Why Would You Store Passwords in Plain Text?</h3>
<p>This is how the membership software we started using in 2009 did it. There are a number of factors for this, none that will make much of a difference at this point or make anyone feel any better about it, myself included.</p>
<p>Know that it’s not because we did not value your data. As an organization, we have been working on a very large migration process that has required us to interlink legacy systems with the latest technologies. Anyone that has ever gone through that process understands the complexities and challenges.</p>
<p>Frankly put, it’s been something we identified as a potential risk and are working rapidly now to rectify this issue as fast as humanly possible.</p></blockquote>
<p>It&#8217;s also worth noting that their customer database and iThemes.com users were affected, but customers that use their Sync product to manage their own websites were not. So if you use iThemes Sync, and utilized your site passwords to connect, those accounts and passwords were not part of this breach.</p>
<h3>aMember and legacy membership platforms</h3>
<p>The membership platform that Cory highlights in the update is a<a href="http://www.amember.com/">Member</a>, a membership management system that&#8217;s been around for many years. aMember only introduced <a href="http://www.amember.com/p/2011/11/amember-pro-version-4-stable/">encrypted passwords in version 4</a>, which was released in November of 2011.</p>
<p>I discussed aMember and plaintext passwords with some other folks that have a significant history with the membership platform, and there are some significant problems that anyone using aMember have experienced.</p>
<p>First, most folks heavily using aMember aren&#8217;t using it out of the box. At the time, most membership sites were doing significant customizations to aMember to achieve desired functionality. So when the v.4 update came out, it was a very difficult update procedure for people to take advantage of the features.</p>
<p>iThemes would even tell you that their current version of membership software doesn&#8217;t look much like aMember at all.</p>
<p>iThemes is also not the first to be hacked and their aMember passwords leaked. Tuts+ Premium <a href="http://marketblog.envato.com/general/tuts-premium-security/">had the same issue in 2012</a>.</p>
<p>I discussed aMember at length with <a href="http://twitter.com/pippinsplugins">Pippin Williamson</a>. He has done a lot of work on his brother&#8217;s membership site, <a href="http://cgcookie.com/">CGCookie</a>, which also used aMember until 2012, when he did a huge migration of tens of thousands of members to a new platform.</p>
<p>At the time, Pippin notes that aMember did not disclose passwords were stored in plaintext, so CGCookie had no idea that their users were vulnerable until they learned of the Tuts+ hack, wherein they put a planned migration &#8220;into hyperdrive.&#8221;</p>
<p>The problem with iThemes&#8217; situation is that they knew of the plaintext passwords and didn&#8217;t address the obvious security vulnerability.</p>
<p>All in all, the migration for CGCookie took months to perfect and significant juggling of priorities by their team.</p>
<h3>Ticking time bomb</h3>
<p>Speaking with Pippin, migrating from aMember was not an easy task. Paypal&#8217;s IPN handlers (a payment notification system) were tightly linked to aMember and preventing customer accounts from being disconnected from the membership site took weeks of engineering. Additionally, simply upgrading to the newer versions was also terrible.</p>
<p>Many other WordPress companies have used aMember in the past as well, storing plaintext passwords just like iThemes today.</p>
<p>So, aMember has definitely been a problem before now, but iThemes has absolutely slacked in their prioritization of the issue. Simply put, it&#8217;s inexcusable to put users into long term risk if you know their passwords are stored in plaintext.<span id="more-7134"></span></p>
<p>That said, we should consider the potential consequences &#8212; though it doesn&#8217;t make it excusable. Because iThemes doesn&#8217;t store credit card details, emails and names and passwords are about the worst things at risk. Still, a tiny percentage of the general population uses responsible passwords, so getting a list of names and emails and passwords is a treasure trove of information for third party (as in other websites like banks and email providers) to steal identities and break directly into user accounts.</p>
<p>This should also be a significant lesson for any user to always use different passwords for every website where you keep an account. Tools like <a href="https://lastpass.com/">LastPass</a> and <a href="https://agilebits.com/">1Password</a> make account password management easy. Additionally, learn about <a href="http://en.wikipedia.org/wiki/Two-step_verification">2-factor authentication</a> and use it whenever the service enables it.</p>
<h3>Owning mistakes</h3>
<p>This is clearly a horrible situation for iThemes to be in. Users have a right to be mad. In 2014 we should be able to expect that our passwords are encrypted, and that even if a server where our information is stored is hacked, that certain valuable details like credit cards or passwords are not exposed. Thankfully, iThemes doesn&#8217;t store credit card details, but those passwords should now be assumed stolen, and users have to pay that price.</p>
<p>But where I have enormous respect for iThemes is how they have owned it. Especially in the update post, Cory Miller &#8212; iThemes&#8217; founder and CEO &#8212; took ownership of the issue and told the full story of the breach.</p>
<blockquote><p>I realize this will generate a lot of concern. Again, I am deeply sorry for this mistake and how it has affected you.</p>
<p>Let me say: we have made mistakes in the past at iThemes … and as humans will make mistakes in the future. To make a promise otherwise would be absurd and misleading.</p>
<p><strong>But my promise to you, our customers, is this</strong> … and it’s the same promise that I’ve held to since January 2008 when I started iThemes in my home:</p>
<ol>
<li><strong>We will identify mistakes as best we can.</strong> You have helped us with this and appreciate that accountability.</li>
<li><strong>We will own up to our mistakes.</strong> Again, we’ve done this in the past, we did this yesterday and this post is another example of us living this value.</li>
<li><strong>We will fix the mistake as fast as humanly possible.</strong> A number of priority issues have been unearthed, shone a hard light on, but we are working to resolve them.</li>
<li><strong>We will learn and grow from it and be better for it and for you.</strong></li>
</ol>
<p>Additionally, as the founder and CEO, the leader of this company, I want you to know: <strong>the buck stops with me and me alone.</strong></p>
<p>At the end of the day, I am responsible for our company, iThemes, and the work we do. I’ve often tried to defer credit for the great work we’ve done to our team, but as for the mistakes we make, that credit belongs solely to me.</p></blockquote>
<p>Not every company that&#8217;s been breached can say the same. Even huge organizations (I&#8217;m thinking of Home Depot as the latest) have done a horrible job at responsible and honest disclosure to their customers.</p>
<p>iThemes could have made this much more quiet and kept it from being a priority to their users or a big deal in WordPress news-land. But they didn&#8217;t. They owned it, they apologized, and they&#8217;ve been rewarded for that.</p>
<p>In the comments of the security update post, users were appalled by the lack of responsibility on the security priorities, but the honesty paid off in the sense that users were verbally thankful for it so that they could accept the problem and deal with it, when the alternative was to be in the dark.</p>
<p>While this breach has cost iThemes some credibility, and some trust, I believe those things are recoverable. Had they obfuscated the hack itself, my post and users reactions (had they found out) would be very different.</p>
<h3>What iThemes is doing now</h3>
<p>iThemes has learned a hard lesson this week, as many other companies have before them. Now they must react, and react strongly. In a situation like this, nothing should take priority over getting this issue fixed.</p>
<p>Until they get their password storage issue fixed, they still are storing passwords in plaintext, even the new ones. Thankfully they&#8217;ve already updated password restrictions &#8212; which previously limited passwords to 20 characters &#8212; to now accept up to 255 characters. But storing them in plaintext means that they are still as vulnerable today as they were last week if someone gets into the server again. So they must be absolutely vigilant to protect their servers through this migration.</p>
<h3>What we can all learn</h3>
<p>Security is not a sexy industry. Too often we don&#8217;t consider it until it&#8217;s a problem. &#8220;Going on offense&#8221; should be our default when we consider security actions, but more often &#8212; even with some of the best companies and people in the tech space &#8212; we react to issues and aren&#8217;t appropriately proactive.</p>
<p>That said, our job is not done either. All of us should consider our own security situation and how we can improve it. Especially if you have users of your own (and many of my readers do), consider that state of your own security, and make sure it&#8217;s a priority in your business.</p>
<p>When we think about what pays the bills, it&#8217;s not security awareness and proactive security investments. But we should consider security breaches and vulnerabilities as risks that must be managed; meaning investment into security priorities should be a significant part of any business.</p>
<p>iThemes, Envato, and WooThemes are all &#8220;big&#8221; businesses from a WordPress business perspective. Each of them has fought a website security battle. Envato and WooThemes before iThemes have recovered and maintained their users and the community&#8217;s trust. I think iThemes will too. But before you, or me, decide &#8220;it won&#8217;t happen to us&#8221;, consider that it can happen to anyone, and our investments into security measures and best practices are not only worthwhile, but the only responsible thing to do.</p>
<p>And for users, use different passwords on every site. Use LastPass or 1Password. Enable 2-factor authentication. Be vigilant. Do not use the excuse that it&#8217;s too hard or a burden. What&#8217;s much more of a burden is dealing with a hacked email or bank account. Protect yourself and learn how to protect your accounts. It&#8217;s easy to adjust to and modern tools make it a much simpler task to manage.</p>
<p>Let&#8217;s all &#8212; web professionals and users &#8212; learn with iThemes here, and do better.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 20:01:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: iThemes Confirms it Stored Customer Passwords in Clear-Text";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31475";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/ithemes-confirms-it-stored-customer-passwords-in-clear-text";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4658:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ClearTextPasswordFeaturedImage.png" rel="prettyphoto[31475]"><img class="size-full wp-image-31477" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ClearTextPasswordFeaturedImage.png?resize=637%2C200" alt="Clear Text Password" /></a>photo credit: <a href="https://www.flickr.com/photos/thegloaming/1402099967/">thegloaming</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>The CEO of iThemes, Cory Miller, <a title="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/" href="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/">published a second update</a> concerning the <a title="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords" href="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords">security breach</a> that occurred on Tuesday. After news of the breach, <a title="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/comment-page-1/#comment-100073" href="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/comment-page-1/#comment-100073">customers were left wondering</a> whether or not their passwords were stored in clear-text. The latest update confirms that passwords were in fact stored in clear-text and affected approximately 60,000 customers.</p>
<blockquote><p>There is no easy way to say this: We were storing your passwords in clear-text. This directly impacted approximately 60,000 of our users, past and current.</p>
<p>Yes, those credentials were used across our entire platform, from our iThemes membership login to your iThemes Sync login.</p></blockquote>
<p>Passwords stored in clear-text allow hackers to easily obtain them if the database becomes compromised. According to the announcement, storing passwords in clear-text dates back to membership software used in 2009. Since that time, the company has been involved with a large migration process moving from legacy systems to newer technology.</p>
<blockquote><p>Know that it’s not because we did not value your data. As an organization, we have been working on a very large migration process that has required us to interlink legacy systems with the latest technologies. Anyone that has ever gone through that process understands the complexities and challenges.</p>
<p>Frankly put, it’s been something we identified as a potential risk and are working rapidly now to rectify this issue as fast as humanly possible.</p></blockquote>
<p>I asked the CTO of <a title="http://crowdfavorite.com/" href="http://crowdfavorite.com/">CrowdFavorite</a>, <a title="http://chrislema.com/" href="http://chrislema.com/">Chris Lema</a>, who has over 20 years of experience in enterprise and SaaS products, if what iThemes experienced is common. &#8220;I can tell you this isn&#8217;t the first or last time I&#8217;ve heard of legacy systems that needed to be migrated or code that needed to be refactored. Sometimes you do it before anything bad happens. Sometimes you&#8217;re not fast enough. The trick is to prioritize it, even when things are &#8216;<em>working&#8217;</em>.&#8221;</p>
<p>In order to avoid the issues iThemes is working through, Lema offers the following advice. &#8220;Companies that have legacy systems &#8211; especially membership sites or eCommerce sites with users/passwords need to create a strategy for migrating those old systems while keeping everything running. This often means the creation of several interim systems. In other words, the migration isn&#8217;t a straight path but a multi-stop journey.&#8221;</p>
<h2>Honesty is a Virtue</h2>
<p>Customers <a title="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/comment-page-1/#comment-100191" href="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/comment-page-1/#comment-100191">have expressed disappointment</a> that a company who sells one of the most popular WordPress security plugins failed to adhere to security best practices. However, thanks to Miller&#8217;s honest approach of attacking the issue head on, a lot of those same customers are pledging their support.</p>
<p>Although this is a difficult situation for iThemes and its customers, the way Miller has handled the situation is an excellent example of leadership. The easiest thing to do in situations like these is to sweep it under the rug or go around the issue. While customers have every right to be outraged, Miller&#8217;s human and honest approach has kept a backlash to a minimum.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 16:22:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: A New Resource Devoted To WordPress and Photographers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=29165";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wptavern.com/a-new-resource-devoted-to-wordpress-and-photographers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2079:"<p><a title="http://wp-photographers.com/" href="http://wp-photographers.com/">WP Photographers,</a> is a new resource created by Aaron Hockley, to help photographers and WordPress users share their photos and build photography businesses. Whether you&#8217;re a <a title="http://wp-photographers.com/wordpress-basics/" href="http://wp-photographers.com/wordpress-basics/">beginner </a>or a photographer looking for <a title="http://wp-photographers.com/wordpress-web-hosting-photographers/" href="http://wp-photographers.com/wordpress-web-hosting-photographers/">the best webhosting service</a>, WP Photographers has you covered. In addition to guides, Hockley routinely publishes reviews of WordPress themes and plugins related to photography.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP-PhotographersWebsite.png" rel="prettyphoto[29165]"><img class="size-full wp-image-31439" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP-PhotographersWebsite.png?resize=1025%2C657" alt="WP Photographers Front Page" /></a>WP Photographers Front Page
<p>He started the site because there were few resources on the web that discuss the intersection between WordPress and photography. &#8220;Being deep in both worlds I get lots of questions from photographers figuring out WordPress and WordPress folks trying to better use images,&#8221; Hockley told the Tavern. He hopes WP Photographers becomes a valuable resource to photographers and plans on starting a podcast to supplement the content on the site.</p>
<p>As Hockley continues to add relevant content,  it could become the go-to place for budding photographers using WordPress. There are several articles on the subject but it&#8217;s convenient to see a website devoted to the topic.</p>
<p>To learn more about Hockley and the inspiration behind WP Photographers, check out this<a title="http://photofocus.com/2014/09/04/finally-a-wordpress-site-for-photographers/" href="http://photofocus.com/2014/09/04/finally-a-wordpress-site-for-photographers/"> interview</a> on PhotoFocus.com.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 23:37:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Matt: Corporate News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2014/09/corporate-news/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"<p><a href="http://www.ft.com/cms/s/2/937b06c2-3ebd-11e4-adef-00144feabdc0.html">The Invasion of Corporate News</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 22:05:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Lorelle on WP: WordPress Social Meetup in Vancouver, Washington, This Weekend";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11895";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://lorelle.wordpress.com/2014/09/24/wordpress-social-meetup-in-vancouver-washington-this-weekend/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:489:"We&#8217;re putting together a WordPress Social Meetup in Vancouver, Washington, just a few minutes from downtown Portland, on Sundays from 4-7, and the first one is this Sunday, Sept. 28, 2014! Part of the WordPress PDX Meetup, we&#8217;re excited to be one of the first to offer a social meetup rather than a formal presentation [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11895&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 20:27:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WPTavern: GavickPro Releases Free WordPress Portfolio Theme for Design, Art and Photography Websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31386";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://wptavern.com/gavickpro-releases-free-wordpress-portfolio-theme-for-design-art-and-photography-websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4322:"<p>A few months ago, the folks at GavickPro <a href="http://wptavern.com/gavickpro-abandons-theme-framework-in-favor-of-wordpress-customizer" target="_blank">abandoned their GavernWP Framework</a> in favor of using the WordPress customizer for theme options. The shop&#8217;s customers found the original framework to be too cumbersome and confusing, so the GavickPro team decided to move away from frameworks altogether.</p>
<p>With the customizer in place as the baseline for the next generation of themes, GavickPro has been releasing a string of free products to give potential customers a way to test drive the new approach. <a href="https://www.gavick.com/wordpress-themes/portfolio,174.html" target="_blank">Portfolio</a> is the latest theme release, created to showcase art and photography with a lightweight, minimalist design.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-gavickpro.png" rel="prettyphoto[31386]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-gavickpro.png?resize=994%2C784" alt="portfolio-gavickpro" class="aligncenter size-full wp-image-31405" /></a></p>
<p>Portfolio items in the this simple theme are essentially just regular posts with a featured image assigned. No extra portfolio plugin is required. If you set the homepage to display the latest posts, it will use the grid layout that you see in the theme&#8217;s <a href="http://www.gavick.com/demo/wordpress/portfolio/" target="_blank">demo</a>. Mousing over a post toggles its title and excerpt into view.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-customizer.png" rel="prettyphoto[31386]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-customizer.png?resize=225%2C300" alt="portfolio-customizer" class="alignright size-medium wp-image-31416" /></a>The customizer includes options for setting the background and primary color for your site. It also allows you to easily change the number of columns, the date format, and enable/disable word-break.</p>
<p>The Portfolio theme also offers options for selecting from a predefined list of Google Fonts for the header and body. You can also paste in the URL for any other Google Font that you prefer to use.</p>
<p>The theme includes one widget area and support for the gallery, image, link, quote, and video post formats.</p>
<p>A social links menu can be created by adding the following available CSS classes to your menu items:</p>
<ul>
<li>icon-fb</li>
<li>icon-gplus</li>
<li>icon-twitter</li>
<li>icon-youtube</li>
<li>icon-pinterest</li>
<li>icon-rss</li>
</ul>
<p>The theme also includes built-in support for <a href="https://disqus.com/" target="_blank">Disqus</a>. Threaded comments, author boxes, and sharing buttons are all nicely styled to remain in the background with portfolio content in the spotlight.</p>
<p>The Portfolio theme is mobile-friendly and responds well to various devices. Your work will look beautiful, no matter the screen size.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-wordpress-theme-responsive.jpg" rel="prettyphoto[31386]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-wordpress-theme-responsive.jpg?resize=700%2C625" alt="portfolio-wordpress-theme-responsive" class="aligncenter size-full wp-image-31410" /></a></p>
<p>If you like the content in the <a href="http://www.gavick.com/demo/wordpress/portfolio/" target="_blank">live demo</a>, you can download it as a <a href="http://www.gavick.com/documentation/wordpress-themes/themes-demo-content-wxr-files/" target="_blank">WXR file</a>, which includes the sample menus, posts, and images to help you get started.</p>
<p>The theme is simply named Portfolio and after testing it, I can confirm that all the customization features work as advertised. I&#8217;d recommend it for simple portfolio sites where you don&#8217;t need to have portfolio items separate from the rest of the content on your site. It&#8217;s available to <a href="https://www.gavick.com/wordpress-themes/portfolio,174.html" target="_blank">download</a> for free from the GavickPro website. You can also find the code on <a href="https://github.com/GavickPro/Portfolio-Free-WordPress-Theme" target="_blank">GitHub</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 18:48:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: Flox: Privately Hosted Social Networks Powered by WordPress and BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31029";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wptavern.com/flox-privately-hosted-social-networks-powered-by-wordpress-and-buddypress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9302:"<p>Every day, millions of people mindlessly pump content into social networks that are owned by someone else. These massive data silos plaster your feed with advertising and blatantly disregard user privacy. It&#8217;s a symbiotic relationship wherein you are the product being sold, but you have no control.</p>
<p>Even Twitter, which many saw as the last vestige of social networking sanity, appears to be inching closer to <a href="http://mashable.com/2014/09/04/twitter-filtered-feed/" target="_blank">filtered feeds</a>, experimenting with an <a href="http://techcrunch.com/2014/09/01/twitters-timeline-could-get-more-algorithmic/" target="_blank">algorithmic approach to the timeline</a> in order to deliver content they deem relevant to you. All the major social outlets are starting to pollute users&#8217; feeds with content they don&#8217;t want to see; it&#8217;s the inevitable byproduct of mining user data for profit.</p>
<p>A growing dissatisfaction with this pollution is leading innovators to create new streams of social interaction, with more realistic business models that deliver an unpolluted experience as the product. Many are turning to private social networks as an alternative to the sprawling networks that invariably attempt to connect you to every passing acquaintance.</p>
<h2>Flox Enters the Market to Provide Hosted Private Networks</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox.jpg" rel="prettyphoto[31029]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox.jpg?resize=1025%2C516" alt="flox" class="aligncenter size-full wp-image-31141" /></a></p>
<p><a href="https://flox.io/" target="_blank">Flox</a> is a brand new service will soon be launching hosted private networks powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>, <a href="https://buddypress.org/" target="_blank">BuddyPress</a>, and <a href="http://www.idangero.us/framework7/" target="_blank">Framework7</a>. The platform will allow you to host your own social network, completely under your control, with the ability to send status updates, photos, messages, and more, in your own private place on the web. Flox users can be part of multiple networks or &#8220;flocks,&#8221; hence the platform&#8217;s sheep logo.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-logo.png" rel="prettyphoto[31029]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-logo.png?resize=250%2C250" alt="flox-logo" class="alignright size-full wp-image-31394" /></a>Founded by BuddyPress project lead <a href="http://jjj.me/" target="_blank">John James Jacoby</a>, Flox is the first WordPress-powered application to jump into hosting full-featured social networks. Jacoby recently left his engineering position at 10up, to pursue his dream of creating hosted communities. Fortunately, Jake Goldman and the folks at <a href="http://10up.com/" target="_blank">10up</a> were behind him and opted to subsidize the project.</p>
<p>&#8220;Jake and I talked about the idea (again) and came to the conclusion it wasn&#8217;t something Jake saw 10up being responsible for in perpetuity, but was still valuable,&#8221; Jacoby told the Tavern. &#8220;Jake and the 10up execs were kind enough to invest a bit in helping bootstrap it. They’ll be my initial round of beta testers.&#8221;</p>
<p>The unique thing about Flox is that it&#8217;s designed to be a mobile-only network. At the moment, the only way you access it is via your mobile browser. There is no desktop version. Jacoby describes it as &#8220;a mobile experience that acts more like Twitter meets Slack powered by BuddyPress, than it does &#8216;large blogging network conglomerate.\'&#8221; Essentially, it is the &#8220;WordPress.com for BuddyPress,&#8221; but he hopes that it will be much more than that.</p>
<p>The possiblity of hosted BuddyPress communities has been burning in Jacoby&#8217;s head since his earlier days at Automattic. &#8220;The idea goes way back to 2007/8, with the idea of BuddyPress on WordPress.com. When Matt eventually abandoned that idea, I couldn&#8217;t let go of the bigger idea of letting people roll their own WordPress.com’s,&#8221; he said.</p>
<p>Why is Flox mobile only? Jacoby believes this is the way of the future for online social interaction.</p>
<blockquote><p>The idea to go Mobile-only was inspired by a few things: Jake Goldman really wanted a great mobile experience to communicate with 10uppers; I believe we&#8217;re entering an era where many people will use mobile devices as their only machines; my desire to funnel the most relevant and important people in my life into a convenient, easy-to-use, and own-my-own-data place in my pocket.</p></blockquote>
<p>Jacoby is flying solo on the project for now but he hopes to add to his team as the platform gains momentum. &#8220;By the end of the year, my goal is to have at least one full-time employee on it besides myself,&#8221; he said. &#8220;Ideally many more down the line, but we’ll see what I’m able to pull off.&#8221;</p>
<h3>The Technology Behind Flox</h3>
<p>Conversations in Flox include all the native BuddyPress social features distilled into a UI that is highly optimized for mobile. Users have the option to create &#8220;channels&#8221; to further filter the activity stream.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-conversation.png" rel="prettyphoto[31029]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-conversation.png?resize=460%2C818" alt="flox-conversation" class="aligncenter size-full wp-image-31150" /></a></p>
<p>Flox is intended to be an application where its users never see the backend of WordPress. Jacoby hopes to preserve wp-admin to be used strictly as a UI for Flox staff to manage the installation. The idea is that administrators of their own networks will get a purposely crafted experience, without all of the maintenance associated with managing a WordPress site.</p>
<p>Under the hood, each flock is its own network on a multi-network installation of WordPress. &#8220;BuddiOS is the heart of the mobile experience, at least right now,&#8221; Jacoby said. &#8220;Currently, it’s a WordPress theme, though it might eventually turn into a plugin that auto-detects a mobile environment, and adjusts. We’ll see how that experience pans out in the long-term.&#8221;</p>
<p>Outside of WordPress and BuddyPress, Framework7 is the only other technology in the mix right now. &#8220;I started down the AngularJS road but it’s not really the right tool for this job,&#8221; Jacoby said. &#8220;I can see future versions using a restful API, but for what I need and how much work needs to go into that API, I wasn&#8217;t inclined to rush it.&#8221;</p>
<p>Why isn&#8217;t Flox launching with a native app? Jacoby wants to start out by refining the experience of the basic social features before delving further into integrating with native device features. &#8220;I built a &#8216;native app&#8217; using a UIWebView that I&#8217;m using personally, but that alone isn&#8217;t enough to make it into the Apple App store,&#8221; he explained. &#8220;It will need to use something native to the phone first, which will likely be push notifications or settings integration.&#8221;</p>
<p>Jacoby plans to put the BuddiOS WordPress theme up for sale to start, in order to help further subsidize BuddyPress/Flox development. Now that he is focusing on Flox, he has a greater ability to contribute to the open source BuddyPress project, which is entirely volunteer driven. This can only mean good things for the future of BuddyPress.</p>
<h3>Pricing and Launch Information</h3>
<p>Flox is emerging as a fresh alternative to the massive social networks where you have limited control over the content presented to you. Online social networking, in its purest form, is the ability to have authentic interactions with the people you choose. Flox is aiming to restore the simplicity and power of small, focused networks but is also built to scale to accommodate large businesses that require social networking for employees.</p>
<p>Users can create several networks, each with their own members. The platform is designed to make it easy to switch between your various private social networks and <a href="https://flox.io/pricing/" target="_blank">pricing</a> is flexible based on the number of users. Personal networks are free and limited to 5 users in 5 networks. The Business pricing option rings in at $3/user per month and is limited to 25 users. Pro social networks do not have a user limit and receive access to priority support at $10/user per month.</p>
<p>The platform is a promising option for those who want the power of mobile BuddyPress social networking without the hassle of managing their own installations. It also appeals to those who are looking to leave traditional social networks in favor of creating their own.</p>
<p>At the moment, <a href="https://flox.io" target="_blank">Flox</a> is in its early beta period and <a href="https://flox.io/sign-up/" target="_blank">signups</a> are limited to a few testers. The service will be launching soon, putting private social networks in the pockets of users around the world.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 13:07:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: How Public Perception of WordPress Influences Developer Contracts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31255";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wptavern.com/how-public-perception-of-wordpress-influences-developer-contracts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:15284:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/cash.jpg" rel="prettyphoto[31255]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/cash.jpg?resize=1019%2C504" alt="photo credit: Tax Credits - cc" class="size-full wp-image-31371" /></a>photo credit: <a href="https://www.flickr.com/photos/76657755@N04/7658205070/">Tax Credits</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a>
<p>If the WordPress community is your only barometer of knowing how an open source community works together, then you might want to explore outside a bit further to gain a broader outlook on other cultures. Some of the differences are worth examining.</p>
<p>A few days ago I noticed an interesting observation regarding the relationship between plugin development and project offers in CakePHP vs. WordPress.</p>
<blockquote class="twitter-tweet" width="550"><p>Another CakePHP project offer thanks to two open source plugins of mine from years ago. Three times more often than WP offers.</p>
<p>&mdash; Mario Y. Peshev (@no_fear_inc) <a href="https://twitter.com/no_fear_inc/status/511604514236141568">September 15, 2014</a></p></blockquote>
<p></p>
<p><a href="http://devwp.eu/" target="_blank">Mario Peshev</a> is a WordPress contributor who owns <a href="http://devrix.com/" target="_blank">DevriX</a>, a high-end agency specializing in SaaS development and platform architecture. He is also a co-organizer of WordCamp Sofia and WordCamp Europe 2014.</p>
<p>It seems curious that Peshev would regularly receive more offers for CakePHP work, originating from older code he&#8217;d written, versus requests for WordPress, which powers more than 23% of the web. In his experience, it&#8217;s not just related to CakePHP but many other technologies as well.</p>
<p>&#8220;It&#8217;s not only CakePHP really. CakePHP, CodeIgniter, Java, Django, Drupal, Android even &#8211; all sorts of small extensions, plugins or apps I&#8217;ve built and released publicly get larger attention than my WordPress contributions,&#8221; Peshev told the Tavern.</p>
<p><strong>&#8220;Not only do I get 2-3x more projects with any other platform (even though I haven&#8217;t contributed there for 3+ years), but the proposed rates and budgets are few times higher.&#8221;</strong></p>
<p>His experience seems to suggest that there&#8217;s a disconnect somewhere in how potential customers value the skills of WordPress developers.</p>
<h2>Client Perception of WordPress</h2>
<p>WordPress is heralded the world over as being the most user friendly publishing software on the web. Unfortunately, this can also contribute to unrealistic client expectations when it comes to custom development.</p>
<p>&#8220;The majority of the WordPress users that get in touch with us are: bloggers, small company owners, marketing consultants, sales agents, small and medium-sized businesses,&#8221; Peshev said. &#8220;They are not technical people and don&#8217;t have realistic (according to the market standards) expectations for the type of work they ask for.&#8221;</p>
<p>He outlined a typical scenario that plagues many development agencies. Because users can piece most of their sites together without help, they figure the rest should be easy:</p>
<blockquote><p>A common scenario is: &#8220;We&#8217;ve built our WordPress website ourselves with a premium theme and a few plugins, so we just need those tiny changes applied here and there.&#8221; Their infrastructure is not ready for the types of changes they need, and the fact that 90%+ of their requirements cost $100 or so (for a premium theme + a plugin) doesn&#8217;t justify paying ten times more for the other 10% if that would be 10-20 hours of high-end development. The math just doesn&#8217;t add up for them.</p></blockquote>
<p>These misconceptions play out in various ways, including users feeling entitled when it comes to free plugin and theme features, core updates, and other improvements that seem to arrive magically from the sky. Very few plugin and theme developers can report anything more than meager donations when it comes to contributing free extensions.</p>
<p>For Peshev, creating open source extensions for platforms outside the WordPress ecosystem has been far more rewarding in terms of referrals for work. He detailed a recent request he received in a post titled <a href="http://devwp.eu/15-wordpress-gig/" target="_blank">The $15 WordPress Gig</a>:</p>
<p><strong><em>&#8220;Hello, I’m looking for someone who could customize a WordPress plugin we bought. It’s a car reservation system, we need to change the pricing model and add a few extra SQL tables that would operate with the plugin.&#8221;</em></strong></p>
<p>After requesting a project description and budget, Peshev received the following reply:</p>
<p><strong><em>&#8220;Thanks, the plugin costs $25 so I estimate the change would probably cost around $15.&#8221;</em></strong></p>
<p>While that response may seem shocking to a developer, it makes perfect sense to someone who only has the price tag of the original product as a gauge for judging the value of work related to it.</p>
<h2>Reshaping Client Expectations</h2>
<p>The WordPress community has a unique challenge when it comes to communicating the costs of custom development, given that thousands of free and/or dirt cheap themes and plugins are available. How can a seemingly simple modification be 10x the price of the original plugin?</p>
<p>Some of these issues stem from the way most development agencies attract customers. <strong>&#8220;WordPress is more design and marketing oriented than other communities. Portfolios reveal beautiful and stylish websites and agencies focus on frontend work,&#8221;</strong> Peshev said.</p>
<p>&#8220;Building CRMs, eRPs, eCommerce platforms or other backend-oriented platforms and services is still not a common thing in the WordPress ecosystem, even if it&#8217;s completely possible and some of us build these sorts of projects for larger clients.&#8221;</p>
<p>Peshev believes that since most clients lack technical knowledge, they judge agencies and developers by what they can see. &#8220;<span class="pullquote alignleft">Clients don&#8217;t browse WordPress.org or GitHub portfolios, they are just looking for beautiful designs.</span> Code quality doesn&#8217;t matter unless you deal with eCommerce, and scalability and security are overlooked until it&#8217;s too late.&#8221;</p>
<p>If you sell WordPress development services, you will undoubtedly have to become skilled at reshaping client expectations. When it comes to custom development, experienced developers often recommend giving the potential customer a more familiar frame of reference:</p>
<blockquote class="twitter-tweet" lang="en"><p><a href="https://twitter.com/pollyplummer">@pollyplummer</a> I can buy a suit for $99 \'off the peg\' or pay 10x that for a custom suit that is made perfectly for me.</p>
<p>&mdash; Jonathan Atkinson (@twsjonathan) <a href="https://twitter.com/twsjonathan/status/514573813707599873">September 24, 2014</a></p></blockquote>
<p></p>
<p>There are many different pre-internet era professions that are easier for clients to understand:</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/BoiteAWeb">@boiteaweb</a> <a href="https://twitter.com/pollyplummer">@pollyplummer</a> if I need electrical work and it takes the electrician 10 mins and a $2 piece I don\'t expect to pay him $10</p>
<p>&mdash; Jonathan Atkinson (@twsjonathan) <a href="https://twitter.com/twsjonathan/status/514575464728244224">September 24, 2014</a></p></blockquote>
<p></p>
<p>What is difficult for customers to grasp, is that development expertise is most similar to the work of a traditional engineer in that it requires applying years of knowledge and experience to devise a technical solution that will hold up in the long run.</p>
<p>A client may see his request as a &#8220;simple tweak to a plugin or theme&#8221; but is unaware of the many obstacles that can make it complicated. Peshev details a few examples in his recent piece on <a href="http://devwp.eu/slippery-slope-wordpress-customizations/" target="_blank">The Slippery Slope of WordPress Customizations</a>:</p>
<ul>
<li>The theme is not written according to the WordPress guidelines</li>
<li>The plugins are not compatible</li>
<li>There have been various manual changes in those plugins</li>
<li>The hosting provider has some limitations</li>
<li>There are PHP/MySQL version issues</li>
<li>The site uses some 3rd party API/service/database that needs special attention</li>
<li>The fixes could cause a regression in another area of the site</li>
<li>A simple functionality has been built with a complex plugin and the change needs to be applied there, which requires hacking the plugin itself </li>
</ul>
<p>For many small to mid-sized development agencies, the majority of incoming requests are directly related to customization work. Developers have to be prepared to educate clients on the realities of building quality WordPress solutions. While client perceptions are a major factor in the size of contracts developers are able to win, Peshev believes that the WordPress community has deeper cultural issues to resolve before the public will change its mind on the value of WordPress development.</p>
<h3>Changing Public Perception by Building a Culture of Contributing</h3>
<p>Because the open source WordPress project is primarily a volunteer-driven effort, a culture of contribution is vital to its continued ability to innovate. It&#8217;s also vital for extension developers if they want to work together to build more elegant solutions. According to Peshev, very few companies and agencies see the value of contributing to the project.</p>
<blockquote><p>While traveling around Europe I&#8217;ve met developers and devops at WordCamps from companies with 400+ employees, where the WordPress department is only 5-10 people strong. Those projects are large online magazines, or platforms for digital and high-tech companies that heavily rely on the WordPress platform, and they rarely invest in WordPress advocates or full-time contributors.</p></blockquote>
<p>Apart from a small number of corporately-funded contributors, the rest are individuals who donate time in the evening after the kids go to bed, over the weekend, or in between their freelance/agency duties.</p>
<p>Yet, many contributions go unrecognized and are often wrongly attributed entirely to Automattic by <a href="http://qz.com/260933/the-case-for-a-distributed-workforce/" target="_blank">every</a> <a href="http://www.fastcolabs.com/3035463/how-matts-machine-works" target="_blank">major</a> <a href="http://techcrunch.com/2014/08/26/automattic-acquires-bruteprotect-to-help-keep-wordpress-users-safe/" target="_blank">tech</a> <a href="http://techcrunch.com/2014/05/05/automattic-raises-160m-to-catch-up-with-the-webs-evolution/" target="_blank">news</a> outlet. These are honest mistakes, but, when left uncorrected, they contribute to the public perception that the project is the work of a handful of people who work for an elite agency, marginalizing the efforts of hundreds of unpaid volunteers.</p>
<p>&#8220;&#8216;WordPress themes&#8217; is the most popular subject in Google searches if you check with the Keyword planner,&#8221; Peshev notes. &#8220;Yet until a week ago there were no paid contributors to the WordPress Theme Review Team. Lots of people haven&#8217;t been noticed at all there, despite the facts that millions of websites run the themes they have reviewed and polished in order to reach to the point that they actually work.&#8221;</p>
<p>He contends that when contributions are undervalued or unrecognized, WordPress developers have little motivation to work together. This applies to product development as well, which spills over into custom development work.</p>
<p>&#8220;Have you noticed how many Lightbox, Gallery or Slider plugins we have out there? <span class="pullquote alignleft">Contributors don&#8217;t help each other and products stay small and simple</span>,&#8221; Peshev siad. &#8220;I have 25+ plugins on GitHub and I&#8217;ve only ever gotten three or four pull requests for any changes, and keep seeing similar plugins popping up every few weeks.</p>
<p>Our culture outside of the core isn&#8217;t contributing, but building everything from scratch or using &#8216;builder&#8217; plugins, which is somewhat justified by the low budgets that prevent us from any research activities which could slow us down (and burn our profits).&#8221;</p>
<p>As a result, many developers opt to go it alone, building custom solutions as quickly as possible on small budgets. Unfortunately, this practice restricts the growth of development agencies.</p>
<p>&#8220;I see a huge gap between the types of WordPress development/design requests,&#8221; Peshev said.</p>
<p>&#8220;The types of WordPress experts that I see out there are either freelancers and small studios with up to 3-4 people, or agencies like Human Made, 10up, WebDevStudios (and Automattic, of course). On one hand, there are the small $500 customization gigs or $3K eCommerce projects. On the other end we have the WordPress.com VIP type of clients and requests that are at least 50 times more expensive than the others.&#8221;</p>
<p>WordPress clients who cannot afford VIP level service turn to smaller companies like Peshev&#8217;s to accommodate their budgets. However, Peshev is frequently approached by clients looking for high-end consultants for other platforms, based on past open source contributions. Unfortunately, when it comes to WordPress work, contributions have done little for bringing in larger projects.</p>
<p>&#8220;I find it challenging to grow from a consultant to a larger and sustainable agency solely with WordPress &#8211; and I see numerous small agencies getting stuck at 4-5 people tops,&#8221; he said.</p>
<h3>Promoting Collaboration and Contribution</h3>
<p>For many dedicated WordPress contributors like Peshev, open source contributions have not led to more work or better contracts, despite the fact that these types of contributions should verify these developers as high-end experts. A little bit of skill and free time are all that are required to contribute to open source software, but time comes at a cost when you&#8217;re struggling to pay the bills.</p>
<p>Peshev&#8217;s observations raise some important questions that are worth considering. In an ecosystem where developers are often in competition with each other to create the same simple extensions for fast cash, it doesn&#8217;t pay to collaborate on more elegant solutions. This contributes to a market flooded with cheap solutions and customers who don&#8217;t value the skills required for WordPress development.</p>
<p>Highly skilled developers, who might otherwise be driven away to other more lucrative platforms, often choose to stick with WordPress because of its unique community. If we can find a way to change the culture to value and reward contributors, they will be better positioned to make a living with WordPress. This allows them to create more stable, secure solutions that raise the quality expectations of users across the web.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 04:29:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: iThemes Suffers Security Breach, Customers Urged To Reset Passwords";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31293";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2904:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2009/08/ithemeslogo.png" rel="prettyphoto[31293]"><img class="alignright wp-image-2310 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2009/08/ithemeslogo.png?resize=255%2C69" alt="iThemes Logo" /></a>iThemes published details on a security breach that took place earlier today. According to <a title="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/" href="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/">the announcement</a>, after noticing suspicious activity, they noticed a signification attack on their membership database. iThemes urges all customers to reset their passwords immediately. To protect accounts from any unauthorized access, iThemes has temporarily reset all user passwords. To regain access to your account, you’ll need to <a href="http://ithemes.com/member/password_reset.php">reset your password</a>.</p>
<p>The attackers could gain access to the following customer data:</p>
<ul>
<li>Username</li>
<li>Password</li>
<li>Email address</li>
<li>First and last name (if you set it)</li>
<li>IP address</li>
<li>The names of products you purchased</li>
<li>Coupon codes you might have used</li>
<li>Access times</li>
<li>Payment receipt information (but no other payment info)</li>
</ul>
<p>Since a third-party payment processor is used, credit card information is not at risk of being obtained. iThemes is working to figure out how the attack happened, ensure the security of the rest of their servers, and make sure the site is safe for visitors to browse. The team has outlined a three-step process towards accomplishing these tasks.</p>
<ul>
<li>We are performing a review / audit of our Information Technology (IT) Stack</li>
<li>We are performing a review / audit of our Products and their code base</li>
<li>We are reviewing and updating our Security Incident Response and Detection procedures</li>
</ul>
<p>iThemes is partnering with security service company, <a title="http://sucuri.net/" href="http://sucuri.net/">Sucuri</a>, to help with the discovery process. The CEO of iThemes, Cory Miller, concluded the announcement with the following statement.</p>
<blockquote><p>I deeply apologize for this event. Security is a staple of the service and products we provide and I assure you we will do everything we can to analyze, understand how this occurred and seek to prevent it from happening again.</p>
<p>Know that your personal information is of the utmost priority to me and if you have any questions or concerns, please let us know.</p></blockquote>
<p>Although no business owner wants to go through an experience like this, I give kudos to iThemes for being upfront and honest with their customers instead of waiting for days. If you&#8217;re an iThemes customer, please make the effort to change your password as soon as possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 23:21:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Envato on The State of WordPress Blogging Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31251";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wptavern.com/envato-on-the-state-of-wordpress-blogging-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1521:"<p>Envato has a nice article covering the <a title="http://marketblog.envato.com/trends/current-state-wordpress-blogging-themes/" href="http://marketblog.envato.com/trends/current-state-wordpress-blogging-themes/">current state</a> of WordPress blogging themes. The article does a nice job highlighting not only the styles over the years but the inspiration behind them as well. The design traits profiled include:</p>
<ul>
<li>Modern Single-Column Layout</li>
<li>Traditional Two-Column Layout</li>
<li>The Journal Layout</li>
<li>The Masonry/Grid Layout</li>
</ul>
<p>My favorite style is a toss-up between the journal and single-column layout. That&#8217;s why I&#8217;m psyched to see the <a title="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme" href="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme">Twenty Fifteen default theme</a> go with a clean, two-column layout. I think a lot of sites will use it compared to Twenty Fourteen which was more of a magazine style. Here&#8217;s a look at the various styles used by default themes in WordPress over the years starting with Twenty Ten.</p>
<a href="http://wptavern.com/envato-on-the-state-of-wordpress-blogging-themes#gallery-31251-1-slideshow">Click to view slideshow.</a>
<p>Which style is your favorite and are you happy to see the Twenty Fifteen default theme go back to a more traditional two-column layout? What do you think the next WordPress theme design trend will be?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 22:20:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: BuddyPress Feature Plugin Adds Rich Text Fields to Profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31220";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/buddypress-feature-plugin-adds-rich-text-fields-to-profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4733:"<p>Earlier this year, BuddyPress contributors announced that the project would be adopting the <a href="http://wptavern.com/wordpress-core-development-goes-to-warp-speed-with-features-as-plugins-model" target="_blank">features-as-plugins</a> model to help speed up future development. This is the same development model that has been working well for WordPress core, helping four major features land in the 3.8 release.</p>
<p>The <a href="http://wptavern.com/buddypress-to-adopt-features-as-plugins-model-to-develop-new-media-component" target="_blank">BuddyPress Media Component and Attachment API</a> was the first feature to enter development as a plugin. One of the benefits of using this model, where it makes sense, is that it gets more people involved in creating and testing new features before they are added to BP core.</p>
<h3>Buddypress xProfile Rich Text Field</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text.jpg" rel="prettyphoto[31220]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text.jpg?resize=772%2C250" alt="rich-text" class="aligncenter size-full wp-image-31236" /></a></p>
<p><a href="https://wordpress.org/plugins/bp-xprofile-rich-text-field/" target="_blank">Buddypress xProfile Rich Text Field</a> is the second plugin to present itself as a feature plugin for consideration. It adds a rich-text editor custom field type to extended profiles. <a href="http://haystack.co.uk/" target="_blank">Christian Wach</a>, better known as <a href="https://profiles.wordpress.org/needle/" target="_blank">@needle</a>, created the plugin with the hope that it will be included in BP core.</p>
<p>Once installed, you&#8217;ll find a new profile field type called &#8220;Rich Text Area&#8221; as an option when creating a new field. It&#8217;s essentially a multi-line textarea field with a visual editor added in.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-field-type.png" rel="prettyphoto[31220]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-field-type.png?resize=634%2C338" alt="rich-text-field-type" class="aligncenter size-full wp-image-31222" /></a></p>
<p>Instead of a blank multi-line text box, members will find simple tools for formatting text, links, bullet lists, etc. on the frontend. Having these familiar formatting options available makes it easier for users provide a more readable profile entry, as opposed to a flat block of text.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-profile-fields.png" rel="prettyphoto[31220]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-profile-fields.png?resize=618%2C456" alt="rich-text-profile-fields" class="aligncenter size-full wp-image-31224" /></a></p>
<p>BuddyPress themes that use compatibility mode will automatically work with this plugin. However, if your theme supplies its own BuddyPress template files, you may need to make a few adjustments in order for this plugin to work.</p>
<p>A <a href="https://buddypress.trac.wordpress.org/ticket/5625" target="_blank">ticket</a> is open for discussion regarding adding this feature to BuddyPress 2.2. Christian Wach created a preliminary patch for a Visual Editor field type. BuddyPress core developer Boone Gorges shared his initial <a href="https://buddypress.trac.wordpress.org/timeline?from=2014-09-19T19%3A45%3A34Z&precision=second" target="_blank">thoughts</a> on the patch:</p>
<blockquote><p>We should not have a separate field type for this. IMHO, all multi-line textarea fields should support rich text. In fact, I think we should just turn it on for those fields and not allow it to be turned off (since there&#8217;s a Text tab in addition to the Visual tab), though if others feel differently perhaps we could have an admin toggle to disable on a per-field basis. In any case, I don&#8217;t see a strong case for having a separate field type.</p></blockquote>
<p>This makes sense, as I&#8217;m not sure why you would ever want a textarea field type that doesn&#8217;t have visual editing capabilities. Wach revised his patch to add options to the textarea field type instead of creating a brand new field type. This change appears to be the direction that the feature will take, if it is approved for inclusion in BP core.</p>
<p>In the meantime, you can utilize the <a href="https://wordpress.org/plugins/bp-xprofile-rich-text-field/" target="_blank">Buddypress xProfile Rich Text Field</a> feature plugin to get this working on your site. If the feature is included in BuddyPress 2.2, it will be easy to simply switch the field type to &#8220;multi-line textarea&#8221; when the time comes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 18:33:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Matt: Checky";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://ma.tt/2014/09/checky/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"<p><a href="http://www.checkyapp.com/">Checky tells you how many times a day you check your phone</a>, which Mary Meeker said in 2013 that we do <a href="http://www.kpcb.com/insights/2013-internet-trends">150 times a day</a>. In a brilliant act of marketing, Checky is brought to you by the same people as <a href="http://www.calm.com/">Calm.com</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 07:58:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Matt: Fog of Sadness";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44146";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2014/09/fog-of-sadness/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:412:"<blockquote><p>It’s happened every year for the past five years. Sometimes it sets in the afternoon I arrive home, like today. Sometimes it sets in after I wake up from the post trip nap (last year’s “nap” was 18 hours long, due to sheer exhaustion from too much fun).</p></blockquote>
<p>Lori McLeese on the post-meetup <a href="http://loriloo.com/2014/09/22/the-fog-of-sadness/">Fog of Sadness</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 04:29:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Is It Maintained? Web App Monitors the Activity of Open Source Projects";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31176";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wptavern.com/is-it-maintained-web-app-monitors-the-activity-of-open-source-projects";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3233:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/isitmaintained.jpg" rel="prettyphoto[31176]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/isitmaintained.jpg?resize=1025%2C471" alt="isitmaintained" class="aligncenter size-full wp-image-31184" /></a></p>
<p>If you&#8217;ve ever wondered how well an open source project is maintained, you now have a quick way to get an overview, without scouring the project&#8217;s issues queue or trying to infer something based on its release history. <a href="http://isitmaintained.com/" target="_blank">Is It Maintained?</a> is a new web app that allows you to check the activity of open source projects by plugging in the URL of its public GitHub repository.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/check-a-project.jpg" rel="prettyphoto[31176]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/check-a-project.jpg?resize=830%2C440" alt="check-a-project" class="aligncenter size-full wp-image-31189" /></a></p>
<p>In this example, we&#8217;re checking up on <a href="https://github.com/Varying-Vagrant-Vagrants/VVV" target="_blank">Varying Vagrant Vagrants</a>. The output displays the percentage of open issues and the median closing time for issues.</p>
<h3>Metrics</h3>
<p>Previously, <a href="http://mnapoli.fr/" target="_blank">Matthieu Napoli</a>, the app&#8217;s creator, had considered using release frequency and last commit date as metrics, but dropped those ideas given the difficulty in determining what constitutes a &#8220;good&#8221; or &#8220;bad&#8221; frequency. Currently, the Is It Maintained app measures how well a project is maintained, based on analysis of the following metrics mined from the project&#8217;s repository:</p>
<ul>
<li><strong>Resolution Time</strong> &#8211; Median time needed to close an issue or pull request.</li>
<li><strong>Open Percentage</strong> &#8211; Percentage of open issues and pull requests.</li>
</ul>
<p>It&#8217;s important to note that not all issues in the queue are taken into account. The app ignores issues from collaborators as well as ones with labels like &#8220;feature&#8221;, &#8220;enhancement&#8221;, &#8220;duplicate,&#8221; etc.</p>
<p>In the future, Napoli is considering adding &#8220;reactivity&#8221; into the metrics, which would measure the average time for issue acknowledgement (i.e. first comment after the issue was open).</p>
<p>Browsing the site, you can see projects recently analyzed along with the most popular projects that have been checked. The app can be particularly handy for checking up on a library or framework before building on top of it. Obviously, it only works with open source projects that use GitHub for their central place of development.</p>
<p>Measuring whether or not a project is maintained is not an exact science, but Napoli is committed to improving the app, which is still in alpha version. He&#8217;s open to suggestions and contributions to the project on <a href="https://github.com/mnapoli/IsItMaintained" target="_blank">GitHub</a>. Do you think there&#8217;s any set of metrics that can ever provide a reasonable approximation of how well an open source project is maintained?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 01:28:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WPTavern: Fukasawa: A Free Masonry WordPress Theme for Photographers and Collectors";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31047";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wptavern.com/fukasawa-a-free-masonry-wordpress-theme-for-photographers-and-collectors";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3767:"<p>WordPress theme designer <a href="http://wptavern.com/a-chat-with-anders-noren-on-finding-inspiration-for-wordpress-theme-design" target="_blank">Anders Norén</a> is an unstoppable force, rolling out his ninth free theme to WordPress.org in just over a year. <a href="https://wordpress.org/themes/fukasawa" target="_blank">Fukasawa</a> is a masonry theme designed to showcase the work of photographers, collectors, and visual artists.</p>
<p>The theme is named for Japanese industrial designer Naoto Fukasawa, who is both well-known and highly decorated for his influential work in designing electronics and household appliances. Design is a way of life for Fukasawa, and his works originate out of an awareness of what is natural, an instinctual response to the surrounding environment.</p>
<p>&#8220;I wanted to do a really clean design built with a media-heavy grid in mind,&#8221; Norén said about his latest creation. Fukasawa delivers with its minimalist Pinterest-style layout.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/fukasawa.png" rel="prettyphoto[31047]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/fukasawa.png?resize=880%2C660" alt="fukasawa" class="aligncenter size-full wp-image-31049" /></a></p>
<p>The theme offers support for three post formats, including image, gallery, and video. <a href="http://www.andersnoren.se/themes/fukasawa/the-design-ethos-of-naoto-fukasawa/" target="_blank">Gallery posts</a> include a built-in slideshow of images before the post content. Both galleries and videos play on the home page in addition to the single posts template.</p>
<p>Fukasawa adds support for one sidebar area and five custom widgets, including recent posts, categories, Flickr, Dribble, and a video widget. A few of these can be seen in the sidebar of the <a href="http://www.andersnoren.se/themes/fukasawa/" target="_blank">live demo</a>.</p>
<p>In contrast to the masonry style homepage, Fukasawa includes a highly simplified <a href="http://www.andersnoren.se/themes/fukasawa/archive-template/" target="_blank">archive template</a>, which will populate the page with a list of posts, categories, tags, and contributors to the site.</p>
<p>The theme&#8217;s design is mostly set and your site will look very similar to the demo immediately upon installation. The customizer allows you to upload a custom logo and to change the theme&#8217;s accent color, which is visible in certain elements like blockquotes and links.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/blockquote.png" rel="prettyphoto[31047]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/blockquote.png?resize=730%2C452" alt="blockquote" class="aligncenter size-full wp-image-31086" /></a></p>
<p>Fukasawa integrates with <a href="http://jetpack.me/" target="_blank">Jetpack</a> for adding infinite scroll to load posts without reloading the page. It also includes built-in support for Jetpack <a href="http://jetpack.me/support/tiled-galleries/" target="_blank">Tiled Galleries</a>, which you can preview on the live demo&#8217;s <a href="http://www.andersnoren.se/themes/fukasawa/style-guide/" target="_blank">style guide</a> page.</p>
<p>When composing in the visual editor, you&#8217;ll find that Fukasawa includes matching editor styles to help you visualize your content on the frontend. The theme is also responsive, retina-ready and translation-ready.</p>
<p>If your blog features highly visual posts, then Fukasawa is a solid option for putting the spotlight on your content in an elegant, mobile-friendly way. <a href="https://wordpress.org/themes/fukasawa" target="_blank">Download</a> it for free from WordPress.org or install it via your admin theme browser.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 22 Sep 2014 16:02:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Matt: Automattic Grand Meetup 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44138";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://ma.tt/2014/09/automattic-grand-meetup-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2058:"<p>Although <a href="http://automattic.com/">Automattic</a> is a fully distributed company with most people working from home in 197 cities around the world, we think it&#8217;s really important to meet in person as well and we bring the entire company together once a year. This year we went to Park City, Utah, and were blessed with amazing weather all week. We were right at the base of a mountain so there were beautiful trails for hikes and runs and gorgeous views no matter what direction you looked.</p>
<p><img src="http://i1.wp.com/s.ma.tt/files/2014/09/FullSizeRender-2.jpg?resize=604%2C220" alt="FullSizeRender-2" class="aligncenter size-full wp-image-44143" /></p>
<p>There were all sorts of activities people did throughout the week from paintball to skydiving to a Magic: The Gathering tournament (I played for the first time in about 15 years) and morning running classes every day at 7 am. I went to a Crossfit class with about 15 colleagues. My body is sore but my heart is happy.</p>
<p><img src="http://i2.wp.com/s.ma.tt/files/2014/09/FullSizeRender-1.jpg?resize=604%2C453" alt="Myself and Joe" class="aligncenter size-full wp-image-44144" /></p>
<p>I&#8217;m really grateful that I get to work with the people I do, and on the problems that we work on together. It&#8217;s far from easy, in fact each year brings new challenges and I make mistakes as often as not, but it is worthwhile and incredibly fulfilling. A few hours ago I gave a closing toast and teared up looking around the room. So many folks that give their passion and dedicate themselves to jobs both large and small, visible and unseen, to help make the web a better place. A web that we want to live in. Here&#8217;s a vignette from when we were taking our annual family photo, it&#8217;s a goofy and crazy group of incredibly unique individuals that I hope to know and make things with for many decades to come.</p>
<p><img src="http://i0.wp.com/s.ma.tt/files/2014/09/2014-company-animated.gif?resize=604%2C340" alt="" class="aligncenter size-full wp-image-44139" /></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 22 Sep 2014 03:05:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Matt: Cuomo’s Embarrassment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44134";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2014/09/cuomos-embarrassment/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:576:"<p>Last week in the New York elections my friend who was running for Lieutenant Governor, <a href="http://timwu.org/">Tim Wu</a>, lost. However, <a href="http://www.newyorker.com/news/john-cassidy/cuomos-embarrassment">the New Yorker has a great look at how close the race was</a>. As John Cassidy puts it, &#8220;The strong showing by Teachout and Wu was a victory for progressive voters who warmed to their message about tackling rising inequality, political corruption, and corporate abuses.&#8221; <cite>Hat tip: <a href="http://codybrown.name/">Cody Brown</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 21 Sep 2014 05:57:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Matt: Zero to One";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44104";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:33:"http://ma.tt/2014/09/zero-to-one/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:174:"<p><a href="http://smile.amazon.com/gp/product/B00J6YBOFQ/">Zero to One by Peter Thiel and Blake Masters</a> is one of the best business books I&#8217;ve read in a while.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 20 Sep 2014 10:30:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: Add Remote Libraries to the WordPress Media Library";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=30986";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wptavern.com/add-remote-libraries-to-the-wordpress-media-library";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3366:"<p>WordPress offers excellent oEmbed support for embedding content from more than two dozen major <a href="http://codex.wordpress.org/Embeds" target="_blank">services</a>. Pasting a link into the editor on its own line will have it magically appear as embedded media on the frontend. However, the task of finding that media in another browser window is still required, and this takes you outside of WordPress.</p>
<p>The <a href="https://wordpress.org/plugins/remote-medias-lite/" target="_blank">Remote Media Libraries</a> plugin aims to simplify the process of inserting remote media, while keeping you in the admin. The plugin gives you quick access to content that is hosted on Youtube, Vimeo, or Dailymotion, and presents it as a natural part of your media library.</p>
<p>When setting up the plugin, you can add remote libraries by selecting a service and adding your account username. For example, let&#8217;s say you&#8217;re creating a fitness site and you want quick access to videos from the <a href="https://www.youtube.com/user/FitnessBlender" target="_blank">FitnessBlender</a> account on Youtube. Simply paste the username into the settings.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/add-new-remote-library.png" rel="prettyphoto[30986]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/add-new-remote-library.png?resize=1025%2C347" alt="add-new-remote-library" class="aligncenter size-full wp-image-30989" /></a></p>
<p>Next, you can navigate to the post editor and test the integration by clicking Add Media. Use the menu on the left side of the modal to insert from your remote gallery.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/insert-fitness-blender.jpg" rel="prettyphoto[30986]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/insert-fitness-blender.jpg?resize=1025%2C540" alt="insert-fitness-blender" class="aligncenter size-full wp-image-30990" /></a></p>
<p>The URL for the selected video will be wrapped in an embed shortcode and will display on the frontend like any other video. I&#8217;m not sure why it adds the shortcode as inserting the plain URL would be adequate.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/fitness-video.jpg" rel="prettyphoto[30986]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/fitness-video.jpg?resize=574%2C490" alt="fitness-video" class="aligncenter size-full wp-image-30991" /></a></p>
<p>Currently, the supported remote libraries are limited to Youtube, Vimeo, and Dailymotion, but the plugin author plans to add the following in the near future:</p>
<ul>
<li>Vimeo Pro (make your exclusive videos private right from WP admin)</li>
<li>Instagram</li>
<li>Amazon S3 Services</li>
<li>Cloud files</li>
<li>Flickr</li>
</ul>
<p>Sites that frequently embed media from one or more of the supported video service providers can benefit from having quick access to remote media in the WordPress admin. This is especially helpful for video bloggers who regularly post their most recent video as a blog post. The <a href="https://wordpress.org/plugins/remote-medias-lite/" target="_blank">Remote Media Libraries</a> plugin brings your latest videos into the media library in a way that feels like a natural part of WordPress. Download it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 20 Sep 2014 00:40:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 04 Oct 2014 16:16:31 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"262540";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sat, 04 Oct 2014 16:00:18 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2601, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2611, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1412439391', 'no') ; 
INSERT INTO `wp_options` VALUES (2621, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2631, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 04 Oct 2014 15:53:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"32629@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5468@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress Social Sharing Optimization (with SEO, Video, and eCommerce Integration)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"https://wordpress.org/plugins/wpsso/#post-62149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 00:00:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"62149@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:143:"Make sure social websites present your content correctly, no matter how your webpage is shared - from buttons, browser add-ons, or pasted URLs.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"JS Morisset";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 04 Oct 2014 16:16:31 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Sat, 04 Oct 2014 16:28:34 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Sat, 04 Oct 2014 15:53:34 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2641, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2651, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1412439391', 'no') ; 
INSERT INTO `wp_options` VALUES (2661, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1412482591', 'no') ; 
INSERT INTO `wp_options` VALUES (2671, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2014/09/benny/\'>WordPress 4.0 “Benny”</a> <span class="rss-date">September 4, 2014</span><div class="rssSummary">Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we’ve put a little extra polish into it. This release brings you a smoother writing and management experience [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/contributing-back-to-wordpress\'>WPTavern: Contributing Back to WordPress</a></li><li><a class=\'rsswidget\' href=\'http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/\'>WordPress.tv Blog: Build your audience:  Recent WordCamp videos from experienced content creators</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/5-wordpress-conferences-taking-place-this-weekend\'>WPTavern: 5 WordPress Conferences Taking Place This Weekend</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/wpsso/\' class=\'dashboard-news-plugin-link\'>WordPress Social Sharing Optimization (with SEO, Video, and eCommerce Integration)</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=wpsso&amp;_wpnonce=3bad62512b&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WordPress Social Sharing Optimization (with SEO, Video, and eCommerce Integration)\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (2681, '_site_transient_timeout_wporg_theme_feature_list', '1412450986', 'yes') ; 
INSERT INTO `wp_options` VALUES (2691, '_site_transient_wporg_theme_feature_list', 'a:4:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:6:"Layout";a:9:{i:0;s:12:"fixed-layout";i:1;s:12:"fluid-layout";i:2;s:17:"responsive-layout";i:3;s:10:"one-column";i:4;s:11:"two-columns";i:5;s:13:"three-columns";i:6;s:12:"four-columns";i:7;s:12:"left-sidebar";i:8;s:13:"right-sidebar";}s:8:"Features";a:20:{i:0;s:19:"accessibility-ready";i:1;s:8:"blavatar";i:2;s:10:"buddypress";i:3;s:17:"custom-background";i:4;s:13:"custom-colors";i:5;s:13:"custom-header";i:6;s:11:"custom-menu";i:7;s:12:"editor-style";i:8;s:21:"featured-image-header";i:9;s:15:"featured-images";i:10;s:15:"flexible-header";i:11;s:20:"front-page-post-form";i:12;s:19:"full-width-template";i:13;s:12:"microformats";i:14;s:12:"post-formats";i:15;s:20:"rtl-language-support";i:16;s:11:"sticky-post";i:17;s:13:"theme-options";i:18;s:17:"threaded-comments";i:19;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2701, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1412477586;s:7:"checked";a:5:{s:6:"klasik";s:7:"0.6.9.3";s:17:"organic_nonprofit";s:5:"4.0.6";s:14:"twentyfourteen";s:3:"1.2";s:14:"twentythirteen";s:3:"1.3";s:12:"twentytwelve";s:3:"1.5";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2711, 'theme_mods_klasik', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:8:"mainmenu";i:31;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2721, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2731, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2741, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2751, 'widget_nav_menu', 'a:3:{i:1;a:0:{}i:2;a:1:{s:8:"nav_menu";i:51;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2761, 'widget_klasik-theme-pfilter-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2771, 'widget_klasik-features-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2781, 'widget_klasik-recentposts-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2791, 'widget_klasik-advancedposts-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2801, 'widget_klasik-testimonial-widget', 'a:3:{i:1;a:0:{}i:2;a:6:{s:5:"title";s:15:"Success Stories";s:8:"category";s:1:"1";s:4:"cols";s:1:"1";s:8:"showpost";s:1:"4";s:8:"longdesc";s:0:"";s:11:"customclass";s:12:"eight column";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2811, 'widget_klasik-team-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2821, 'widget_klasik-pcarousel-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2831, 'widget_klasik-action-widget', 'a:5:{i:1;a:0:{}i:2;a:8:{s:6:"mtitle";s:7:"Mission";s:8:"subtitle";s:0:"";s:4:"text";s:195:"The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.";s:8:"buttext1";s:10:"Learn More";s:7:"buturl1";s:8:"/mission";s:8:"buttext2";s:0:"";s:7:"buturl2";s:0:"";s:11:"customclass";s:0:"";}i:3;a:8:{s:6:"mtitle";s:17:"Veteran Mentoring";s:8:"subtitle";s:0:"";s:4:"text";s:152:"Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search.";s:8:"buttext1";s:10:"Learn More";s:7:"buturl1";s:9:"veterans/";s:8:"buttext2";s:0:"";s:7:"buturl2";s:0:"";s:11:"customclass";s:0:"";}i:4;a:8:{s:6:"mtitle";s:11:"Be a Mentor";s:8:"subtitle";s:0:"";s:4:"text";s:289:"Imagine this scenario: A transitioning veteran submits a resume on line reflecting his military leadership skills and commendations. Not only does he not receive any interviews, other than an electronic “We have received your application,” he receives no personal acknowledgement […]";s:8:"buttext1";s:10:"Learn More";s:7:"buturl1";s:12:"be-a-mentor/";s:8:"buttext2";s:0:"";s:7:"buturl2";s:0:"";s:11:"customclass";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2841, 'widget_klasik-page-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2851, 'widget_klasik-latestnews-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2861, 'widget_klasik-events-widget', 'a:3:{i:1;a:0:{}i:3;a:8:{s:5:"title";s:12:"Get Involved";s:8:"category";s:1:"0";s:4:"cols";s:1:"1";s:8:"showpost";s:1:"3";s:8:"longdesc";s:0:"";s:5:"order";s:3:"ASC";s:11:"customclass";s:0:"";s:10:"onlyfuture";s:4:"true";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2891, 'klasik', 'a:13:{s:25:"klasik_disable_responsive";s:1:"0";s:17:"klasik_enable_rtl";s:1:"0";s:21:"klasik_disable_slider";s:1:"0";s:23:"klasik_sidebar_position";s:12:"two-col-left";s:16:"klasik_logo_type";s:9:"imagelogo";s:16:"klasik_site_name";s:0:"";s:14:"klasik_tagline";s:0:"";s:17:"klasik_logo_image";s:87:"http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/BTSlogo-300x37.png";s:14:"klasik_favicon";s:0:"";s:18:"klasik_foot_column";s:1:"3";s:13:"klasik_footer";s:0:"";s:19:"klasik_footerscript";s:0:"";s:16:"klasik_customcss";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3461, '_transient_timeout_feed_c809918297b2c893fd8504c06adcaf00', '1412490334', 'no') ; 
INSERT INTO `wp_options` VALUES (3471, '_transient_feed_c809918297b2c893fd8504c06adcaf00', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WebDevStudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"http://webdevstudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Website Development and Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 17:18:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.9.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:69:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Displaying Your Popular Posts Using Jetpack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://webdevstudios.com/2014/10/02/displaying-your-popular-posts-using-jetpack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:89:"http://webdevstudios.com/2014/10/02/displaying-your-popular-posts-using-jetpack/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 17:18:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:10:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Employee Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:8:"Snippets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:9;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8539";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:399:"Every site owner who is posting fresh, new content frequently wants to have their content read on a regular basis. It does not necessarily matter if it is a returning reader or a brand new one, (though returning readers are &#8230; <a class="more-link" href="http://webdevstudios.com/2014/10/02/displaying-your-popular-posts-using-jetpack/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Michael Beckwith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5037:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/10/jetpack-logo-1080x650.jpg"><img class="alignright size-medium wp-image-8548" src="http://webdevstudios.com/wp-content/uploads/2014/10/jetpack-logo-1080x650-300x180.jpg" alt="jetpack-logo-1080x650" width="300" height="180" /></a>Every site owner who is posting fresh, new content frequently wants to have their content read on a regular basis. It does not necessarily matter if it is a returning reader or a brand new one, (though returning readers are awesome!), what matters is that someone is consuming what you have to post about.</p>
<p>We also appreciate our site analytics and statistics. These help us break down what is going on, who is reading what, what sections of the website get the most traffic, and shape our decisions in the future. For that, we tend to go for either Automattic&#8217;s Jetpack plugin or Google Analytics.</p>
<p>For the purpose of our post today, we are going to focus on Jetpack and the statistics module that comes with it. With this, we will explore how to query for the site&#8217;s popular posts &#8220;for the past X days&#8221; and some ways you could display results to users. This post assumes that you have some experience with PHP and WordPress theme development, as well as the site you are developing for has had Jetpack stats enabled for at least a little while. That way you will have stats recorded and available to query for. If it is a new install or still in development, results may be slim at first.</p>
<h2>Installing our plugin</h2>
<p>First things first, we need to get our PHP class installed and activated on your WordPress install. I have made it into a convenient WordPress plugin for easy activation. You can <a href="http://cl.ly/380Y3Z1g181h">download the plugin</a>, and if you just want to see visually what is in the plugin, you can use this <a href="https://gist.github.com/tw2113/d91939af0da36fc88ecf">GitHub gist</a> with the same contents.</p>
<h2>Creating our object</h2>
<p>Once you have installed and activated, we are ready to get to work using it. The first thing we need to do is instantiate a new object with some parameters for what we want the class to fetch.</p>
<pre class="prettyprint lang-php">$popular_post_object = new WDS_JetPack_Popular_Posts( array( \'count\' =&gt; 5, \'days\' =&gt; 2, \'transient_affix\' =&gt; \'_mypp\' ) );</pre>
<p>We have three parameters available for this, and we will want to pass them in as an array. The first parameter is &#8216;count&#8217; which is for how many posts you want to be returned, and defaults to 5. The second is &#8216;days&#8217; which is for how many days you want to compare between and it defaults to 2. Last is &#8216;transient_affix&#8217; that is used as part of the WordPress transient used that will temporarily store the results in, this one defaults to just &#8216;_popular&#8217; in most places, but adds the &#8220;current queried object ID&#8221; if one exists. This allows for you to query for multiple things on the same page safely without overwriting your previous results.</p>
<h2>Fetching our posts</h2>
<p>After we have specified the parameters we want and instantiated the new object, we are ready to fetch our results and display our results.</p>
<pre class="prettyprint lang-php">$popular_post_results = $popular_post_object-&gt;get_posts();</pre>
<p>This should be the only method you need to call and will assign the results to the variable you specify. If you do not have Jetpack installed and activated the variable will hold a message that lets you know you need Jetpack activated. Otherwise you will receive an array back.</p>
<h2>Displaying our posts</h2>
<p>If you have stats available, the method will return an array of arrays, each that will have indexes of title, permalink, and post_id that hold the corresponding value for each of your popular posts. If there are no posts to display yet, it will return an empty array. For our example we will display ours in an ordered list.</p>
<pre class="prettyprint lang-php">if ( !empty( $popular_post_results ) ) {
	$output = \'&lt;ol&gt;\';
	foreach( $popular_post_results as $popular_post ) {
		$output .= \'&lt;li class=&quot;popular-post-\' . $popular_post[\'post_id\'] . \'&quot;&gt;&lt;a href=&quot;\' . $popular_post[\'permalink\'] . \'&quot;&gt;\' . $popular_post[\'title\'] . \'&lt;/a&gt;&lt;/li&gt;\';
	}
	$output .= \'&lt;/ol&gt;\';

	echo $output;
}</pre>
<p>If all goes well, you should see a list of the top posts from your site, depending on the parameters you used. You can repeat as much as necessary and use as many times as you may need.</p>
<p>As long as Jetpack and this Popular Posts plugin are available and active, you can use them wherever you want in the site you are working on. This could be within your templates, in a custom widget you are creating, or even from a separate plugin. Your imagination is the limit.</p>
<p><a href="http://cl.ly/380Y3Z1g181h">Plugin zip</a> | <a href="https://gist.github.com/tw2113/d91939af0da36fc88ecf">GitHub gist</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:85:"http://webdevstudios.com/2014/10/02/displaying-your-popular-posts-using-jetpack/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:60:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Lisa Sabin-Wilson at Prestige Conference 2014!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://webdevstudios.com/2014/09/30/lisa-sabin-wilson-at-prestige-conference-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:91:"http://webdevstudios.com/2014/09/30/lisa-sabin-wilson-at-prestige-conference-2014/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 14:49:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8519";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:469:"The Prestige Conference is taking place in Downtown Minneapolis, Minnesota from Friday, October 3rd to Saturday; October 4th. This conference is unlike any other! They have sought out the BEST speakers in the WordPress Community to speak on topics related to the economics of WordPress, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/30/lisa-sabin-wilson-at-prestige-conference-2014/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2556:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/09/Prestige-Conference.png"><img class="alignright wp-image-8520 size-full" src="http://webdevstudios.com/wp-content/uploads/2014/09/Prestige-Conference.png" alt="Prestige Conference" width="310" height="191" /></a>The <a href="http://prestigeconf.com/">Prestige Conference</a> is taking place in Downtown Minneapolis, Minnesota from Friday, October 3rd to Saturday; October 4th. This conference is unlike any other! They have sought out the BEST speakers in the WordPress Community to speak on topics related to the economics of WordPress, with the target audience being entrepreneurs in the WordPress industry.  We are honored to have our very own <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a> on the esteemed speakers roster!</p>
<p>Lisa will be speaking on Saturday, October 4th from 11 AM to 11:45 AM. The topic of her presentation is &#8220;<em>You Should Charge More</em>&#8220;. Here is a short description of what you can expect &#8211;</p>
<blockquote><p>As freelancers and entrepreneurs, we are in charge of assigning value to the work that we do. In 2004, as a freelancer, Lisa sold her first WordPress project for $75. Ten years later, as a partner in a thriving web design and development agency, she is frequently involved in projects 1000 times that much, often more.</p>
<p>There are different considerations in pricing as a freelancer, and pricing as an agency. Lisa explores these considerations and shares her insight into common mistakes she made in her career as a freelancer, as well as pricing lessons, strategies and advice she is using today.</p>
<p>This session will explore different pricing models, help you identify signs that your rates might be too low and some similarities and differences between freelancing vs. agency pricing strategies. You&#8217;ll find out how she gradually increased her pricing as a freelancer because one of her (paying) clients encouraged her to do so, and you should be prepared for Lisa to encourage you to do the same!</p></blockquote>
<p>If you can&#8217;t be at the conference physically, that&#8217;s okay. They&#8217;re live streaming the entire thing! You can purchase tickets <a href="http://prestigeconf.com/tickets/">here</a>.</p>
<p>Lisa is proud to speak alongside the <a href="http://prestigeconf.com/#speakers">best of the best</a> in the WordPress community. As always, she is excited to connect with fellow WordPress lovers both new and seasoned.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2014/09/30/lisa-sabin-wilson-at-prestige-conference-2014/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"Why Grids Matter:  A review from chaos to order";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://webdevstudios.com/2014/09/26/why-grids-matter-a-review-from-chaos-to-order/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:91:"http://webdevstudios.com/2014/09/26/why-grids-matter-a-review-from-chaos-to-order/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 16:51:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Employee Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8507";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:379:"For ages, grids have hung prose on pages to the benefit of humanity and to its curse at times. The topic of grids is lost to some, especially in a world that moves so fast. Designers have to, at times, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/26/why-grids-matter-a-review-from-chaos-to-order/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"simon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:11259:"<p>For ages, grids have hung prose on pages to the benefit of humanity and to its curse at times. The topic of grids is lost to some, especially in a world that moves so fast. Designers have to, at times, initiate the creative process on a computer without even so much as a sketch. On the other hand, grids are held as the construct of beauty by many. Yet, we as designers must know the limits of our craft before limits can be broken <i>the right way</i>.</p>
<p>If you have no idea what I am talking about, let me try to explain. Grids make sense out of nonsense. In a world that seems chaotic and void of order, if you look closely at nature and ourselves we can see a mysterious link through the prism of a grid.</p>
<p>Grid Systems are everywhere. Look in the mirror, your face is a grid (of sorts). Look at the Parthenon &#8211; it’s a grid though not completely as some say. Look at the Mona Lisa &#8211; there’s a vanishing point. Look at a magazine or a car, all of which have grid like measures and with all the same “limitations” we so often complain about.</p>
<p>What you’ll read here will be more for art than science, more history than future, more vegetable than cupcake. There are plenty of resources to the latter with snippets galore and with much needed code monkey snark.</p>
<p>By definition grid systems are limited to the graphic design world and world of design. In this post I want to share how there are shared qualities in the natural world and the digital one. Here my goal is to sharpen our craft by sharing my own experiences with grids and it’s cousins like the Golden Ratio or Fibonacci number, etc.</p>
<p><b>Chaos</b></p>
<p>This is not a post to dictate to others that using a grid is the only way to success. Because, it is not. Rather, this is a post to cultivate an appreciation for grid-driven design, while taking from the natural world. Even if you don’t leverage grids, there is a historic and mysterious value.</p>
<div id="attachment_8511" style="width: 218px" class="wp-caption alignright"><a href="http://webdevstudios.com/wp-content/uploads/2014/09/66439_254x191.jpg"><img class=" wp-image-8511" src="http://webdevstudios.com/wp-content/uploads/2014/09/66439_254x191.jpg" alt="Graphic Designer - David Carson" width="208" height="157" /></a><p class="wp-caption-text">Graphic Designer &#8211; David Carson</p></div>
<p>I write and ponder this as a humble designer that started without using grids in the late 80’s. <a href="http://en.wikipedia.org/wiki/David_Carson_(graphic_designer)">David Carson</a> believes a good designer should bring in who he or she is, what shaped them, and their history. David was my hero at the time.</p>
<p>I emulated his approach to design / life and the time he spent surfing appealed to me. So in the 90’s that is exactly what I did. I rejected a scholarship to a prestigious art school and learned from life. These experiences are adventures that my midwestern wife appreciates and shakes her head. I surfed for a better part of a decade and designed for clients like United Colors of Benetton. I was in the apparel industry as a creative director for a now defunct jean company. It was a good time for me. That’s where I am coming from &#8211; a life rich in experience and endeavoring in the arts.</p>
<p>David Carson doesn’t depend on grids so much, but depends on intuition and I completely agree with this approach. I prefer to call it intelligent intuition as “gut feeling” seems to create risk aversion from even the most adventurous among us. A lot more emphasis should be based on intelligent intuition when designers are trained. Yet, higher schools of learning turn away from intuition as having any real measurable value. The funny thing is these gut feelings a lot of times are based on what the designer has seen and experienced which are Grid Systems. Intrinsically, I believe all artists and designers are skewed by grids even while not knowing it.</p>
<p>Within every human living in what seems to be a chaotic universe there is an underlying order. This is a bit philosophical, but I want to emphasize designers have to develop a taste for appreciation of art with critical thinking.</p>
<blockquote><p>  Via <a href="http://www.creativebloq.com/design/designers-guide-golden-ratio-12121546" target="_blank">Creative Bloq</a><a href="http://webdevstudios.com/wp-content/uploads/2014/09/fibonaccispiral.jpg"><img class="aligncenter size-full wp-image-8512" src="http://webdevstudios.com/wp-content/uploads/2014/09/fibonaccispiral.jpg" alt="fibonaccispiral" width="535" height="338" /></a></p>
<p style="color: #333333">It&#8217;s believed that the Golden Ratio has been in use for at least 4,000 years in human art and design, but it may be even longer than that &#8211; some people argue that the Ancient Egyptians used the principle to build the pyramids. In more contemporary times, the Golden Ratio can be observed in music, art, and design all around you.</p>
</blockquote>
<p>You may say that the Golden Ratio or Fibonacci numbers don’t mean anything to web designers&#8217; work or are not even related to grids, but it really does and they are. I make no claims that I totally understand what I am so humbly trying to communicate. In fact, it’s overwhelming to me. But, I can observe this world, I see patterns therein, and for our purposes observe grids.</p>
<p>I consider Golden Ratio, Fibonacci number, Golden Mean, Golden String, Grids, Grid Systems, are different yet the same. They are locked in place in the natural world and if done right on your next WordPress theme, which is hopefully created by WebDevStudios.</p>
<p>Design without grids can be wonderful. Having experienced it first hand professionally, it was then and is now fun. But, there is more to the grid (order) story.</p>
<p><b>Order</b></p>
<p>For ages designers (whatever the label) have been tasked with creating on pages that are limited by page edges. Think from book spine to bleeding page edge. The measure and the page are set and it’s values are simple for the implementation of any design works. That is to say, we design limited by the width, height, and page content of the work to be delivered. Simple right?</p>
<p>So works like typographically heavy invitations, photography, or paintings can use grids in a broad sense. We won’t ponder the immense mystery of Golden Ratio and a like, but to me these are all linked under a purposeful creative order with beauty as the goal. It’s also worth noting that there is a lot of debate and misconceptions on related subject matter.</p>
<p>I am not here to blaze a trail and solve those misconceptions. Here I will just observe, know, and  communicate what I think I know. For example, the Parthenon does share the golden ratio, but not totally. You get the point.</p>
<p>Having said that, I have never met someone that didn’t love beautiful things and those beautiful things are naturally suspended in order.</p>
<p><b>Hey, Grid Face</b></p>
<p>Look in the mirror and there is a grid staring back at you. All faces are different, but there is an intrinsic order that is undeniable. As a trained illustrator we were taught to start with boxes &#8211; grids. That isn’t something that is asymmetric or totally unique just to you. We can observe there are faces of varying sizes on a grid like there are also pages of different sizes using a grid. This is amazing! Consider for a moment that there is a grid that we all share &#8211; our face.</p>
<p>Via <a href="http://www.goldennumber.net/golden-ratio-myth/">Golden Number</a></p>
<blockquote>
<p style="color: #232323">“<a href="http://www.goldennumber.net/beauty/">Does the human face reflect golden ratios in its proportions?</a> Not everyone will agree, but there is much evidence to demonstrate that the answer is ‘Yes.’”</p>
</blockquote>
<p>We love beauty and by extension order not chaos.</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/kKWV-uU_SoI?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
<p><b>Grid Zen</b></p>
<p>I recall discussing design with a new business school graduate. He told me in no uncertain terms, “design means nothing”. In other words, what he meant to say was that design as a part of a business strategy is not a driving factor in it’s success. That’s quite a claim.</p>
<p>Consider Nike for a moment. Does design matter for them? Are they just an outlier? Well, maybe Apple doesn’t need design. I guess Microsoft’s brand refresh was for not? The real truth is some companies are successful <i>despite not having any taste to begin with</i>, but that doesn’t mean design doesn’t matter. That means some companies are just lucky.</p>
<p>Today we have a set of viewports that are changing and iterating over time. So a work may require you to design for responsive design with no limit on height most times.</p>
<p>Many say that there are no longer page edges or grids just content driving the design of a grid &#8211; inward to outward. I would disagree about edges, but agree on content. Of course, content or in marketing parlance “value”, should always drive work and I think in a sense successful initiatives always do.</p>
<p>The real difference now is there are just more edges. Not only are there still the same edges in a book, but now there are more edges in the form of viewports. There are more edges, not less. There are more opportunities, not less.</p>
<p><b>All paths lead to Grids.</b></p>
<p>The paths of designers are varied as shells on a beach. Some have been trained from print forward and some straight into web design from other mediums. Some couldn’t draw to save their life. We are different in the design universe, yet we are the same.</p>
<p>Some designers design by intelligent intuition and some don’t. Yet we can observe, that while some are outwardly grid agnostic, they subconsciously design with Grid Systems pointed towards a greater order with beauty as the goal.</p>
<p>As a trained artist I can tell you that my process for illustrating isn’t so different when I am creating a website design. I start with a draft and using boxes I illustrate a human face. In web design I start with sketches, then finalize the work from sketch to grid.</p>
<p>If you were to (without mortal limitations) travel in one direction forever into space you would be limited by direction but not the destination. Design is similar. The design life is a paradoxical one. Because, we are limited. But, only because of ourselves and what we think we know.</p>
<p>I hear many times from colleagues that grids are useless and mean nothing. I think they are speaking on the actual code with which they are frustratingly trying to theme a design. I get that. However, grids and all it’s related cousins hold immense hidden value to those designers especially. And, it should be an arrow in your quiver too. If it isn’t, maybe you should look in the mirror. Because, looking back at you is a beautiful grid.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2014/09/26/why-grids-matter-a-review-from-chaos-to-order/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"How To QA WordPress Websites Like A Pro!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://webdevstudios.com/2014/09/18/how-to-qa-wordpress-websites-like-a-pro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:85:"http://webdevstudios.com/2014/09/18/how-to-qa-wordpress-websites-like-a-pro/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 18 Sep 2014 15:24:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:13:"Employee Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8491";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:380:"You&#8217;ve pushed your final bit of code and crossed the final item off of your to-do list. Now it&#8217;s just time to sit back, relax and wait for all of the praise on a job well done to come rolling in, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/18/how-to-qa-wordpress-websites-like-a-pro/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Corey Collins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:9018:"<p>You&#8217;ve pushed your final bit of code and crossed the final item off of your to-do list. Now it&#8217;s just time to sit back, relax and wait for all of the praise on a job well done to come rolling in, right?</p>
<p>Wrong.</p>
<h2>WRONG WRONG WRONG.</h2>
<p>Just because you think you&#8217;re done with a site doesn&#8217;t mean that you&#8217;re actually done with the site. I&#8217;m pretty sure Confucius said that. And what that means, basically, is that once you&#8217;ve pushed your &#8220;final&#8221; code and crossed off that final to-do there are still one million things left for you to do. Yes, you think everything looks good in whatever browser you&#8217;ve been working in, but have you considered other browsers and their thoughts? Their feelings? The way they handle your pseudo elements, or the way they display an SVG font as a craggly mess? You didn&#8217;t think about that, did you?</p>
<h2>GOD, YOU&#8217;RE SO INSENSITIVE!</h2>
<p>But we can help with that insensitivity.  That lack of a second-thought you give to the way your favorite browser works on another operating system, and the way your least-favorite browser mangles all of the delicate beauty you&#8217;ve painfully crafted over the last six weeks.</p>
<p>Around these parts, it used to be that I would complete a site and proudly watch as it entered the QA process.  I would smile along with any other designers with whom I had worked on the project, a little smug in our belief that the entire QA process would be totally fruitless for the QA&#8217;er.  How could they find anything wrong with something so wonderful?  We&#8217;ve made their job so easy!  Soon, there wouldn&#8217;t even be a need for a QA&#8217;er to QA anything what with all of the certified gold we were churning out.</p>
<blockquote><p><span style="color: #000000">Let me like myself sometimes</span><br style="color: #000000" /><span style="color: #000000">Let me be narcissistic sometimes</span><br style="color: #000000" /><span style="color: #000000">I&#8217;m not like this all the time</span></p>
<p>- Everyone Everywhere, &#8220;<a title="Everyone Everywhere, &quot;I Feel Fine by Everyone Everywhere&quot;" href="http://everyoneeverywhere.bandcamp.com/track/i-feel-fine-by-everyone-everywhere" target="_blank">I Feel Fine by Everyone Everywhere</a>&#8220;</p></blockquote>
<p>It is in those moments where I now realize how gravely I overestimated our aforementioned gold and how deeply I underestimated the QA prowess of one Lisa Sabin-Wilson.  You don&#8217;t know true shame until you&#8217;ve passed off a site for QA and see it come back with three dozen new to-dos.  Well, until you look at the to-dos and realize how easily these QA issues could have been fixed.  You can tell yourself whatever you need to tell yourself to try and feel better about it &#8211; you&#8217;ve been looking at it for so long that it&#8217;s easy to miss the little things.  Right?  That&#8217;s a real thing, right?  What it comes down to, though, is that you&#8217;ve overlooked some pretty obvious and easy things and being called out on those via the QA process is like a punch to the head, heart and ego.</p>
<blockquote><p><span style="color: #000000">I want to smash things</span><br style="color: #000000" /><span style="color: #000000">I want a coffee</span><br style="color: #000000" /><span style="color: #000000">I want to punch myself repeatedly</span></p>
<p>- Everyone Everywhere, &#8220;<a title="Everyone Everywhere, &quot;I Feel Exhausted&quot;" href="http://everyoneeverywhere.bandcamp.com/track/i-feel-exhausted" target="_blank">I Feel Exhausted</a>&#8220;</p></blockquote>
<p>It didn&#8217;t take long for me to realize that I needed to change the way I was doing things so the resulting product would have a much easier and simpler QA process once it left my hands.  Damn it, I&#8217;d QA the site myself before I even handed it off to someone else!  As a Front-End Lead at WebDevStudios, that came as part of the job so my rallying cry to myself is more of a way to pump myself up than me shaking the foundation of QA itself.  But hey, if you can&#8217;t be proud of the work you&#8217;re doing and get yourself excited to do it, then what&#8217;s the point of doing anything?  Why even get out of bed?  Why even wake up, ya damn bum?</p>
<p>So, what&#8217;s the big secret?  How do I QA sites before I pass them off for a final review, ensuring that all of the little things have been sewn up?</p>
<h2>Spreadsheets.</h2>
<p>Yep.  Spreadsheets.</p>
<p>I didn&#8217;t know what would be the best way to organize my QA thoughts.  I broke out a pen and paper and scrawled chicken scratch into shoddy columns, making notes of which browser rendered something too weird to accept.  Even then, though, you can miss things because you&#8217;re still working against your own brain and memory.  Work-as-you-go QA still allows for things to be left behind.</p>
<p>My first step in the QA process is to visit the WordPress dashboard.  I look at the sidebar and begin making a list of all of the various post types.  Posts and Pages, of course, but then any other custom post types that may have been registered.  We&#8217;re not just listing the post types, though &#8211; we want to be as granular as possible.  Post archives, single posts, post type-specific sidebars, etc.</p>
<p>What about taxonomies?  Categories, tags, custom taxonomies &#8211; you&#8217;re going to want to make sure you&#8217;re looking at those, too.  Sure, maybe you&#8217;re using a single archive template file to power all of your archive pages, but don&#8217;t be so sure that something weird won&#8217;t crop up on a custom taxonomy page just because your category archive page looks terrific.  Expect the unexpected, and then go fix it.</p>
<p>And for the love of God, don&#8217;t forget the search results or 404 pages.</p>
<p>When all is said and done, I wind up with something like this:</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2014/09/Screenshot-2014-09-17-22.34.15.png"><img class="alignnone size-large wp-image-8492" src="http://webdevstudios.com/wp-content/uploads/2014/09/Screenshot-2014-09-17-22.34.15-1024x478.png" alt="A shiny new QA spreadsheet" width="640" height="298" /></a></p>
<p>While I walk through the QA process, browser-by-browser, I eventually wind up with something like this:</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2014/09/Screenshot-2014-09-17-22.39.49.png"><img class="alignnone size-large wp-image-8493" src="http://webdevstudios.com/wp-content/uploads/2014/09/Screenshot-2014-09-17-22.39.49-1024x594.png" alt="Christmas comes but once a year" width="640" height="371" /></a></p>
<p>It&#8217;s the most wonderful time of the year, isn&#8217;t it?</p>
<p>As you can see, I block cells out with green if they&#8217;re good to go and red if they&#8217;re bad to go.  In addition to the red menace, I&#8217;ll add a number with a corresponding note that falls below.  This way, I can organize my thoughts and add individual, granular tasks into Basecamp so I can help track the process a bit more.  Plus, rather than fixing everything immediately as I see it, this allows me to see if there are any trends across browsers (this is why you see numbers repeating across columns).  If something is breaking in all but one or two browsers, then maybe it&#8217;s something I&#8217;m doing wrong and not something the browsers are doing wrong.</p>
<p>Since implementing this method for myself, I really feel that the quality of my QA&#8217;ing has increased exponentially.  Now, instead of just running through the site and telling myself I&#8217;ve checked off all of the possible pages, page templates, post type archives, etc., I can sit confidently knowing that &#8211; yes, I DID check that post type out or no, I did NOT remember to check a specific page template.  At this point, I&#8217;ll add it to my spreadsheet and start the process on that single item once again.  Maybe you&#8217;re telling yourself that, in the final stages of QA, you&#8217;d rather just check the items you may have forgotten without opening up the spreadsheet again.  But what&#8217;s the point of that?  If you&#8217;re writing everything down and making notes of everything you&#8217;re seeing, you can rest assured that you have absolutely, positively, 100% checked everything that you had needed to check.</p>
<p>I&#8217;m not saying that this is the best way or the only way to QA.  Everyone works differently and what works best for one person may not work as well for the next.  For me, though, being able to block out each portion of the site and make a visual mark of the work I&#8217;ve done QA&#8217;ing it has been hugely beneficial.</p>
<p>Want to give it a whirl?  <a title="QA Spreadsheet" href="https://dl.dropboxusercontent.com/u/37615265/QA%20Spreadsheet.xlsx" target="_blank">Download this handy spreadsheet</a> and get on your way!  Go on, get!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:81:"http://webdevstudios.com/2014/09/18/how-to-qa-wordpress-websites-like-a-pro/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Chris Reynolds Speaking at WordCamp Salt Lake City";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2014/09/10/chris-reynolds-speaking-at-wordcamp-salt-lake-city/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://webdevstudios.com/2014/09/10/chris-reynolds-speaking-at-wordcamp-salt-lake-city/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 10 Sep 2014 15:00:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8467";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:421:"WordCamp Salt Lake City is taking place on Saturday, September 13th at the City and County Building. During this event, you will have the opportunity to meet WDS team member, Chris Reynolds. Chris has been involved with WordCamp Salt Lake &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/10/chris-reynolds-speaking-at-wordcamp-salt-lake-city/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2160:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/09/WordCamp-Salt-Lake-City.png"><img class="alignright wp-image-8468 size-medium" src="http://webdevstudios.com/wp-content/uploads/2014/09/WordCamp-Salt-Lake-City-287x300.png" alt="WordCamp Salt Lake City" width="287" height="300" /></a><a href="http://2014.slc.wordcamp.org/">WordCamp Salt Lake City</a> is taking place on Saturday, September 13th at the City and County Building. During this event, you will have the opportunity to meet WDS team member, <a title="Chris Reynolds" href="http://webdevstudios.com/team/chris-reynolds/">Chris Reynolds</a>. Chris has been involved with WordCamp Salt Lake City since 2011, both speaking and co-organizing. This year is no different &#8212; he helped organize the event and he will be presenting to the attendees.</p>
<p>You can catch Chris&#8217; presentation on <strong>Saturday, September 13th at 9:50 AM</strong> in the developer track. He will be speaking to you about <a style="font-style: italic;color: #1982d1" title="Speaker Announcement — Chris Reynolds" href="http://2014.slc.wordcamp.org/2014/08/12/speaker-announcement-chris-reynolds/">Why Hacking WordPress Search Isn’t Some Big Scary Thing</a>. Here is a short description of his talk &#8211;</p>
<blockquote><p><span style="color: #3c363e">Developers can be a stubborn lot. We like to focus on the things we know really well, and things we don’t deal with as often can be seen as “hard”. Search is one of those things that gets written off a lot, few devs I know will deal with it (voluntarily), and almost everyone will tell you “WordPress search sucks.” In this presentation you will learn that not only do you know more about how search works than you thought you did, but maybe give you a better understanding of how WordPress works as a whole, as well as showing you some cool tricks that you can do with WordPress search.</span></p></blockquote>
<p>Chris is excited to connect with people who share his love for WordPress; both those he&#8217;s met and those he has yet to meet. If you see Chris around the venue, don&#8217;t be afraid to go up to him and chat!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://webdevstudios.com/2014/09/10/chris-reynolds-speaking-at-wordcamp-salt-lake-city/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"WDS Welcomes Nate Schaumburg!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2014/09/09/wds-welcomes-nate-schaumburg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2014/09/09/wds-welcomes-nate-schaumburg/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 09 Sep 2014 19:22:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8477";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:405:"WDS is proud to announce our newest team member, Nate Schaumburg! He will be joining as a Front-End developer. Nate, a native of Wisconsin, has been developing websites since 2004. In 2007, he discovered WordPress and began developing themes as &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/09/wds-welcomes-nate-schaumburg/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1301:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/09/schaumburg.jpg"><img class="alignright size-medium wp-image-8478" src="http://webdevstudios.com/wp-content/uploads/2014/09/schaumburg-300x300.jpg" alt="schaumburg" width="300" height="300" /></a>WDS is proud to announce our newest team member, <a title="Nate Schaumburg" href="http://webdevstudios.com/team/nate-schaumburg/">Nate Schaumburg</a>! He will be joining as a Front-End developer.</p>
<p>Nate, a native of Wisconsin, has been developing websites since 2004. In 2007, he discovered WordPress and began developing themes as a hobby and for freelance work. He has worked with top theme developers from WordPress.com and looks forward to working on great client projects for WebDevStudios.</p>
<p>Prior to web development, Nate was an aviation enthusiast. He has flight hours in both single engine planes and gliders.</p>
<p>For fun, Nate develops free themes for the <a href="https://ghost.org/" target="_blank">ghost.org</a> platform. He also enjoys going to the shooting range. You can follow Nate&#8217;s love of WordPress on <a href="https://twitter.com/___nate" target="_blank">Twitter</a>.</p>
<p>We are excited to have Nate joining the team and can&#8217;t wait to see what awesomeness he will add to our amazing team!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2014/09/09/wds-welcomes-nate-schaumburg/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Ben Lobaugh Joins WDS as Developer Lead!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://webdevstudios.com/2014/09/08/ben-lobaugh-joins-wds-as-developer-lead/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:85:"http://webdevstudios.com/2014/09/08/ben-lobaugh-joins-wds-as-developer-lead/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 08 Sep 2014 16:04:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8469";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:393:"WDS is proud to welcome our newest team member, Ben Lobaugh! He is joining us as a Developer Lead. Ben is a native born Washingtonian currently living in the beautiful Seattle area. He has been involved in the open source &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/08/ben-lobaugh-joins-wds-as-developer-lead/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3265:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/09/IMG_8172.jpg"><img class="alignright size-medium wp-image-8470" src="http://webdevstudios.com/wp-content/uploads/2014/09/IMG_8172-300x225.jpg" alt="IMG_8172" width="300" height="225" /></a>WDS is proud to welcome our newest team member, <a title="Ben Lobaugh" href="http://webdevstudios.com/team/ben-lobaugh/">Ben Lobaugh</a>! He is joining us as a Developer Lead.</p>
<p>Ben is a native born Washingtonian currently living in the beautiful Seattle area. He has been involved in the open source community since 1998 and wrote his first line of code over 14 years ago! His web career has involved working with companies small and large, hyper-local and multi-national.</p>
<p>Ben first encountered WordPress due to laziness. All his work used to be on fully custom solutions for clients and as such he wrote his own blogging software, sort of. It worked well enough to make a post but did not have any features. After a couple years of no progress, Ben installed WordPress to handle just the blogging portion of his website. As WordPress progressed it became powerful enough to meet the needs of his more generalized clients and he switched to it full-time and stopped writing custom solutions. After moving to Seattle, Ben found and became involved in the WordPress Meetup group and the rest is history. Being involved in the WordPress community is a rich and fulfilling experience.</p>
<p>In his free time, Ben is the editor of the <a href="http://make.wordpress.org/docs/">WordPress.org Plugin Developer Handbook</a>, outdoorsy adventurer, and intrepid sailor. He owns a beautiful 23&#8242; sailboat named <a href="http://ben.lobaugh.net/blog/887/new-toy-north-american-spirit-23-zzzippety-doo-dah">zzZippety Doo Dah</a> (Zippey for short) that he takes out for leisurely cruises and <a href="http://ben.lobaugh.net/ship-log/a-weekend-at-blake-island">island adventures</a>. Ben&#8217;s other boat is a <a href="http://ben.lobaugh.net/ship-log/introducing-my-new-1977-33-carver">33&#8242; Carver cabin-cruiser</a> that he is currently in the process of turning into a liveaboard. Nothing beats being on the water and letting a boat gently rock you to sleep.</p>
<p>When asked why he was excited to join WDS, Ben had this to say &#8211;</p>
<blockquote><p>Everyone in the WordPress community has heard of <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a>, <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a>, and <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a>. Not only are they highly regarded WordPressers; they are genuinely good people. After a delicious but painful outing with Brad at the most delicious build your own burger joint in Orange County, I knew WebDevStudios would be a great place to work. As I got to know the team and projects I became more impressed with the company. I found myself referring clients to WebDevStudios and knew it was a match made in heaven.</p></blockquote>
<p>We are extremely excited to have Ben joining the team. We can&#8217;t wait to see what he will bring to an already spectacular team!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:81:"http://webdevstudios.com/2014/09/08/ben-lobaugh-joins-wds-as-developer-lead/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:66:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Better Responsive Typography";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2014/09/04/better-responsive-typography/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2014/09/04/better-responsive-typography/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Sep 2014 15:52:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:9:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Employee Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:8:"Snippets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8459";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:386:"Any smartphone user has probably noticed and been annoyed by sites (even responsive ones) that are difficult to read or just don’t look quite right. I know I&#8217;ve been annoyed by trying to view a website on my phone and &#8230; <a class="more-link" href="http://webdevstudios.com/2014/09/04/better-responsive-typography/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Zack Rothauser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5466:"<p>Any smartphone user has probably noticed and been annoyed by sites (even responsive ones) that are difficult to read or just don’t look quite right. I know I&#8217;ve been annoyed by trying to view a website on my phone and having to strain to read the text, or given up waiting on a page to load due to a slow connection or just a half-considered mobile layout. With more and more web traffic coming from mobile users, web designers have to be concerned with how readable text is on any type of screen.</p>
<h2>Font Size</h2>
<p>What device are you currently reading this article on, and how far away are you sitting? Most people sit between 18 and 24 inches from a desktop or laptop display, but hold a phone or tablet significantly closer. To make up for this distance, you can use larger type for larger displays and smaller type on mobile displays. However, the line length needs to be considered along with the type size and layout.</p>
<h2>Line Length and Line Height</h2>
<p>An often-overlooked element of typography on the web is line length. According Robert Bringhurst, in <em>The Elements of Typographic Style</em>, the optimal line length is between 45 and 75 characters, with 66 characters being the “ideal”. Setting the body text of a website in this range allows the user to read quicker and stay engaged longer.</p>
<p>Line height should go along with line length. As the screen becomes wider and the line becomes longer, the space between lines needs to increase so that the eye can quickly find the next line. Too much space between lines can look awkward on smaller screens. So whereas a line-height of around 1.5 may work well for desktop displays, a line-height of 1.2 may be better for mobile devices. However, there is no ideal line-height, so it may take some adjustments to find the best line height for the various screen sizes.</p>
<h2>Web Fonts on Mobile</h2>
<p>Should you include web fonts for narrow screens, or use them only on desktop displays? Web fonts by now are a standard practice for many reasons — consistency between browsers and OSes, better designed typefaces, and giving the site a unique look. But if you use more than one, they can quickly add on 300–400KB to a page’s size, increasing load time and bandwidth usage, which is especially important to consider for mobile devices.</p>
<p>One of the issues with using the system fonts on mobile devices is inconsistency. Android devices only come with 4 fonts, which are not included on iOS, Windows, or Mac devices. If we want to provide a consistent experience for our website across devices, we will have to include at least <strong>some</strong> web fonts.</p>
<p>How can this be done without adding on too much weight to a page? Reduce the number of fonts loaded on mobile. This is easily done with media queries and mobile-first practices. Even if a font is defined with <code>@font-face</code>, it will only be downloaded by the browser if it is used somewhere in the site’s CSS. A mobile browser will disregard any fonts mentioned within media queries that don’t apply to the device, so if you load the heaviest fonts inside of your <code>min-width</code> media queries, you can avoid downloading them on mobile devices.This way, you can create a subset of your web fonts to be loaded on a mobile device.</p>
<p>Here, I&#8217;m only downloading Open Sans at two font weights on mobile, and adding in a different typeface for desktop users. The user will see a bit more consistency because we&#8217;re at least using Open Sans for both mobile and desktop, but they can avoid downloading any extra fonts beyond that.</p>
<pre class="prettyprint linenums lang-cs">/* Declare the font-faces, but they won\'t necessarily be downloaded until they\'re used */
@font-face {
	font-family: \'Open Sans\';
	font-style: normal;
	font-weight: 400;
	src: local(\'Open Sans\'), local(\'OpenSans\'), url(http://fonts.gstatic.com/s/opensans/v10/cJZKeOuBrn4kERxqtaUH3ZBw1xU1rKptJj_0jans920.woff2) format(\'woff2\');
}

@font-face {
	font-family: \'Open Sans\';
	font-style: normal;
	font-weight: 700;
	src: local(\'Open Sans Bold\'), local(\'OpenSans-Bold\'), url(http://fonts.gstatic.com/s/opensans/v10/k3k702ZOKiLJc3WVjuplzBampu5_7CjHW5spxoeN3Vs.woff2) format(\'woff2\');
}

@font-face {
	font-family: \'PT Serif\';
	font-style: normal;
	font-weight: 700;
	src: local(\'PT Serif Bold\'), local(\'PTSerif-Bold\'), url(http://fonts.gstatic.com/s/ptserif/v8/QABk9IxT-LFTJ_dQzv7xpJQV2lvL5Ba9FjAYK6Lx0Qk.woff2) format(\'woff2\');
}


/* Mobile layout by default */
/* We\'ll only use one web font here */
body {
	font-family: &quot;Open Sans&quot;, sans-serif;
	font-size: 16px;
	line-height: 1.25;
}

/* Use the same font for headings on mobile */
h1 {
	font-weight: bold;
	font-size: 36px;
}

h2 {
	font-weight: bold;
	font-size: 24px
}

@media (min-width: 768px) {
	body {
		line-height: 1.5;
	}
	
	/* Now that we\'re at a larger screen size, we\'ll load the second font */
	/* The browser will only download PT Serif if the screen size is wider than 768px */
	h1, h2 {
		font-family: &quot;PT Serif&quot;, serif;
	}
}</pre>
<h2>Read More:</h2>
<p><a href="http://trentwalton.com/2012/06/19/fluid-type/">“Fluid Type”</a> by Trent Walton</p>
<p><a href="http://frankchimero.com/talks/what-screens-want/transcript/">“What Screens Want”</a> by Frank Chimero</p>
<p><em><a href="http://www.abookapart.com/products/on-web-typography">On Web Typography</a></em> by Jason Santa Maria</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2014/09/04/better-responsive-typography/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:66:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Integrating Font Awesome icons in bbPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://webdevstudios.com/2014/08/28/integrating-font-awesome-icons-in-bbpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2014/08/28/integrating-font-awesome-icons-in-bbpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 28 Aug 2014 18:33:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:9:{i:0;a:5:{s:4:"data";s:7:"bbPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Employee Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Snippets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:7:"Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8438";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:439:"The amount of thought and time that goes into designing a universally accepted icon is amazing.  Choosing when to utilize icons to represent interfacing elements is paramount to whether users will understand, and seamlessly navigate areas of a website. Previously, &#8230; <a class="more-link" href="http://webdevstudios.com/2014/08/28/integrating-font-awesome-icons-in-bbpress/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Damon Cook";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:12181:"<p>The amount of thought and time that goes into designing a universally accepted icon is amazing.  Choosing when to utilize icons to represent interfacing elements is paramount to whether users will understand, and seamlessly navigate areas of a website.</p>
<p>Previously, website icons consisted of small images, and sometimes image sprites. Creating and maintaining these images was cumbersome, and integration tedious at times.</p>
<p><img class="alignright  wp-image-8439" src="http://webdevstudios.com/wp-content/uploads/2014/08/font-awesome-logo-300x300.png" alt="Font Awesome icon fonts FTW!" width="187" height="187" />Recently, icon fonts have paved the way for expedient delivery of icons. Libraries of font icons have become prevalent, one of which is <a href="http://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome</a>.</p>
<p>Let&#8217;s get started with integrating Font Awesome icons with bbPress forums, but first I would like to point out this bbPress Trac ticket that created the filter necessary to add this functionality. This may be a helpful reference: &#8220;<a href="https://bbpress.trac.wordpress.org/ticket/2090">New Filters for Topic/Reply Admin Links</a>.&#8221;</p>
<p>First we must enqueue the Font Awesome library script in our theme. Although, you could use a plugin: <a href="https://wordpress.org/plugins/font-awesome/">Font Awesome Icons</a>, but we&#8217;re going to be smart about it since we&#8217;re going to be utilizing Font Awesome in other areas of our site, and keep it in our theme.</p>
<p><code>wp_enqueue</code> to the rescue!</p>
<pre class="prettyprint lang-php">$cdn_url = \'//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\';

wp_register_style( \'font-awesome\', $cdn_url );

wp_enqueue_style( \'font-awesome\' );</pre>
<p>Drop that snippet in your theme&#8217;s <code>functions.php</code> file, and now we have Font Awesome loading on every page. (Of course, if you would like to limit loading to only the necessary pages you could use one of the many handy-dandy <a href="https://codex.wordpress.org/Conditional_Tags">conditionals</a>.)</p>
<p>We&#8217;re going to start by adding an icon to bbPress&#8217;s default &#8216;Edit&#8217; link for a topic.</p>
<div id="attachment_8445" style="width: 658px" class="wp-caption aligncenter"><img class="wp-image-8445 size-full" src="http://webdevstudios.com/wp-content/uploads/2014/08/Screenshot-2014-08-28-11.25.091.png" alt="bbPress\'s bbp_topic_admin_links" width="648" height="103" /><p class="wp-caption-text">bbPress&#8217;s bbp_topic_admin_links</p></div>
<p>We&#8217;ll hook into the <code>bbp_topic_admin_links</code> filter and add our icon font, like so (again, <code>functions.php</code>):</p>
<pre class="prettyprint lang-php">/**
 * bbPress - replace topic edit links with Font Awesome icons
 */
function bbp_topic_icon_admin_link( $links ) {

   $links[\'edit\'] = bbp_get_topic_edit_link( array(
      \'edit_text\' =&gt; \'&lt;i class=&quot;fa fa-edit&quot; title=&quot;\'. __( \'Edit topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;\'. __( \'Edit\', \'wds-tutorial-example\' ),
   ) );

   return $links;
}
add_filter( \'bbp_topic_admin_links\', \'bbp_topic_icon_admin_link\' );
</pre>
<p>That gives us this:</p>
<div id="attachment_8446" style="width: 654px" class="wp-caption aligncenter"><img class="size-full wp-image-8446" src="http://webdevstudios.com/wp-content/uploads/2014/08/Screenshot-2014-08-28-12.01.17.png" alt="bbPress topic links with Font Awesome edit icon" width="644" height="97" /><p class="wp-caption-text">bbPress topic links with Font Awesome edit icon</p></div>
<p>Now we&#8217;ll want to do the same for the reply to topic area by tying into the <code>bbp_reply_admin_links</code> filter so it&#8217;ll look like this:</p>
<div id="attachment_8447" style="width: 670px" class="wp-caption aligncenter"><img class="size-full wp-image-8447" src="http://webdevstudios.com/wp-content/uploads/2014/08/bbpress-edit-icon.gif" alt="bbPress edit icon for topic and reply" width="660" height="536" /><p class="wp-caption-text">bbPress edit icon for topic and reply (animated .gif)</p></div>
<p>We can hook into reply links with this (<code>functions.php</code>):</p>
<pre class="prettyprint lang-bsh">/**
 * bbPress - replace reply links with Font Awesome icons
 */
function bbp_reply_icon_admin_links( $links ) {

   $links[\'edit\'] = bbp_get_reply_edit_link( array(
      \'edit_text\' =&gt; \'&lt;i class=&quot;fa fa-edit&quot; title=&quot;\'. __( \'Edit topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;\'. __( \'Edit\', \'wds-tutorial-example\' ),
   ) );

   return $links;
}
add_filter( \'bbp_reply_admin_links\', \'bbp_reply_icon_admin_links\' );</pre>
<p>Of course, you can add an icon to any one of those links, and even replace the link altogether, like:</p>
<pre class="prettyprint linenums lang-bsh">&lt;?php
/**
 * bbPress - replace topic edit links with Font Awesome icons
 */
function bbp_topic_icon_admin_link( $links ) {

   $links[\'edit\'] = bbp_get_topic_edit_link( array(
      \'edit_text\' =&gt; \'&lt;i class=&quot;fa fa-edit&quot; title=&quot;\'. __( \'Edit Topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Edit\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\'
   ) );

   $links[\'close\'] = bbp_get_topic_close_link( array(
      \'close_text\' =&gt; \'&lt;i class=&quot;fa fa-toggle-on&quot; title=&quot;\'. __( \'Close topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Close\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'open_text\'  =&gt; \'&lt;i class=&quot;fa fa-toggle-off&quot; title=&quot;\'. __( \'Open topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Open\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
   ) );

   $links[\'stick\'] = bbp_get_topic_stick_link( array(
      \'stick_text\'   =&gt; \'&lt;i class=&quot;fa fa-bookmark&quot; title=&quot;\'. __( \'Stick topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Stick\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'unstick_text\' =&gt; \'&lt;i class=&quot;fa fa-bookmark-o&quot; title=&quot;\'. __( \'Unstick topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Unstick\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'super_text\'   =&gt; \'&lt;i class=&quot;fa fa-asterisk&quot; title=&quot;\'. __( \'Stick to front\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Stick to front\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
   ) );

   $links[\'merge\'] = bbp_get_topic_merge_link( array(
      \'merge_text\' =&gt; \'&lt;i class=&quot;fa fa-exchange&quot; title=&quot;\'. __( \'Merge topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Merge\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\'
   ) );

   $links[\'trash\'] = bbp_get_topic_trash_link( array(
      \'trash_text\'   =&gt; \'&lt;i class=&quot;fa fa-trash&quot; title=&quot;\'. __( \'Trash topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;Trash&lt;/span&gt;\',
      \'restore_text\' =&gt; \'&lt;i class=&quot;fa fa-restore&quot; title=&quot;\'. __( \'Restore topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Restore\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'delete_text\'  =&gt; \'&lt;i class=&quot;fa fa-times&quot; title=&quot;\'. __( \'Delete topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Delete\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
   ) );

   $links[\'spam\'] = bbp_get_topic_spam_link( array(
      \'spam_text\'   =&gt; \'&lt;i class=&quot;fa fa-exclamation&quot; title=&quot;\'. __( \'Mark as spam\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Spam\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'unspam_text\' =&gt; \'&lt;i class=&quot;fa fa-exclamation-circle&quot; title=&quot;\'. __( \'Unmark as spam\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Unspam\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
   ) );

   $links[\'reply\'] = bbp_get_topic_reply_link( array(
      \'reply_text\' =&gt; \'&lt;i class=&quot;fa fa-reply&quot; title=&quot;\'. __( \'Reply\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Reply\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\'
   ) );

   return $links;
}
add_filter( \'bbp_topic_admin_links\', \'bbp_topic_icon_admin_link\' );


/**
 * bbPress - replace reply links with Font Awesome icons
 */
function bbp_reply_icon_admin_links( $links ) {

   $links[\'edit\'] = bbp_get_reply_edit_link( array(
      \'edit_text\' =&gt; \'&lt;i class=&quot;fa fa-edit&quot; title=&quot;\'. __( \'Edit topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Edit\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\'
   ) );

   $links[\'move\'] = bbp_get_reply_move_link( array(
      \'split_text\' =&gt; \'&lt;i class=&quot;fa fa-arrow-circle-right&quot; title=&quot;\'. __( \'Move topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Move\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\'
   ) );

   $links[\'split\'] = bbp_get_topic_split_link( array(
      \'split_text\' =&gt; \'&lt;i class=&quot;fa fa-code-fork&quot; title=&quot;\'. __( \'Split topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Split\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\'
   ) );

   $links[\'trash\'] = bbp_get_reply_trash_link( array(
      \'trash_text\'   =&gt; \'&lt;i class=&quot;fa fa-trash&quot; title=&quot;\'. __( \'Trash topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Trash\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'restore_text\' =&gt; \'&lt;i class=&quot;fa fa-restore&quot; title=&quot;\'. __( \'Restore topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Restore\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'delete_text\'  =&gt; \'&lt;i class=&quot;fa fa-times&quot; title=&quot;\'. __( \'Delete topic\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Delete\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
   ) );

   $links[\'spam\'] = bbp_get_reply_spam_link( array(
      \'spam_text\'   =&gt; \'&lt;i class=&quot;fa fa-exclamation&quot; title=&quot;\'. __( \'Mark as spam\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Spam\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
      \'unspam_text\' =&gt; \'&lt;i class=&quot;fa fa-exclamation-circle&quot; title=&quot;\'. __( \'Unmark as spam\', \'wds-tutorial-example\' ) .\'&quot;&gt;&lt;/i&gt;&lt;span class=&quot;screen-reader-text&quot;&gt;\'. __( \'Unspam\', \'wds-tutorial-example\' ) .\'&lt;/span&gt;\',
   ) );

   return $links;
}
add_filter( \'bbp_reply_admin_links\', \'bbp_reply_icon_admin_links\' );
</pre>
<p>Which will give you this:</p>
<div id="attachment_8450" style="width: 670px" class="wp-caption aligncenter"><img class="size-full wp-image-8450" src="http://webdevstudios.com/wp-content/uploads/2014/08/bbpress-edit-icon-all.gif" alt="replace all bbPress topic and reply links with font icon" width="660" height="536" /><p class="wp-caption-text">Replace all bbPress topic and reply links with font icon (animated .gif)</p></div>
<p>But that is just <em><strong>crazy TOWN</strong></em>! Would you know what each icon represented if you were a new user trying to interact with that forum? Me neither. So be careful when and where you use such a recipe (for disaster?).</p>
<p>Integrating icons into modern web interfaces is a continuing challenge that can be fun if used properly. Have fun!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://webdevstudios.com/2014/08/28/integrating-font-awesome-icons-in-bbpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:72:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Using APIs to Integrate with WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2014/08/21/using-apis-to-integrate-with-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:84:"http://webdevstudios.com/2014/08/21/using-apis-to-integrate-with-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Aug 2014 20:11:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:11:{i:0;a:5:{s:4:"data";s:3:"API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"Employee Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:8:"Snippets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:9;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:10;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8419";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:397:"What is an API? API stands for &#8220;application programming interface&#8221; but that does not help explain what an API is. The simplest way I could explain what an API is: a way to handle data somewhere other than where you &#8230; <a class="more-link" href="http://webdevstudios.com/2014/08/21/using-apis-to-integrate-with-wordpress/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Patrick Garman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:9627:"<p>What is an API? API stands for &#8220;application programming interface&#8221; but that does not help explain what an API is. The simplest way I could explain what an API is: a way to handle data somewhere other than where you are. A good example that is probably being used on many WordPress websites is a typical Twitter widget. Depending on the widget different API&#8217;s may be being used there, and it is displayed in different ways but no matter what way you do it what is happening is your website is using the Twitter API to retrieve and display tweets. However, API does not always mean connecting to an external website and getting data; you could be sending data, or you could even be working with data within your own website. The WordPress <a href="https://codex.wordpress.org/Settings_API">settings API</a> is an API for managing your WordPress settings; that is when you are not using <a href="https://github.com/WebDevStudios/Custom-Metaboxes-and-Fields-for-WordPress/">CMB</a>!</p>
<p>When working with APIs in PHP you typically see cURL being used to connect to other servers to get or send data. cURL is great, except when the web server does not have cURL installed. So how do you make sure that your plugin or widget that uses APIs will work on as many of the varying server environments across the whole 20% of the internet WordPress powers? WordPress offers you a <a href="http://codex.wordpress.org/HTTP_API">HTTP API</a> that you can use to access other APIs! Instead of using cURL to send a GET or POST data, we use the <a href="http://codex.wordpress.org/Function_Reference/wp_remote_get">wp_remote_get()</a> or <a href="http://codex.wordpress.org/Function_Reference/wp_remote_post">wp_remote_post()</a> functions and simply pass in a URL and what data we want to send. I will be using these and</p>
<p>Greg Rickaby, one of our lead designers, and I put our heads together a little while back and extracted an <a href="https://github.com/WebDevStudios/WDS-Instagram">Instagram widget</a> we had created for a client site into its own plugin. This plugin and widget is very simple and will grow later, but it is a perfect proof of concept for accessing an API and then using that data. I will be examining how we went from our goal of using the Instagram API to create a widget that will grab the latest X shared photos, cache them, and then display them. For the purposes of this post, I am going to skip creating the widget itself, but you can check out the <a href="https://github.com/WebDevStudios/WDS-Instagram">source code on our GitHub</a>!</p>
<p>Most API&#8217;s require some form of authentication in order to use the API. The same way you need to login to your Instagram account to share your pictures, you need to login to get your data. For our purposes, we will need to create a &#8220;client&#8221; within Instagram &#8211; this is what you will authenticate to the API with. To get the credentials you will need to login to the Instagram developers console and register a client. Where it asks for your website and oAuth redirect URL you can enter your website URL in both fields (we are not dealing with oAuth today but they are required). Once registered you will be given your client ID which we will use to authenticate with the API.</p>
<p><img class="aligncenter size-full wp-image-8420" src="http://webdevstudios.com/wp-content/uploads/2014/08/instagram-add-client.png" alt="Add Instagram API Client" width="757" height="397" /></p>
<p>Now that we have our keys to the Instagram API, we can start getting our data! Let&#8217;s step through the function below and examine how we can use the <a href="http://codex.wordpress.org/HTTP_API">WordPress HTTP API</a> to connect to Instagram, authenticate with our new client ID, and cache this response locally for a short period of time to help improve performance and reduce the number of API calls made on every page load.</p>
<p>To cache our data we are going to use the <a href="http://codex.wordpress.org/Transients_API">Transients API</a>, and to do this we need a unique key that is no more than 45 characters in length. While this can sometimes at times be a bit difficult to have a readable AND short key I&#8217;ve found that having a readable prefix and concatenating that with an MD5 hash of some unique data will give me a unique and short key, every time. When this key is passed into <a href="http://codex.wordpress.org/Function_Reference/get_transient">get_transient()</a> if cached data is available it will be returned, otherwise it will return <code>false</code>. If cached data is available skip all the processing and just return it! This will help keep your site running as quick as it can.</p>
<pre class="prettyprint lang-php">$key = \'wds_instagram_widget_\' . md5( $this-&gt;id, $args[\'count\'] );
if ( false === ( $instagrams = get_transient( $key ) ) ) {
// ...
}</pre>
<p>When results are not cached yet though, we need to make that API call. To do this we build the URL that we need to access, which in this case required passing the Instagram user ID (not the username, the integer ID) along with a two query args for the client ID we create earlier and the count of how many photos we want returned. Once the URL has been created, we pass it to <a href="http://codex.wordpress.org/Function_Reference/wp_remote_get">wp_remote_get()</a> wrapped in the <a href="http://codex.wordpress.org/Function_Reference/add_query_arg">add_query_arg()</a> function to add the data we need to pass along. Every HTTP request made is going to return a status code with its response in the header, a good quick way to make sure that you are getting the response you expect is to check this code. Typically a good response is going to return a 200, if we do not receive a 200 code (using the <a href="http://codex.wordpress.org/Function_Reference/wp_remote_retrieve_response_code">wp_remote_retrieve_response_code()</a> function to check the response) from this endpoint of the Instagram API something did not go quite right and we are just going to bail out right now by returning <code>false</code>.</p>
<pre class="prettyprint lang-php">$api_url = \'https://api.instagram.com/v1/users/\' . esc_html( $user_id ) . \'/media/recent/\';
$response = wp_remote_get( add_query_arg( array(
	\'client_id\' =&amp;gt; esc_html( $client_id ),
	\'count\'     =&amp;gt; absint( $count )
), $api_url ) );

// Is the API up?
if ( ! 200 == wp_remote_retrieve_response_code( $response ) ) {
	return false;
}</pre>
<p>If you were to access that URL directly once built you would see a nice blob of machine readable JSON! That JSON may mean nothing to you but once WordPress can get it&#8217;s hands around it, <a href="http://php.net/manual/en/function.json-decode.php">json_decode()</a> will turn that JSON into a usable PHP object, or if you pass <code>true</code> as the second argument, you will be returned an array. Just in case the API is acting up, or the user ID is wrong, or a client ID is wrong, or for any other reason if we are not returned an array. If the response is not an array, just like before bail out and return <code>false</code>.</p>
<pre class="prettyprint lang-php">$instagrams = json_decode( wp_remote_retrieve_body( $response ), true );

// Are the results in an array?
if ( ! is_array( $instagrams ) ) {
	return false;
}</pre>
<p>Finally, once we have received our data and verified it is what we are expecting as well, we can we can save it to a transient using the key from before and cache so the next site visitor can get their page just a little bit faster.</p>
<pre class="prettyprint lang-php">set_transient( $key, $instagrams, apply_filters( \'wds_instagram_widget_cache_lifetime\', 1 * HOUR_IN_SECONDS ) );</pre>
<p>Putting it all together when we display our widget we can use this function to query the Instagram API for a users photos. Once we verify we did not return false in those few cases with a simple loop our photos are being displayed.</p>
<pre class="prettyprint lang-php">$instagram = $this-&gt;get_instagrams( array(
   \'user_id\'   =&gt; $instance[\'user_id\'],
   \'client_id\' =&gt; $instance[\'client_id\'],
   \'count\'     =&gt; $instance[\'count\'],
) );

// If we have Instagrams
if ( false !== $instagram ) : ?&gt;

   &lt;?php
      // Allow the image resolution to be filtered to use any available image resolutions from Instagram
      // low_resolution, thumbnail, standard_resolution
      $image_res = apply_filters( \'wds_instagram_widget_image_resolution\', \'standard_resolution\' );

      echo $args[\'before_widget\'];
      echo $args[\'before_title\'] . esc_html( $title ) . $args[\'after_title\'];
   ?&gt;

   &lt;ul class=&quot;instagram-widget&quot;&gt;

   &lt;?php
      foreach( $instagram[\'data\'] as $key =&gt; $image ) {
         echo apply_filters( \'wds_instagram_widget_image_html\', sprintf( \'&lt;li&gt;&lt;a href=&quot;%1$s&quot;&gt;&lt;img class=&quot;instagram-image&quot; src=&quot;%2$s&quot; alt=&quot;%3$s&quot; title=&quot;%3$s&quot; /&gt;&lt;/a&gt;&lt;/li&gt;\',
            $image[\'link\'],
            $image[\'images\'][ $image_res ][\'url\'],
            $image[\'caption\'][\'text\']
         ), $image );
      }
   ?&gt;

      &lt;a href=&quot;https://instagram.com/&lt;?php echo esc_html( $username ); ?&gt;&quot;&gt;&lt;?php printf( __( \'Follow %1$s on Instagram\', \'wds-instagram\' ), esc_html( $username ) ); ?&gt;&lt;/a&gt;
   &lt;/ul&gt;

&lt;?php endif;</pre>
<p>That&#8217;s it! You have successfully integrated Instagram into WordPress using their API. Using these basic concepts you can expand to integrate just about anything you want; so long as it has an API.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:80:"http://webdevstudios.com/2014/08/21/using-apis-to-integrate-with-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"webdevstudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:29:"https://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"fl7tZ1QOLM2aXR5F4HNICbZ22AI";s:13:"last-modified";s:29:"Sat, 04 Oct 2014 18:01:12 GMT";s:4:"date";s:29:"Sat, 04 Oct 2014 18:25:34 GMT";s:7:"expires";s:29:"Sat, 04 Oct 2014 18:25:34 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:14:"80:quic,p=0.01";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (3481, '_transient_timeout_feed_mod_c809918297b2c893fd8504c06adcaf00', '1412490334', 'no') ; 
INSERT INTO `wp_options` VALUES (3491, '_transient_feed_mod_c809918297b2c893fd8504c06adcaf00', '1412447134', 'no') ; 
INSERT INTO `wp_options` VALUES (3531, 'cpt_custom_post_types', 'a:3:{i:0;a:21:{s:4:"name";s:7:"sponsor";s:5:"label";s:8:"Sponsors";s:14:"singular_label";s:7:"Sponsor";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}i:1;a:21:{s:4:"name";s:5:"event";s:5:"label";s:6:"Events";s:14:"singular_label";s:5:"Event";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}i:2;a:21:{s:4:"name";s:11:"testimonial";s:5:"label";s:12:"Testimonials";s:14:"singular_label";s:11:"Testimonial";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3831, 'hmbkp_default_path', 'D:/home/site/wwwroot/wp-content/backupwordpress-586eae256d-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (3841, 'hmbkp_path', 'D:/home/site/wwwroot/wp-content/backupwordpress-586eae256d-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (3851, 'hmbkp_schedule_default-1', 'a:5:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_hourly";s:19:"schedule_start_time";i:1412452800;s:11:"max_backups";i:14;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3861, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1412478000;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3871, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (3891, '_transient_timeout_hmbkp_plugin_data', '1412536441', 'no') ; 
INSERT INTO `wp_options` VALUES (3901, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":20:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.6.2";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:32:"//profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:34:"//profiles.wordpress.org/humanmade";s:7:"willmot";s:32:"//profiles.wordpress.org/willmot";s:13:"pauldewouters";s:38:"//profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:33:"//profiles.wordpress.org/joehoyle";s:7:"mattheu";s:32:"//profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:34:"//profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.7.3";s:6:"tested";s:5:"3.9.2";s:13:"compatibility";a:1:{s:3:"4.0";a:1:{s:5:"2.6.2";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}}}s:6:"rating";d:91.799999999999997;s:11:"num_ratings";i:755;s:7:"ratings";a:5:{i:5;i:620;i:4;i:66;i:3;i:13;i:2;i:8;i:1;i:48;}s:10:"downloaded";i:1154611;s:12:"last_updated";s:21:"2014-05-06 2:07pm GMT";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:18:"http://bwp.hmn.md/";s:8:"sections";a:5:{s:11:"description";s:1433:"<p><a href="https://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">BackUpWordPress</a> will back up your entire site including your database and all your files on a schedule that suits you. Try it now to see how easy it is!</p>

<h4>Features</h4>

<ul>
<li>Super simple to use, no setup required.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Manage multiple schedules.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster backups if they are available.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your backups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted on GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:1083:"<ol>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' title=\'Click to view full-size screenshot 1\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' alt=\'backupwordpress screenshot 1\' />
		</a>		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' title=\'Click to view full-size screenshot 2\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' alt=\'backupwordpress screenshot 2\' />
		</a>		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' title=\'Click to view full-size screenshot 3\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' alt=\'backupwordpress screenshot 3\' />
		</a>		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:32377:"<h4>2.6.2</h4>

<ul>
<li>Reverts a change to how the home path is calculated as it caused issues on installs where wp-config.php was stored outside of web root. Props to @mikelittle for the bug report.</li>
</ul>

<h4>2.6.1</h4>

<ul>
<li>Bump minimum WP requirement to 3.7.3, the latest security release on the 3.7 branch.</li>
<li>Fix an issues that could cause schedule times to fail to account for timezone differences.</li>
<li>Add a nonce check to the schedule settings.</li>
<li>Fix a possible JS warning when removing an exclude rule.</li>
<li>Our unit tests now run in PHP 5.2 again.</li>
</ul>

<h4>2.6</h4>

<ul>
<li>It\'s now possible to choose the time and day that your schedule will run on.</li>
<li>Introduces several new unit tests around schedule timings.</li>
<li>Fixes a bug that could cause the hourly schedule to run constantly.</li>
<li>Improved the layout of the Constants help panel.</li>
<li>If the backup root directory is unreadable then the plugin will no longer function.</li>
<li>Update the backups table match the standard WordPress table styles.</li>
<li>Improved styling for the settings dialogue.</li>
<li>Improved styling for the Server Info help tab.</li>
<li>/s/back ups/backups.</li>
<li>Remove Deprecated call to <code>screen_icon</code>.</li>
<li>Updated French translation.</li>
<li>Update the <code>WP CLI</code> command to use the new method for registering command.</li>
<li>Reload the schedules when re-setting up the default schedules so they show up straight away.</li>
<li>s/dpesnt\'t/doesn\'t.</li>
<li>Only show the estimated total schedule size when editing an existing schedule.</li>
<li>Stop stripping 0 from the minutes on hourly backups so that backups at 10 (&#38; 20, etc.) past the hour correctly show.</li>
<li>Disable buttons whilst ajax requests are running.</li>
<li>Move spinners outside the buttons as they didn\'t look very good inside.</li>
<li>Improve the detection of the home path on multisite installs which have WordPress in a subdirectory.</li>
<li>Track the time that the running backup is started and display how long a backup has been running for.</li>
<li>Fix an issue that meant it wasn\'t possible to run multiple manual backups at the same time.</li>
<li>Many other minor improvements.</li>
</ul>

<h4>2.5</h4>

<ul>
<li>BackUpWordPress now requires WordPress 3.7.1 as a minimum.</li>
<li>Remove some old back-compat code that was required because we supported older WP versions.</li>
<li>It\'s now possible to change the email address that notification emails are sent from using the <code>hmbkp_from_email</code> filter.</li>
<li>The spinner is now retina!</li>
<li>Close the PHP Session before starting the backup process to work around the 1 request per session issue. Backup status will now work on sites which happen to call <code>session_start</code>.</li>
<li>Pass <code>max_execution_time</code> and the BackUpWordPress Plugin version back to support. * Include the users real name in support requests</li>
<li>Stop passing <code>$_SERVER</code> with support requests as it can contain things like <code>.htaccess</code> passwords on some server configurations.</li>
<li>Improve the display of the server info in the enable support popup.</li>
<li>New screenshots</li>
<li>Use <code>wp_safe_redirect</code> for internal redirects.</li>
<li>Use <code>wp_is_writable</code> instead of <code>is_writable</code>.</li>
</ul>

<h4>2.4.2</h4>

<ul>
<li>In WordPress Multisite the backups admin page is now located in Network admin instead of the wp-admin of the main site.</li>
<li>Fixed an issue with the new intercom support integration that could cause loading the backups page to timeout</li>
<li>Fixed 3 stray PHP warnings.</li>
<li>BackUpWordPress will now always be loaded before any BackUpWordPress Extensions.</li>
<li>Fixed an issue that could cause a long modal (excludes) to show underneath the WP admin bar.</li>
</ul>

<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4410:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>What if I want I want to back up my site to another destination?</strong></p>

<p>BackUpWordPress Pro supports Dropbox, Google Drive, Amazon S3, Rackspace, Azure, DreamObjects and FTP/SFTP. Check it out here: <a href="http://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">https://bwp.hmn.md</a></p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (3911, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2824986488', 'no') ; 
INSERT INTO `wp_options` VALUES (3921, '_transient_hmbkp_schedule_default-1_database_filesize', '2670592', 'no') ; 
INSERT INTO `wp_options` VALUES (3951, '_transient_timeout_hmbkp_schedule_default-1_complete_filesize', '2824986972', 'no') ; 
INSERT INTO `wp_options` VALUES (3961, '_transient_hmbkp_schedule_default-1_complete_filesize', '47259657', 'no') ; 
INSERT INTO `wp_options` VALUES (3971, 'widget_klasik-sponsors-widget', 'a:2:{i:2;a:7:{s:5:"title";s:12:"Our Sponsors";s:8:"category";s:1:"0";s:4:"cols";s:1:"1";s:8:"showpost";s:0:"";s:8:"longdesc";s:0:"";s:5:"order";s:4:"DESC";s:11:"customclass";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4381, 'widget_klasik-testimonials-widget', 'a:2:{i:2;a:7:{s:5:"title";s:15:"Success Stories";s:8:"category";s:1:"0";s:4:"cols";s:1:"1";s:8:"showpost";s:1:"3";s:8:"longdesc";s:0:"";s:5:"order";s:4:"DESC";s:11:"customclass";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4411, 'widget_akismet_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4591, 'rewrite_rules', 'a:111:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"sponsor/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"sponsor/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"sponsor/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"sponsor/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"sponsor/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"sponsor/([^/]+)/trackback/?$";s:34:"index.php?sponsor=$matches[1]&tb=1";s:36:"sponsor/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?sponsor=$matches[1]&paged=$matches[2]";s:43:"sponsor/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?sponsor=$matches[1]&cpage=$matches[2]";s:28:"sponsor/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?sponsor=$matches[1]&page=$matches[2]";s:24:"sponsor/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"sponsor/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"sponsor/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"sponsor/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"sponsor/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"event/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"event/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"event/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"event/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:34:"event/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:41:"event/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:26:"event/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:22:"event/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"event/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"event/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"testimonial/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"testimonial/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"testimonial/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"testimonial/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"testimonial/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"testimonial/([^/]+)/trackback/?$";s:38:"index.php?testimonial=$matches[1]&tb=1";s:40:"testimonial/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?testimonial=$matches[1]&paged=$matches[2]";s:47:"testimonial/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?testimonial=$matches[1]&cpage=$matches[2]";s:32:"testimonial/([^/]+)(/[0-9]+)?/?$";s:50:"index.php?testimonial=$matches[1]&page=$matches[2]";s:28:"testimonial/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"testimonial/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"testimonial/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"testimonial/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"testimonial/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:41:"index.php?&page_id=5221&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4601, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1412476390', 'yes') ; 
INSERT INTO `wp_options` VALUES (4611, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4690";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2907";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2823";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2344";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2238";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1804";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1619";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1591";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1569";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1533";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1496";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1485";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1403";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1236";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1183";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1133";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1081";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1027";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1018";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"849";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"844";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"838";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"806";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"798";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"747";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"710";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"709";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"673";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"663";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"631";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"626";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"623";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"619";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"613";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"600";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:3:"572";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"564";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"561";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"554";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"553";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4621, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1412477585;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:11:{s:35:"add-from-server/add-from-server.php";O:8:"stdClass":7:{s:2:"id";s:4:"2613";s:4:"slug";s:15:"add-from-server";s:6:"plugin";s:35:"add-from-server/add-from-server.php";s:11:"new_version";s:7:"3.2.0.3";s:14:"upgrade_notice";s:86:"Japanese Translations, PHP 5.4 compatibility, and a fix to special characters in urls.";s:3:"url";s:46:"https://wordpress.org/plugins/add-from-server/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/add-from-server.3.2.0.3.zip";}s:30:"advanced-custom-fields/acf.php";O:8:"stdClass":6:{s:2:"id";s:5:"21367";s:4:"slug";s:22:"advanced-custom-fields";s:6:"plugin";s:30:"advanced-custom-fields/acf.php";s:11:"new_version";s:5:"4.3.9";s:3:"url";s:53:"https://wordpress.org/plugins/advanced-custom-fields/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/advanced-custom-fields.zip";}s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.2.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"2.6.2";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";}s:51:"configure-login-timeout/configure-login-timeout.php";O:8:"stdClass":6:{s:2:"id";s:5:"19073";s:4:"slug";s:23:"configure-login-timeout";s:6:"plugin";s:51:"configure-login-timeout/configure-login-timeout.php";s:11:"new_version";s:3:"1.0";s:3:"url";s:54:"https://wordpress.org/plugins/configure-login-timeout/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/configure-login-timeout.zip";}s:59:"content-views-query-and-display-post-page/content-views.php";O:8:"stdClass":7:{s:2:"id";s:5:"50378";s:4:"slug";s:41:"content-views-query-and-display-post-page";s:6:"plugin";s:59:"content-views-query-and-display-post-page/content-views.php";s:11:"new_version";s:5:"1.3.3";s:14:"upgrade_notice";s:75:"Bug fixed: Return &#039;Empty settings&#039; message for pagination request";s:3:"url";s:72:"https://wordpress.org/plugins/content-views-query-and-display-post-page/";s:7:"package";s:90:"https://downloads.wordpress.org/plugin/content-views-query-and-display-post-page.1.3.3.zip";}s:43:"custom-post-type-ui/custom-post-type-ui.php";O:8:"stdClass":7:{s:2:"id";s:5:"13183";s:4:"slug";s:19:"custom-post-type-ui";s:6:"plugin";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:11:"new_version";s:5:"0.8.4";s:14:"upgrade_notice";s:119:"Fix issue with get code and post types/taxonomies that use a dash instead of underscore. Props Evan Mullins/circlecube.";s:3:"url";s:50:"https://wordpress.org/plugins/custom-post-type-ui/";s:7:"package";s:68:"https://downloads.wordpress.org/plugin/custom-post-type-ui.0.8.4.zip";}s:45:"limit-login-attempts/limit-login-attempts.php";O:8:"stdClass":7:{s:2:"id";s:4:"6158";s:4:"slug";s:20:"limit-login-attempts";s:6:"plugin";s:45:"limit-login-attempts/limit-login-attempts.php";s:11:"new_version";s:5:"1.7.1";s:14:"upgrade_notice";s:249:"Users of version 1.6.2 and 1.7.0 should upgrade immediately. There was a problem with &quot;auth cookie&quot; lockout enforcement. Lockout of normal password login attempts still worked as it should. Please see plugin Changelog for more information.";s:3:"url";s:51:"https://wordpress.org/plugins/limit-login-attempts/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/limit-login-attempts.1.7.1.zip";}s:31:"page-links-to/page-links-to.php";O:8:"stdClass":6:{s:2:"id";s:3:"216";s:4:"slug";s:13:"page-links-to";s:6:"plugin";s:31:"page-links-to/page-links-to.php";s:11:"new_version";s:5:"2.9.3";s:3:"url";s:44:"https://wordpress.org/plugins/page-links-to/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/page-links-to.2.9.3.zip";}s:37:"user-role-editor/user-role-editor.php";O:8:"stdClass":6:{s:2:"id";s:5:"13697";s:4:"slug";s:16:"user-role-editor";s:6:"plugin";s:37:"user-role-editor/user-role-editor.php";s:11:"new_version";s:6:"4.17.1";s:3:"url";s:47:"https://wordpress.org/plugins/user-role-editor/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/user-role-editor.zip";}s:41:"wordpress-importer/wordpress-importer.php";O:8:"stdClass":6:{s:2:"id";s:5:"14975";s:4:"slug";s:18:"wordpress-importer";s:6:"plugin";s:41:"wordpress-importer/wordpress-importer.php";s:11:"new_version";s:5:"0.6.1";s:3:"url";s:49:"https://wordpress.org/plugins/wordpress-importer/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.1.zip";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4631, 'user_role_editor', 'a:3:{s:17:"ure_caps_readable";i:0;s:24:"ure_show_deprecated_caps";i:0;s:19:"ure_hide_pro_banner";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4641, 'wp_backup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";i:1;s:17:"manage_categories";i:1;s:12:"manage_links";i:1;s:12:"upload_files";i:1;s:15:"unfiltered_html";i:1;s:10:"edit_posts";i:1;s:17:"edit_others_posts";i:1;s:20:"edit_published_posts";i:1;s:13:"publish_posts";i:1;s:10:"edit_pages";i:1;s:4:"read";i:1;s:7:"level_7";i:1;s:7:"level_6";i:1;s:7:"level_5";i:1;s:7:"level_4";i:1;s:7:"level_3";i:1;s:7:"level_2";i:1;s:7:"level_1";i:1;s:7:"level_0";i:1;s:17:"edit_others_pages";i:1;s:20:"edit_published_pages";i:1;s:13:"publish_pages";i:1;s:12:"delete_pages";i:1;s:19:"delete_others_pages";i:1;s:22:"delete_published_pages";i:1;s:12:"delete_posts";i:1;s:19:"delete_others_posts";i:1;s:22:"delete_published_posts";i:1;s:20:"delete_private_posts";i:1;s:18:"edit_private_posts";i:1;s:18:"read_private_posts";i:1;s:20:"delete_private_pages";i:1;s:18:"edit_private_pages";i:1;s:18:"read_private_pages";i:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (4651, '_site_transient_timeout_ure_caps_readable', '1412466390', 'yes') ; 
INSERT INTO `wp_options` VALUES (4661, '_site_transient_ure_caps_readable', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (4771, '_site_transient_timeout_theme_roots', '1412479384', 'yes') ; 
INSERT INTO `wp_options` VALUES (4781, '_site_transient_theme_roots', 'a:5:{s:6:"klasik";s:7:"/themes";s:17:"organic_nonprofit";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4811, '_transient_doing_cron', '1412478231.2440900802612304687500', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=21521 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (488 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (11, 11, '_edit_lock', '1412393623:1') ; 
INSERT INTO `wp_postmeta` VALUES (21, 51, '_edit_lock', '1412393513:1') ; 
INSERT INTO `wp_postmeta` VALUES (31, 61, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (41, 61, '_edit_lock', '1412466004:1') ; 
INSERT INTO `wp_postmeta` VALUES (51, 61, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (7731, 3921, '_wp_attached_file', '2013/12/blackram.png') ; 
INSERT INTO `wp_postmeta` VALUES (7741, 3921, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:130;s:6:"height";i:75;s:4:"file";s:20:"2013/12/blackram.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (10031, 22, '_wp_attached_file', '2013/12/pacificcont1.png') ; 
INSERT INTO `wp_postmeta` VALUES (10041, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:216;s:6:"height";i:75;s:4:"file";s:24:"2013/12/pacificcont1.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"pacificcont1-150x75.png";s:5:"width";i:150;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (12721, 30, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12731, 30, '_wp_page_template', 'page-full.php') ; 
INSERT INTO `wp_postmeta` VALUES (12751, 32, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12761, 32, '_wp_page_template', 'page-full.php') ; 
INSERT INTO `wp_postmeta` VALUES (12781, 32, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12791, 32, '_wp_page_template', 'page-full.php') ; 
INSERT INTO `wp_postmeta` VALUES (12811, 38, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12821, 38, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12831, 38, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (12841, 38, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (12871, 40, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12881, 40, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (12891, 40, '_post_restored_from', 'a:3:{s:20:"restored_revision_id";i:58;s:16:"restored_by_user";i:1;s:13:"restored_time";i:1392718516;}') ; 
INSERT INTO `wp_postmeta` VALUES (12911, 42, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12921, 42, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (12941, 54, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12951, 54, '_wp_page_template', 'page-full.php') ; 
INSERT INTO `wp_postmeta` VALUES (12971, 117, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (12981, 117, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (13181, 5131, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (13201, 5131, '_menu_item_menu_item_parent', '7431') ; 
INSERT INTO `wp_postmeta` VALUES (13231, 5131, '_menu_item_object_id', '38') ; 
INSERT INTO `wp_postmeta` VALUES (13251, 5131, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (13271, 5131, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (13291, 5131, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (13301, 5131, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (13311, 5131, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (13321, 5141, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (13331, 5141, '_menu_item_menu_item_parent', '7921') ; 
INSERT INTO `wp_postmeta` VALUES (13341, 5141, '_menu_item_object_id', '42') ; 
INSERT INTO `wp_postmeta` VALUES (13351, 5141, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (13361, 5151, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (13371, 5141, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (13381, 5151, '_menu_item_menu_item_parent', '5191') ; 
INSERT INTO `wp_postmeta` VALUES (13391, 5141, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (13401, 5151, '_menu_item_object_id', '32') ; 
INSERT INTO `wp_postmeta` VALUES (13411, 5141, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (13421, 5151, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (13431, 5141, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (13441, 5151, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (13451, 5151, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (13461, 5151, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (13471, 5151, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (13501, 225, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13521, 225, '_wp_page_template', 'page-slideshow.php') ; 
INSERT INTO `wp_postmeta` VALUES (13591, 225, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13611, 225, '_wp_page_template', 'page-slideshow.php') ; 
INSERT INTO `wp_postmeta` VALUES (13761, 5191, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (13771, 5191, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (13781, 5191, '_menu_item_object_id', '5191') ; 
INSERT INTO `wp_postmeta` VALUES (13791, 5191, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (13801, 5191, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (13811, 5191, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (13831, 5191, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (13851, 5191, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (13921, 103, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13931, 103, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (13951, 103, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13961, 103, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (13981, 115, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13991, 115, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (14001, 115, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14021, 115, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (14041, 119, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14051, 119, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14071, 122, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14081, 122, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14091, 122, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14101, 122, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14131, 130, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14141, 130, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14161, 154, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14171, 154, '_links_to', 'http://temp.bootstoshoes.org/veterans') ; 
INSERT INTO `wp_postmeta` VALUES (14191, 158, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14201, 158, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (14221, 158, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14231, 158, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (14251, 5211, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14261, 5211, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14271, 5221, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14281, 5211, '_links_to', 'http://temp.bootstoshoes.org') ; 
INSERT INTO `wp_postmeta` VALUES (14291, 5221, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14301, 5221, '_links_to', 'http://temp.bootstoshoes.org') ; 
INSERT INTO `wp_postmeta` VALUES (14311, 208, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14321, 208, '_wp_page_template', 'page-full.php') ; 
INSERT INTO `wp_postmeta` VALUES (14341, 220, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14361, 220, '_links_to', '#') ; 
INSERT INTO `wp_postmeta` VALUES (14371, 222, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14391, 222, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (14401, 222, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14421, 222, '_links_to', 'http://temp.bootstoshoes.org/') ; 
INSERT INTO `wp_postmeta` VALUES (14431, 237, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14441, 237, '_links_to', 'http://temp.bootstoshoes.org/boots-to-shoes/volunteer/') ; 
INSERT INTO `wp_postmeta` VALUES (14451, 237, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14461, 237, '_links_to', 'http://temp.bootstoshoes.org/boots-to-shoes/volunteer/') ; 
INSERT INTO `wp_postmeta` VALUES (14471, 328, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14491, 335, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14501, 335, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14521, 335, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14531, 335, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14551, 339, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14561, 339, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14581, 5231, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14591, 5241, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14601, 5231, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14611, 5241, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14641, 349, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (14651, 349, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (14831, 5281, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (14861, 5281, '_menu_item_menu_item_parent', '7431') ; 
INSERT INTO `wp_postmeta` VALUES (14881, 5281, '_menu_item_object_id', '119') ; 
INSERT INTO `wp_postmeta` VALUES (14891, 5281, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (14921, 5281, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (14941, 5281, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (14961, 5281, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (14971, 5281, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (15171, 5321, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15191, 5321, '_menu_item_menu_item_parent', '5191') ; 
INSERT INTO `wp_postmeta` VALUES (15211, 5321, '_menu_item_object_id', '335') ; 
INSERT INTO `wp_postmeta` VALUES (15231, 5321, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (15251, 5321, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (15271, 5321, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (15281, 5321, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (15291, 5321, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (15301, 5331, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15311, 5331, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (15321, 5331, '_menu_item_object_id', '208') ; 
INSERT INTO `wp_postmeta` VALUES (15331, 5331, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (15341, 5341, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15351, 5331, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (15361, 5341, '_menu_item_menu_item_parent', '5191') ; 
INSERT INTO `wp_postmeta` VALUES (15371, 5331, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (15381, 5341, '_menu_item_object_id', '5241') ; 
INSERT INTO `wp_postmeta` VALUES (15391, 5331, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (15401, 5341, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (15411, 5341, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (15421, 5331, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (15431, 5341, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (15441, 5341, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (15451, 5341, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (15461, 5211, '_edit_lock', '1412443078:1') ; 
INSERT INTO `wp_postmeta` VALUES (15471, 5221, '_edit_lock', '1412456674:1') ; 
INSERT INTO `wp_postmeta` VALUES (15481, 40, '_edit_lock', '1412445973:1') ; 
INSERT INTO `wp_postmeta` VALUES (15491, 328, '_edit_lock', '1412443441:1') ; 
INSERT INTO `wp_postmeta` VALUES (15511, 328, 'klasik_slider_post', '') ; 
INSERT INTO `wp_postmeta` VALUES (15521, 237, '_edit_lock', '1412460221:1') ; 
INSERT INTO `wp_postmeta` VALUES (15541, 237, 'klasik_slider_post', '') ; 
INSERT INTO `wp_postmeta` VALUES (15561, 222, '_edit_lock', '1412446664:1') ; 
INSERT INTO `wp_postmeta` VALUES (15581, 222, 'klasik_slider_post', '') ; 
INSERT INTO `wp_postmeta` VALUES (15591, 41, '_edit_lock', '1412463390:1') ; 
INSERT INTO `wp_postmeta` VALUES (15641, 5221, 'klasik_layout', 'one-col') ; 
INSERT INTO `wp_postmeta` VALUES (15761, 130, '_edit_lock', '1412459851:1') ; 
INSERT INTO `wp_postmeta` VALUES (15771, 5481, '_edit_lock', '1412464584:1') ; 
INSERT INTO `wp_postmeta` VALUES (15781, 5481, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (15791, 5481, 'klasik_layout', 'two-col-left') ; 
INSERT INTO `wp_postmeta` VALUES (15801, 5481, 'page-title', 'Donor Wall') ; 
INSERT INTO `wp_postmeta` VALUES (15811, 5501, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15821, 5501, '_menu_item_menu_item_parent', '7431') ; 
INSERT INTO `wp_postmeta` VALUES (15831, 5501, '_menu_item_object_id', '5481') ; 
INSERT INTO `wp_postmeta` VALUES (15841, 5501, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (15851, 5501, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (15861, 5501, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (15871, 5501, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (15881, 5501, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (15901, 42, '_edit_lock', '1412456901:1') ; 
INSERT INTO `wp_postmeta` VALUES (15911, 40, 'klasik_layout', 'two-col-left') ; 
INSERT INTO `wp_postmeta` VALUES (15921, 5521, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (15931, 5521, '_edit_lock', '1412460080:1') ; 
INSERT INTO `wp_postmeta` VALUES (15941, 5541, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (15951, 5541, '_edit_lock', '1412444391:1') ; 
INSERT INTO `wp_postmeta` VALUES (15961, 5561, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15971, 5561, '_menu_item_menu_item_parent', '7921') ; 
INSERT INTO `wp_postmeta` VALUES (15981, 5561, '_menu_item_object_id', '5541') ; 
INSERT INTO `wp_postmeta` VALUES (15991, 5561, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (16001, 5561, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (16011, 5561, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (16021, 5561, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (16031, 5561, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (16051, 5571, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (16061, 5571, '_menu_item_menu_item_parent', '7921') ; 
INSERT INTO `wp_postmeta` VALUES (16071, 5571, '_menu_item_object_id', '5521') ; 
INSERT INTO `wp_postmeta` VALUES (16081, 5571, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (16091, 5571, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (16101, 5571, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (16111, 5571, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (16121, 5571, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (16141, 5211, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (16151, 5211, '_wp_trash_meta_time', '1412444729') ; 
INSERT INTO `wp_postmeta` VALUES (16161, 5581, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (16171, 5581, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (16181, 5581, '_menu_item_object_id', '5221') ; 
INSERT INTO `wp_postmeta` VALUES (16191, 5581, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (16201, 5581, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (16211, 5581, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (16221, 5581, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (16231, 5581, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (16251, 5591, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16261, 5591, '_edit_lock', '1412456530:1') ; 
INSERT INTO `wp_postmeta` VALUES (16271, 5611, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (16281, 5611, '_menu_item_menu_item_parent', '7431') ; 
INSERT INTO `wp_postmeta` VALUES (16291, 5611, '_menu_item_object_id', '5591') ; 
INSERT INTO `wp_postmeta` VALUES (16301, 5611, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (16311, 5611, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (16321, 5611, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (16331, 5611, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (16341, 5611, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (16381, 5641, '_edit_lock', '1412446619:1') ; 
INSERT INTO `wp_postmeta` VALUES (16391, 5641, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16411, 5641, 'klasik_slider_post', '') ; 
INSERT INTO `wp_postmeta` VALUES (16421, 222, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (16431, 222, '_wp_trash_meta_time', '1412446808') ; 
INSERT INTO `wp_postmeta` VALUES (16451, 5661, '_edit_lock', '1412448065:1') ; 
INSERT INTO `wp_postmeta` VALUES (16461, 5661, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16501, 5661, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (16511, 5661, '_wp_trash_meta_time', '1412448208') ; 
INSERT INTO `wp_postmeta` VALUES (16521, 5681, '_edit_lock', '1412464286:1') ; 
INSERT INTO `wp_postmeta` VALUES (16531, 5681, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16541, 5701, '_edit_lock', '1412459104:1') ; 
INSERT INTO `wp_postmeta` VALUES (16551, 5701, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16561, 5731, '_edit_lock', '1412449080:1') ; 
INSERT INTO `wp_postmeta` VALUES (16571, 5731, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16581, 5751, '_edit_lock', '1412464295:1') ; 
INSERT INTO `wp_postmeta` VALUES (16591, 5751, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16641, 5811, '_wp_attached_file', '2014/10/Boots-to-Shoes-Logo-300x75.png') ; 
INSERT INTO `wp_postmeta` VALUES (16651, 5811, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:75;s:4:"file";s:38:"2014/10/Boots-to-Shoes-Logo-300x75.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"Boots-to-Shoes-Logo-300x75-150x75.png";s:5:"width";i:150;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:14:"widget-feature";a:4:{s:4:"file";s:36:"Boots-to-Shoes-Logo-300x75-50x50.png";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/png";}s:11:"widget-post";a:4:{s:4:"file";s:37:"Boots-to-Shoes-Logo-300x75-100x75.png";s:5:"width";i:100;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:18:"widget-testimonial";a:4:{s:4:"file";s:37:"Boots-to-Shoes-Logo-300x75-100x75.png";s:5:"width";i:100;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (16861, 5921, '_wp_attached_file', '2014/10/corsair.png') ; 
INSERT INTO `wp_postmeta` VALUES (16871, 5921, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:130;s:6:"height";i:75;s:4:"file";s:19:"2014/10/corsair.png";s:5:"sizes";a:3:{s:14:"widget-feature";a:4:{s:4:"file";s:17:"corsair-50x50.png";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/png";}s:11:"widget-post";a:4:{s:4:"file";s:18:"corsair-100x75.png";s:5:"width";i:100;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:18:"widget-testimonial";a:4:{s:4:"file";s:18:"corsair-100x75.png";s:5:"width";i:100;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (16921, 5951, '_wp_attached_file', '2014/10/unitedway.png') ; 
INSERT INTO `wp_postmeta` VALUES (16931, 5951, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:130;s:6:"height";i:75;s:4:"file";s:21:"2014/10/unitedway.png";s:5:"sizes";a:3:{s:14:"widget-feature";a:4:{s:4:"file";s:19:"unitedway-50x50.png";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/png";}s:11:"widget-post";a:4:{s:4:"file";s:20:"unitedway-100x75.png";s:5:"width";i:100;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:18:"widget-testimonial";a:4:{s:4:"file";s:20:"unitedway-100x75.png";s:5:"width";i:100;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (18191, 6571, '_wp_attached_file', '2014/10/Rick-2-609x320.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (18201, 6571, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:609;s:6:"height";i:320;s:4:"file";s:26:"2014/10/Rick-2-609x320.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Rick-2-609x320-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Rick-2-609x320-300x157.jpg";s:5:"width";i:300;s:6:"height";i:157;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:24:"Rick-2-609x320-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:26:"Rick-2-609x320-550x320.jpg";s:5:"width";i:550;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:26:"Rick-2-609x320-550x320.jpg";s:5:"width";i:550;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:26:"Rick-2-609x320-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:26:"Rick-2-609x320-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (18211, 6581, '_wp_attached_file', '2014/10/Rick-2-609x600.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (18221, 6581, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:609;s:6:"height";i:600;s:4:"file";s:26:"2014/10/Rick-2-609x600.jpg";s:5:"sizes";a:11:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Rick-2-609x600-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Rick-2-609x600-300x295.jpg";s:5:"width";i:300;s:6:"height";i:295;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:24:"Rick-2-609x600-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:16:"widget-portfolio";a:4:{s:4:"file";s:26:"Rick-2-609x600-609x444.jpg";s:5:"width";i:609;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:26:"Rick-2-609x600-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:26:"Rick-2-609x600-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:26:"Rick-2-609x600-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:26:"Rick-2-609x600-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"image-slider";a:4:{s:4:"file";s:26:"Rick-2-609x600-609x480.jpg";s:5:"width";i:609;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:26:"Rick-2-609x600-609x320.jpg";s:5:"width";i:609;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:26:"Rick-2-609x600-609x320.jpg";s:5:"width";i:609;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (18641, 5921, '_edit_lock', '1412449451:1') ; 
INSERT INTO `wp_postmeta` VALUES (18671, 6571, '_edit_lock', '1412449528:1') ; 
INSERT INTO `wp_postmeta` VALUES (18681, 6581, '_edit_lock', '1412449536:1') ; 
INSERT INTO `wp_postmeta` VALUES (18771, 6791, '_edit_lock', '1412459771:1') ; 
INSERT INTO `wp_postmeta` VALUES (18781, 6791, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (18811, 6821, '_edit_lock', '1412459688:1') ; 
INSERT INTO `wp_postmeta` VALUES (18821, 6821, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (18871, 3921, '_edit_lock', '1412449951:1') ; 
INSERT INTO `wp_postmeta` VALUES (18931, 6841, '_edit_lock', '1412459196:1') ; 
INSERT INTO `wp_postmeta` VALUES (18941, 6841, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (18951, 6861, '_edit_lock', '1412458607:1') ; 
INSERT INTO `wp_postmeta` VALUES (18961, 6861, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (18971, 6881, '_edit_lock', '1412450655:1') ; 
INSERT INTO `wp_postmeta` VALUES (18981, 6891, '_wp_attached_file', '2014/10/stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (18991, 6891, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:254;s:4:"file";s:78:"2014/10/stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:78:"stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:78:"stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:76:"stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:78:"stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:78:"stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19001, 6901, '_wp_attached_file', '2014/10/stock-photo-6237791-auto-mechanic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19011, 6901, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:272;s:4:"file";s:45:"2014/10/stock-photo-6237791-auto-mechanic.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:45:"stock-photo-6237791-auto-mechanic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:45:"stock-photo-6237791-auto-mechanic-300x214.jpg";s:5:"width";i:300;s:6:"height";i:214;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:43:"stock-photo-6237791-auto-mechanic-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:45:"stock-photo-6237791-auto-mechanic-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:45:"stock-photo-6237791-auto-mechanic-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19021, 6911, '_wp_attached_file', '2014/10/stock-photo-6588831-computer-repairing.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19031, 6911, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:268;s:4:"file";s:50:"2014/10/stock-photo-6588831-computer-repairing.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:50:"stock-photo-6588831-computer-repairing-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:50:"stock-photo-6588831-computer-repairing-300x211.jpg";s:5:"width";i:300;s:6:"height";i:211;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:48:"stock-photo-6588831-computer-repairing-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:50:"stock-photo-6588831-computer-repairing-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:50:"stock-photo-6588831-computer-repairing-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19041, 6921, '_wp_attached_file', '2014/10/stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19051, 6921, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:254;s:4:"file";s:83:"2014/10/stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:83:"stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:83:"stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:81:"stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:83:"stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:83:"stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19061, 6931, '_wp_attached_file', '2014/10/stock-photo-9942879-modern-storehouse.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19071, 6931, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:49:"2014/10/stock-photo-9942879-modern-storehouse.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:49:"stock-photo-9942879-modern-storehouse-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:49:"stock-photo-9942879-modern-storehouse-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:47:"stock-photo-9942879-modern-storehouse-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:49:"stock-photo-9942879-modern-storehouse-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:49:"stock-photo-9942879-modern-storehouse-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19081, 6941, '_wp_attached_file', '2014/10/stock-photo-12925726-military-handshake.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19091, 6941, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:51:"2014/10/stock-photo-12925726-military-handshake.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:51:"stock-photo-12925726-military-handshake-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:51:"stock-photo-12925726-military-handshake-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:49:"stock-photo-12925726-military-handshake-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:51:"stock-photo-12925726-military-handshake-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:51:"stock-photo-12925726-military-handshake-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19101, 6951, '_wp_attached_file', '2014/10/stock-photo-16302628-female-american-soldier.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19111, 6951, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:253;s:6:"height";i:380;s:4:"file";s:56:"2014/10/stock-photo-16302628-female-american-soldier.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-199x300.jpg";s:5:"width";i:199;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:54:"stock-photo-16302628-female-american-soldier-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-253x330.jpg";s:5:"width";i:253;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-253x330.jpg";s:5:"width";i:253;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-253x320.jpg";s:5:"width";i:253;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:56:"stock-photo-16302628-female-american-soldier-253x320.jpg";s:5:"width";i:253;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19121, 6961, '_wp_attached_file', '2014/10/stock-photo-17603464-technician-and-engineer.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19131, 6961, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:261;s:4:"file";s:56:"2014/10/stock-photo-17603464-technician-and-engineer.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:56:"stock-photo-17603464-technician-and-engineer-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"stock-photo-17603464-technician-and-engineer-300x206.jpg";s:5:"width";i:300;s:6:"height";i:206;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:54:"stock-photo-17603464-technician-and-engineer-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:56:"stock-photo-17603464-technician-and-engineer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:56:"stock-photo-17603464-technician-and-engineer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19141, 6971, '_wp_attached_file', '2014/10/stock-photo-18060019-merkel-tours-energy-production-sites.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19151, 6971, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:252;s:4:"file";s:69:"2014/10/stock-photo-18060019-merkel-tours-energy-production-sites.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:69:"stock-photo-18060019-merkel-tours-energy-production-sites-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:69:"stock-photo-18060019-merkel-tours-energy-production-sites-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:67:"stock-photo-18060019-merkel-tours-energy-production-sites-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:69:"stock-photo-18060019-merkel-tours-energy-production-sites-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:69:"stock-photo-18060019-merkel-tours-energy-production-sites-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19161, 6981, '_wp_attached_file', '2014/10/stock-photo-18149011-it-engineers-in-network-server-room.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19171, 6981, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:68:"2014/10/stock-photo-18149011-it-engineers-in-network-server-room.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:68:"stock-photo-18149011-it-engineers-in-network-server-room-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:68:"stock-photo-18149011-it-engineers-in-network-server-room-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:66:"stock-photo-18149011-it-engineers-in-network-server-room-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:68:"stock-photo-18149011-it-engineers-in-network-server-room-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:68:"stock-photo-18149011-it-engineers-in-network-server-room-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19181, 6991, '_wp_attached_file', '2014/10/stock-photo-19078655-people-working-together-in-shipping-warehouse.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19191, 6991, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:200;s:4:"file";s:78:"2014/10/stock-photo-19078655-people-working-together-in-shipping-warehouse.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:78:"stock-photo-19078655-people-working-together-in-shipping-warehouse-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:78:"stock-photo-19078655-people-working-together-in-shipping-warehouse-300x157.jpg";s:5:"width";i:300;s:6:"height";i:157;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:76:"stock-photo-19078655-people-working-together-in-shipping-warehouse-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:78:"stock-photo-19078655-people-working-together-in-shipping-warehouse-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:78:"stock-photo-19078655-people-working-together-in-shipping-warehouse-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19201, 7001, '_wp_attached_file', '2014/10/stock-photo-24756209-hydro-biologist-testing-quality-of-water.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19211, 7001, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:73:"2014/10/stock-photo-24756209-hydro-biologist-testing-quality-of-water.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:73:"stock-photo-24756209-hydro-biologist-testing-quality-of-water-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:73:"stock-photo-24756209-hydro-biologist-testing-quality-of-water-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:71:"stock-photo-24756209-hydro-biologist-testing-quality-of-water-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:73:"stock-photo-24756209-hydro-biologist-testing-quality-of-water-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:73:"stock-photo-24756209-hydro-biologist-testing-quality-of-water-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19221, 7011, '_wp_attached_file', '2014/10/stock-photo-1943540-communicating-soldier.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19231, 7011, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:53:"2014/10/stock-photo-1943540-communicating-soldier.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:53:"stock-photo-1943540-communicating-soldier-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:53:"stock-photo-1943540-communicating-soldier-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:51:"stock-photo-1943540-communicating-soldier-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:53:"stock-photo-1943540-communicating-soldier-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:53:"stock-photo-1943540-communicating-soldier-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19241, 7021, '_wp_attached_file', '2014/10/stock-photo-1985508-black-hawk.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19251, 7021, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:42:"2014/10/stock-photo-1985508-black-hawk.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:42:"stock-photo-1985508-black-hawk-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"stock-photo-1985508-black-hawk-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:40:"stock-photo-1985508-black-hawk-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:42:"stock-photo-1985508-black-hawk-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:42:"stock-photo-1985508-black-hawk-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19261, 7031, '_wp_attached_file', '2014/10/stock-photo-2362750-female-engineer.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19271, 7031, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:252;s:4:"file";s:47:"2014/10/stock-photo-2362750-female-engineer.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"stock-photo-2362750-female-engineer-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:47:"stock-photo-2362750-female-engineer-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:45:"stock-photo-2362750-female-engineer-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:47:"stock-photo-2362750-female-engineer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:47:"stock-photo-2362750-female-engineer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19281, 7041, '_wp_attached_file', '2014/10/stock-photo-2931457-plugging-in-the-wires.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19291, 7041, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:53:"2014/10/stock-photo-2931457-plugging-in-the-wires.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:53:"stock-photo-2931457-plugging-in-the-wires-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:53:"stock-photo-2931457-plugging-in-the-wires-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:51:"stock-photo-2931457-plugging-in-the-wires-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:53:"stock-photo-2931457-plugging-in-the-wires-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:53:"stock-photo-2931457-plugging-in-the-wires-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19301, 7051, '_wp_attached_file', '2014/10/stock-photo-5928905-delivery-boy-series.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19311, 7051, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:253;s:4:"file";s:51:"2014/10/stock-photo-5928905-delivery-boy-series.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:51:"stock-photo-5928905-delivery-boy-series-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:51:"stock-photo-5928905-delivery-boy-series-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:49:"stock-photo-5928905-delivery-boy-series-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:51:"stock-photo-5928905-delivery-boy-series-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:51:"stock-photo-5928905-delivery-boy-series-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19321, 6911, '_edit_lock', '1412452305:1') ; 
INSERT INTO `wp_postmeta` VALUES (19331, 7061, '_edit_lock', '1412452931:1') ; 
INSERT INTO `wp_postmeta` VALUES (19341, 7061, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (19351, 7081, '_edit_lock', '1412452918:1') ; 
INSERT INTO `wp_postmeta` VALUES (19361, 7081, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (19371, 7111, '_edit_lock', '1412452909:1') ; 
INSERT INTO `wp_postmeta` VALUES (19381, 7111, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (19391, 38, '_edit_lock', '1412459359:1') ; 
INSERT INTO `wp_postmeta` VALUES (19401, 7151, '_edit_lock', '1412459750:1') ; 
INSERT INTO `wp_postmeta` VALUES (19411, 7151, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (19421, 7151, 'klasik_layout', 'two-col-left') ; 
INSERT INTO `wp_postmeta` VALUES (19431, 7151, 'page-title', 'About Us') ; 
INSERT INTO `wp_postmeta` VALUES (19441, 7171, '_wp_attached_file', '2014/10/founders.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (19451, 7171, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:650;s:6:"height";i:559;s:4:"file";s:20:"2014/10/founders.jpg";s:5:"sizes";a:11:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"founders-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"founders-300x258.jpg";s:5:"width";i:300;s:6:"height";i:258;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:18:"founders-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:16:"widget-portfolio";a:4:{s:4:"file";s:20:"founders-650x444.jpg";s:5:"width";i:650;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:20:"founders-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:20:"founders-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:20:"founders-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:20:"founders-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"image-slider";a:4:{s:4:"file";s:20:"founders-650x480.jpg";s:5:"width";i:650;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:20:"founders-650x320.jpg";s:5:"width";i:650;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:20:"founders-650x320.jpg";s:5:"width";i:650;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (19461, 7171, '_edit_lock', '1412453687:1') ; 
INSERT INTO `wp_postmeta` VALUES (19471, 7291, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (19481, 7291, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19491, 7291, '_menu_item_object_id', '7291') ; 
INSERT INTO `wp_postmeta` VALUES (19501, 7291, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (19511, 7291, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19521, 7291, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (19531, 7291, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (19541, 7291, '_menu_item_url', 'http://#') ; 
INSERT INTO `wp_postmeta` VALUES (19551, 7291, '_menu_item_orphaned', '1412454666') ; 
INSERT INTO `wp_postmeta` VALUES (19561, 7301, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (19571, 7301, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19581, 7301, '_menu_item_object_id', '42') ; 
INSERT INTO `wp_postmeta` VALUES (19591, 7301, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (19601, 7301, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19611, 7301, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (19621, 7301, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (19631, 7301, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (19641, 7301, '_menu_item_orphaned', '1412454704') ; 
INSERT INTO `wp_postmeta` VALUES (19651, 7311, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (19661, 7311, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19671, 7311, '_menu_item_object_id', '54') ; 
INSERT INTO `wp_postmeta` VALUES (19681, 7311, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (19691, 7311, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19701, 7311, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (19711, 7311, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (19721, 7311, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (19741, 7321, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (19751, 7321, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19761, 7321, '_menu_item_object_id', '208') ; 
INSERT INTO `wp_postmeta` VALUES (19771, 7321, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (19781, 7321, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19791, 7321, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (19801, 7321, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (19811, 7321, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (19831, 7331, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (19841, 7331, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19851, 7331, '_menu_item_object_id', '38') ; 
INSERT INTO `wp_postmeta` VALUES (19861, 7331, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (19871, 7331, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19881, 7331, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (19891, 7331, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (19901, 7331, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (19921, 7341, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (19931, 7341, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19941, 7341, '_menu_item_object_id', '119') ; 
INSERT INTO `wp_postmeta` VALUES (19951, 7341, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (19961, 7341, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19971, 7341, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (19981, 7341, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (19991, 7341, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (20011, 7361, '_wp_attached_file', '2014/10/cropped-BTSlogo-DkBlue21stCen2r.gif') ; 
INSERT INTO `wp_postmeta` VALUES (20021, 7361, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:959;s:6:"height";i:106;s:4:"file";s:43:"2014/10/cropped-BTSlogo-DkBlue21stCen2r.gif";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-150x106.gif";s:5:"width";i:150;s:6:"height";i:106;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:42:"cropped-BTSlogo-DkBlue21stCen2r-300x33.gif";s:5:"width";i:300;s:6:"height";i:33;s:9:"mime-type";s:9:"image/gif";}s:14:"widget-feature";a:4:{s:4:"file";s:41:"cropped-BTSlogo-DkBlue21stCen2r-50x50.gif";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/gif";}s:16:"widget-portfolio";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-750x106.gif";s:5:"width";i:750;s:6:"height";i:106;s:9:"mime-type";s:9:"image/gif";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-550x106.gif";s:5:"width";i:550;s:6:"height";i:106;s:9:"mime-type";s:9:"image/gif";}s:17:"widget-latestnews";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-550x106.gif";s:5:"width";i:550;s:6:"height";i:106;s:9:"mime-type";s:9:"image/gif";}s:11:"widget-post";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-100x100.gif";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/gif";}s:18:"widget-testimonial";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-100x100.gif";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/gif";}s:11:"entry-image";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-750x106.gif";s:5:"width";i:750;s:6:"height";i:106;s:9:"mime-type";s:9:"image/gif";}s:13:"entry-gallery";a:4:{s:4:"file";s:43:"cropped-BTSlogo-DkBlue21stCen2r-750x106.gif";s:5:"width";i:750;s:6:"height";i:106;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20031, 335, '_edit_lock', '1412465780:1') ; 
INSERT INTO `wp_postmeta` VALUES (20041, 7391, '_wp_attached_file', '2014/10/stock-photo-1948640-churning-dust.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (20051, 7391, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:759;s:4:"file";s:45:"2014/10/stock-photo-1948640-churning-dust.jpg";s:5:"sizes";a:12:{s:9:"thumbnail";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:46:"stock-photo-1948640-churning-dust-1024x681.jpg";s:5:"width";i:1024;s:6:"height";i:681;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:43:"stock-photo-1948640-churning-dust-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:16:"widget-portfolio";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-750x444.jpg";s:5:"width";i:750;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"image-slider";a:4:{s:4:"file";s:46:"stock-photo-1948640-churning-dust-1140x480.jpg";s:5:"width";i:1140;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:45:"stock-photo-1948640-churning-dust-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20061, 7401, '_wp_attached_file', '2014/10/stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (20071, 7401, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:380;s:6:"height";i:241;s:4:"file";s:78:"2014/10/stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:78:"stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:78:"stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains-300x190.jpg";s:5:"width";i:300;s:6:"height";i:190;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:76:"stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:78:"stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:78:"stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20081, 7411, '_wp_attached_file', '2014/10/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (20091, 7411, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:980;s:6:"height";i:550;s:4:"file";s:63:"2014/10/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg";s:5:"sizes";a:11:{s:9:"thumbnail";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:61:"stock-photo-5821161-army-boots-focus-on-front-pair1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:16:"widget-portfolio";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-750x444.jpg";s:5:"width";i:750;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"image-slider";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-980x480.jpg";s:5:"width";i:980;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:63:"stock-photo-5821161-army-boots-focus-on-front-pair1-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20101, 7421, '_wp_attached_file', '2014/10/stock-photo-23127282-doctors-during-computer-tomography-exam_resized.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (20111, 7421, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:950;s:6:"height";i:632;s:4:"file";s:80:"2014/10/stock-photo-23127282-doctors-during-computer-tomography-exam_resized.jpg";s:5:"sizes";a:11:{s:9:"thumbnail";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:78:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:16:"widget-portfolio";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-750x444.jpg";s:5:"width";i:750;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"image-slider";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-950x480.jpg";s:5:"width";i:950;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:80:"stock-photo-23127282-doctors-during-computer-tomography-exam_resized-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20121, 7431, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (20131, 7431, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (20141, 7431, '_menu_item_object_id', '7151') ; 
INSERT INTO `wp_postmeta` VALUES (20151, 7431, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (20161, 7431, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (20171, 7431, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (20181, 7431, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (20191, 7431, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (20211, 31, '_edit_lock', '1412456632:1') ; 
INSERT INTO `wp_postmeta` VALUES (20231, 335, '_post_restored_from', 'a:3:{s:20:"restored_revision_id";i:7381;s:16:"restored_by_user";i:1;s:13:"restored_time";i:1412457900;}') ; 
INSERT INTO `wp_postmeta` VALUES (20241, 7521, '_wp_attached_file', '2014/10/Amazon.png') ; 
INSERT INTO `wp_postmeta` VALUES (20251, 7521, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:229;s:6:"height";i:44;s:4:"file";s:18:"2014/10/Amazon.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Amazon-150x44.png";s:5:"width";i:150;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";}s:14:"widget-feature";a:4:{s:4:"file";s:16:"Amazon-50x44.png";s:5:"width";i:50;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";}s:11:"widget-post";a:4:{s:4:"file";s:17:"Amazon-100x44.png";s:5:"width";i:100;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";}s:18:"widget-testimonial";a:4:{s:4:"file";s:17:"Amazon-100x44.png";s:5:"width";i:100;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20261, 208, '_edit_lock', '1412457536:1') ; 
INSERT INTO `wp_postmeta` VALUES (20271, 7521, '_edit_lock', '1412457582:1') ; 
INSERT INTO `wp_postmeta` VALUES (20281, 122, '_edit_lock', '1412458035:1') ; 
INSERT INTO `wp_postmeta` VALUES (20291, 339, '_edit_lock', '1412458207:1') ; 
INSERT INTO `wp_postmeta` VALUES (20301, 7591, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20311, 7591, '_edit_lock', '1412458076:1') ; 
INSERT INTO `wp_postmeta` VALUES (20321, 7611, '_edit_lock', '1412458121:1') ; 
INSERT INTO `wp_postmeta` VALUES (20331, 7611, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20341, 339, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20351, 339, '_wp_trash_meta_time', '1412458355') ; 
INSERT INTO `wp_postmeta` VALUES (20361, 7681, '_wp_attached_file', '2014/10/cascaderunning-club.png') ; 
INSERT INTO `wp_postmeta` VALUES (20371, 7681, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:233;s:6:"height";i:45;s:4:"file";s:31:"2014/10/cascaderunning-club.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"cascaderunning-club-150x45.png";s:5:"width";i:150;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:14:"widget-feature";a:4:{s:4:"file";s:29:"cascaderunning-club-50x45.png";s:5:"width";i:50;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:11:"widget-post";a:4:{s:4:"file";s:30:"cascaderunning-club-100x45.png";s:5:"width";i:100;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}s:18:"widget-testimonial";a:4:{s:4:"file";s:30:"cascaderunning-club-100x45.png";s:5:"width";i:100;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20391, 7751, '_wp_attached_file', '2014/10/blurred_lines.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (20401, 7751, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2880;s:6:"height";i:1181;s:4:"file";s:25:"2014/10/blurred_lines.jpg";s:5:"sizes";a:12:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"blurred_lines-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"blurred_lines-300x123.jpg";s:5:"width";i:300;s:6:"height";i:123;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"blurred_lines-1024x419.jpg";s:5:"width";i:1024;s:6:"height";i:419;s:9:"mime-type";s:10:"image/jpeg";}s:14:"widget-feature";a:4:{s:4:"file";s:23:"blurred_lines-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}s:16:"widget-portfolio";a:4:{s:4:"file";s:25:"blurred_lines-750x444.jpg";s:5:"width";i:750;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:25:"blurred_lines-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:17:"widget-latestnews";a:4:{s:4:"file";s:25:"blurred_lines-550x330.jpg";s:5:"width";i:550;s:6:"height";i:330;s:9:"mime-type";s:10:"image/jpeg";}s:11:"widget-post";a:4:{s:4:"file";s:25:"blurred_lines-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:18:"widget-testimonial";a:4:{s:4:"file";s:25:"blurred_lines-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"image-slider";a:4:{s:4:"file";s:26:"blurred_lines-1170x480.jpg";s:5:"width";i:1170;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:11:"entry-image";a:4:{s:4:"file";s:25:"blurred_lines-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:13:"entry-gallery";a:4:{s:4:"file";s:25:"blurred_lines-750x320.jpg";s:5:"width";i:750;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (20411, 7151, '_thumbnail_id', '7751') ; 
INSERT INTO `wp_postmeta` VALUES (20421, 7781, '_edit_lock', '1412459827:1') ; 
INSERT INTO `wp_postmeta` VALUES (20431, 7781, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20441, 32, '_edit_lock', '1412459915:1') ; 
INSERT INTO `wp_postmeta` VALUES (20451, 32, '_thumbnail_id', '7751') ; 
INSERT INTO `wp_postmeta` VALUES (20461, 7801, '_edit_lock', '1412459866:1') ; 
INSERT INTO `wp_postmeta` VALUES (20471, 7801, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20481, 130, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20491, 130, '_wp_trash_meta_time', '1412459994') ; 
INSERT INTO `wp_postmeta` VALUES (20501, 335, '_thumbnail_id', '7751') ; 
INSERT INTO `wp_postmeta` VALUES (20511, 7831, '_edit_lock', '1412460062:1') ; 
INSERT INTO `wp_postmeta` VALUES (20521, 7831, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20531, 7851, '_edit_lock', '1412459965:1') ; 
INSERT INTO `wp_postmeta` VALUES (20541, 7851, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20551, 7871, '_edit_lock', '1412460105:1') ; 
INSERT INTO `wp_postmeta` VALUES (20561, 7871, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20571, 5521, '_thumbnail_id', '7751') ; 
INSERT INTO `wp_postmeta` VALUES (20581, 7901, '_edit_lock', '1412460339:1') ; 
INSERT INTO `wp_postmeta` VALUES (20591, 7901, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20601, 119, '_edit_lock', '1412460555:1') ; 
INSERT INTO `wp_postmeta` VALUES (20611, 7921, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (20621, 7921, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (20631, 7921, '_menu_item_object_id', '7921') ; 
INSERT INTO `wp_postmeta` VALUES (20641, 7921, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (20651, 7921, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (20661, 7921, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (20671, 7921, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (20681, 7921, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (20701, 5641, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20711, 5641, '_wp_trash_meta_time', '1412460649') ; 
INSERT INTO `wp_postmeta` VALUES (20721, 1, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20731, 1, '_wp_trash_meta_time', '1412460649') ; 
INSERT INTO `wp_postmeta` VALUES (20741, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}') ; 
INSERT INTO `wp_postmeta` VALUES (20751, 328, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20761, 328, '_wp_trash_meta_time', '1412460649') ; 
INSERT INTO `wp_postmeta` VALUES (20771, 237, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20781, 237, '_wp_trash_meta_time', '1412460650') ; 
INSERT INTO `wp_postmeta` VALUES (20791, 220, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20801, 220, '_wp_trash_meta_time', '1412460650') ; 
INSERT INTO `wp_postmeta` VALUES (20811, 103, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20821, 103, '_wp_trash_meta_time', '1412460650') ; 
INSERT INTO `wp_postmeta` VALUES (20831, 154, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20841, 154, '_wp_trash_meta_time', '1412460650') ; 
INSERT INTO `wp_postmeta` VALUES (20851, 115, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20861, 115, '_wp_trash_meta_time', '1412460651') ; 
INSERT INTO `wp_postmeta` VALUES (20871, 158, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (20881, 158, '_wp_trash_meta_time', '1412460651') ; 
INSERT INTO `wp_postmeta` VALUES (20891, 7991, '_edit_lock', '1412460602:1') ; 
INSERT INTO `wp_postmeta` VALUES (20901, 7991, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20911, 7991, '_thumbnail_id', '7411') ; 
INSERT INTO `wp_postmeta` VALUES (20931, 7991, 'klasik_slider_post', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (20941, 8011, '_edit_lock', '1412463812:1') ; 
INSERT INTO `wp_postmeta` VALUES (20951, 8011, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20961, 8011, '_thumbnail_id', '7421') ; 
INSERT INTO `wp_postmeta` VALUES (20981, 8011, 'klasik_slider_post', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (20991, 8031, '_edit_lock', '1412463783:1') ; 
INSERT INTO `wp_postmeta` VALUES (21001, 8031, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (21011, 8031, '_thumbnail_id', '7401') ; 
INSERT INTO `wp_postmeta` VALUES (21031, 8061, '_edit_lock', '1412463000:1') ; 
INSERT INTO `wp_postmeta` VALUES (21041, 8061, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (21051, 8061, '_thumbnail_id', '6991') ; 
INSERT INTO `wp_postmeta` VALUES (21071, 8081, '_edit_lock', '1412463020:1') ; 
INSERT INTO `wp_postmeta` VALUES (21081, 8081, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (21091, 8081, '_thumbnail_id', '7391') ; 
INSERT INTO `wp_postmeta` VALUES (21121, 8081, 'klasik_slider_post', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (21141, 8061, 'klasik_slider_post', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (21161, 8031, 'klasik_slider_post', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (21201, 5231, '_edit_lock', '1412465696:1') ; 
INSERT INTO `wp_postmeta` VALUES (21211, 5231, '_post_restored_from', 'a:3:{s:20:"restored_revision_id";i:8101;s:16:"restored_by_user";i:1;s:13:"restored_time";i:1412465170;}') ; 
INSERT INTO `wp_postmeta` VALUES (21221, 5231, '_oembed_362642fdc4173f8576f8e55da52ecb93', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21231, 5231, '_oembed_e5e17f8cd832c36f31030a6c60af4e4a', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21261, 5241, '_edit_lock', '1412463711:1') ; 
INSERT INTO `wp_postmeta` VALUES (21271, 5241, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (21281, 5241, '_wp_trash_meta_time', '1412463852') ; 
INSERT INTO `wp_postmeta` VALUES (21291, 5231, '_oembed_0ca70c1be39929b7db54cdda206afc3b', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21301, 8141, '_edit_lock', '1412467851:1') ; 
INSERT INTO `wp_postmeta` VALUES (21311, 8141, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (21321, 5231, '_oembed_28c11c91b31108ca384043b0e08bce32', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21341, 8141, '_wp_page_template', 'page-list-events.php') ; 
INSERT INTO `wp_postmeta` VALUES (21351, 5231, '_oembed_db9e5c224ec3d9cd437202a0b93072d9', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21361, 5231, '_oembed_284db962902dc03cef5c4739c9875495', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21371, 5231, '_oembed_b10e5025132d81ced33c42cd372ef542', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21381, 5231, '_oembed_451dcddb4c042e35ba32e5ff643c9bfd', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21391, 5231, '_oembed_c915094324062d5df7dbef2158b24710', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21401, 5231, '_oembed_0fbc7687c5f23474b362d13c11e7de60', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21411, 5231, '_oembed_73b3f714c6945902f29a99754577ce04', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21421, 5231, '_oembed_32ab3ff5e6d7a41d3c1051d14cb04144', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21431, 5231, '_oembed_1539797f6777c27a037a930686801b3a', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21441, 5231, '_oembed_824f36a5241214f14f49cc14506bb8aa', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21451, 5231, '_oembed_38b2e3e9a78011868cfe49002a86bda6', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21461, 5231, '_oembed_7dc97a049fcc1b2ed92a9dfe08fc6c89', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21471, 5231, '_oembed_705cb09cacc4c8edffeeca3122eff33a', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21481, 5231, '_oembed_40d06fca0fb9dd22b5c37c70406fb511', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21491, 5231, '_oembed_35d91d2f998c4810b0d4ff96aaeb57f8', '{{unknown}}') ; 
INSERT INTO `wp_postmeta` VALUES (21501, 8291, '_wp_attached_file', '2014/10/BTSlogo.png') ; 
INSERT INTO `wp_postmeta` VALUES (21511, 8291, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:100;s:4:"file";s:19:"2014/10/BTSlogo.png";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"BTSlogo-150x100.png";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"BTSlogo-300x37.png";s:5:"width";i:300;s:6:"height";i:37;s:9:"mime-type";s:9:"image/png";}s:14:"widget-feature";a:4:{s:4:"file";s:17:"BTSlogo-50x50.png";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/png";}s:16:"widget-portfolio";a:4:{s:4:"file";s:19:"BTSlogo-750x100.png";s:5:"width";i:750;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:19:"widget-advancedpost";a:4:{s:4:"file";s:19:"BTSlogo-550x100.png";s:5:"width";i:550;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:17:"widget-latestnews";a:4:{s:4:"file";s:19:"BTSlogo-550x100.png";s:5:"width";i:550;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:11:"widget-post";a:4:{s:4:"file";s:19:"BTSlogo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:18:"widget-testimonial";a:4:{s:4:"file";s:19:"BTSlogo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:11:"entry-image";a:4:{s:4:"file";s:19:"BTSlogo-750x100.png";s:5:"width";i:750;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:13:"entry-gallery";a:4:{s:4:"file";s:19:"BTSlogo-750x100.png";s:5:"width";i:750;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=8301 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (236 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-10-04 02:32:37', '2014-10-04 02:32:37', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world', '', '', '2014-10-04 22:10:49', '2014-10-04 22:10:49', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-10-04 02:32:37', '2014-10-04 02:32:37', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://bootstoshoes2014.azurewebsites.net/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-10-04 02:32:37', '2014-10-04 02:32:37', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-10-04 02:33:23', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 02:33:23', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=12', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-10-04 02:39:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 02:39:58', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=21', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-02-03 10:40:13', '2014-02-03 10:40:13', '', 'pacificcont', '', 'inherit', 'open', 'open', '', 'pacificcont-2', '', '', '2014-10-04 21:48:20', '2014-10-04 21:48:20', '', 6841, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2013/12/pacificcont1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2014-02-04 04:25:20', '2014-02-04 04:25:20', 'Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That\'s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.[gallery ids="64,86,59,23,10"]

&nbsp;
<h1>Thank you</h1>
</div>', 'Our Story', '', 'publish', 'open', 'open', '', 'bootstoshoes', '', '', '2014-02-04 04:25:20', '2014-02-04 04:25:20', '', 117, 'http://temp.bootstoshoes.org/?page_id=30', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-10-04 02:52:27', '2014-10-04 02:52:27', '', 'Register', '', 'publish', 'open', 'open', '', 'register', '', '', '2014-10-04 02:52:27', '2014-10-04 02:52:27', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=31', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2014-02-04 04:26:09', '2014-02-04 04:26:09', '<h3>Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search.</h3>
<!--more-->

<strong>A mentor will also provide:</strong>
<ul>
	<li><strong>Insight into the language of civilian professions</strong></li>
	<li><strong>Objective discussions of your career goals</strong></li>
	<li><strong>Encourage as you develop a job search PLAN</strong></li>
	<li><strong>A sounding board and checkpoint for progress, and</strong></li>
	<li><strong>Appreciation for your service.</strong></li>
</ul>
<span style="font-size: 1.17em; line-height: 1.5em;">If you are ready to get started with a mentor </span><a style="font-size: 1.17em; line-height: 1.5em;" href="http://bootstoshoes.org/files/application.pdf">click here</a><span style="font-size: 1.17em; line-height: 1.5em;">. If you have questions, </span><a style="font-size: 1.17em; line-height: 1.5em;" title="Mission" href="http://temp.bootstoshoes.org/boots-to-shoes/contact/">contact us</a><span style="font-size: 1.17em; line-height: 1.5em;">.</span>

&nbsp;', 'Veteran Mentoring', '', 'publish', 'open', 'open', '', 'veterans', '', '', '2014-10-04 21:59:32', '2014-10-04 21:59:32', '', 0, 'http://temp.bootstoshoes.org/?page_id=32', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2014-02-04 04:26:59', '2014-02-04 04:26:59', '<h4>What will a mentor do for me? Why do I need a mentor?</h4>
A BTS trained mentor will meet one-on-one with you and will challenge and inspire you to do your best on your job search, provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn\'t considered. A BTS mentor may provide practical information regarding their career profession, entry requirements, opportunities for advancement and employment outlook.
<h4>As a veteran, how do I know a mentor will be a good match for me?</h4>
Veterans and mentors are matched basedhh on location and career interest or specialty. Of course, we recognize that people don\'t automatically "click" and if that is the case for either person, let us know and we will arrange a reassignment.
<h4>How much do your services cost?</h4>
Our services are provided at no cost.
<h4><span style="font-size: 1em; line-height: 1.5em;">What do you mean by "greater Puget Sound area"?</span></h4>
Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.
<h4>Are there any BTS mentors outside of the Puget Sound area?</h4>
No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.
<h4>Where do you get volunteers? How do you recruit mentors?</h4>
We frequently make presentations at area professional associations, community groups and businesses.  Our volunteers reflect employees from many companies and disciplines in the Puget Sound region including Information Technology, Logistics, Human Resources, Finance, and Business Management.
<h4>I don\'t have time to be a mentor, can I be supportive in some other way?</h4>
Of course! You can invite Boots to Shoes to present program information to your company or professional association.  Donations are always welcome.
<h4>How could my company get involved?</h4>
Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.

You may request BTS be added to your Company\'s donation match program.

Your company may sponsor BTS activities and Veteran Education.', 'FAQ\'s', '', 'publish', 'open', 'open', '', 'faqs', '', '', '2014-10-04 21:47:28', '2014-10-04 21:47:28', '', 0, 'http://temp.bootstoshoes.org/?page_id=38', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2014-02-04 04:27:49', '2014-02-04 04:27:49', '<em><strong>"The Boots to Shoes mission is to augment veterans support services for 21st century Veterans\' successful </strong></em><em style="line-height: 1.5em;"><strong>transition into civilian jobs.</strong></em><em style="line-height: 1.5em;"><strong> It serves as an </strong></em><em style="line-height: 1.5em;"><strong>example for </strong></em><em style="line-height: 1.5em;"><strong>going forward by giving back."</strong> </em><span style="line-height: 1.5em;"> </span>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans\' service to country.

<em> Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

In the words of General David Patraeus,<em> " While the military does a great job preparing our citizens to be soldiers, it does a less wonderful job preparing them to be citizens again."</em>', 'Mission', '', 'publish', 'closed', 'closed', '', 'mission', '', '', '2014-10-04 17:41:04', '2014-10-04 17:41:04', '', 0, 'http://temp.bootstoshoes.org/?page_id=40', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-10-04 02:52:27', '2014-10-04 02:52:27', '', 'Account', '', 'publish', 'open', 'open', '', 'account', '', '', '2014-10-04 02:52:27', '2014-10-04 02:52:27', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=41', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2014-02-04 04:28:02', '2014-02-04 04:28:02', '<strong> </strong>

<strong>April 29 -30, 2014</strong>

JBLM AACAP Prep Career Day Workshops and Career Day, American Lake Conference Center, Joint Base Lewis McChord WA

<strong>May 15, 2014</strong>

Job and Resource Fair, King County Veterans Program, Washington National Guard Readiness Center, Kent WA

<strong>June 5, 2014</strong>

RecruitMilitary Job Fair, Safeco Field, Seattle WA

<strong style="line-height: 1.5em;">June 21, 2014</strong>

Veterans Resource Fair, Tacoma Dome

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Attend an Event', '', 'publish', 'open', 'open', '', 'events', '', '', '2014-10-04 17:40:56', '2014-10-04 17:40:56', '', 0, 'http://temp.bootstoshoes.org/?page_id=42', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-10-04 02:52:27', '2014-10-04 02:52:27', '<p>The content you are trying to access is only available to members. Sorry.</p>', 'Protected Content', '', 'publish', 'open', 'open', '', 'protected', '', '', '2014-10-04 02:52:27', '2014-10-04 02:52:27', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=51', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-02-18 08:40:59', '2014-02-18 08:40:59', '<a href="mailto:staff@bootstoshoes.org">staff@bootstoshoes.org</a>

Patricia Conover, Program Director
Boots to Shoes Foundation
<span class="baec5a81-e4d6-4674-97f3-e9220f0136c1" style="white-space: nowrap;">425-284-1453</span>

&nbsp;

Mail:
Boots to Shoes Foundation
218 Main Street #690
Kirkland, WA 98033', 'Contact Us', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-02-18 08:40:59', '2014-02-18 08:40:59', '', 0, 'http://temp.bootstoshoes.org/?page_id=54', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-10-04 03:34:49', '2014-10-04 03:34:49', 'This page is accessible only to members.', 'Sample Members-Only Page', '', 'private', 'open', 'open', '', 'sample-members-only-page', '', '', '2014-10-04 23:40:03', '2014-10-04 23:40:03', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=61', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-10-04 03:34:49', '2014-10-04 03:34:49', 'This page is accessible only to members.', 'Sample Members-Only Page', '', 'inherit', 'open', 'open', '', '61-revision-v1', '', '', '2014-10-04 03:34:49', '2014-10-04 03:34:49', '', 61, 'http://bootstoshoes2014.azurewebsites.net/?p=71', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-03-07 09:14:52', '2014-03-07 09:14:52', '<a href="http://temp.bootstoshoes.org/wp-content/uploads/2014/03/IMG_9212.jpg"> </a>', ' ', '', 'trash', 'open', 'open', '', 'test-post', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 0, 'http://temp.bootstoshoes.org/?p=103', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2014-03-04 21:02:46', '2014-03-04 21:02:46', '', ' ', '', 'trash', 'open', 'open', '', 'about-us', '', '', '2014-10-04 22:10:51', '2014-10-04 22:10:51', '', 0, 'http://temp.bootstoshoes.org/?p=115', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-03-08 21:06:18', '2014-03-08 21:06:18', 'Our services are available to all military branches in the Puget Sound region at no cost.

<strong>Services include:</strong>

<em>Veteran Mentoring</em>

Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search. A mentor will also provide:
<p align="left">• Insight into interviewing and the language of civilian professions,</p>
<p align="left">• Resume reviews and objective discussion of career goals,</p>
<p align="left">• Encouragement as you develop a job search plan,</p>
<p align="left">• A sounding board &amp; checkpoint for progress, and</p>
<p align="left">• Appreciation for your service.</p>
<p align="left">Veteran/Mentor matches are based on career interests and geographic proximity. Orientation is provided for all participants.</p>
<em>Mock Interviews</em>

Veterans practice interviewing skills individually with a business professional. Veterans experience techniques used in today\'s competitive job environment and receive specific feedback to improve their interview results.

If you are ready to get started with a mentor <a href="http://bootstoshoes.org/files/application.pdf">click here.</a>

If you have questions <a title="Contact Us" href="http://temp.bootstoshoes.org/boots-to-shoes/contact/">contact us.</a>

&nbsp;

&nbsp;', 'Services', '', 'publish', 'open', 'open', '', 'boots-to-shoes', '', '', '2014-03-08 21:06:18', '2014-03-08 21:06:18', '', 0, 'http://temp.bootstoshoes.org/?page_id=117', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-03-08 21:08:07', '2014-03-08 21:08:07', '<strong>Tricia Stromberg, President/Founder                         board@bootstoshoes.org</strong>
Ms. Stromberg is a retired Boeing Engineer and Associate Technical Fellow. Her engineering career centered on military aircraft systems and spanned all services; from the Army Cobra Helicopter to the Air Force F-22. Also, 20 some years as a Marine Corps spouse brought her into close contact with the everyday challenges faced by families whose military member is sent into harm’s way. Throughout her career, Ms. Stromberg has interviewed, hired, and managed and mentored numerous individuals in career transition. She has over 14 years serving on non-profit\' Boards of Directors including 7 years as President of Seattle’s Spectrum Dance Theater and now serving as the Boots to Shoes Foundation President since 2010.
</hr>
<strong>Ed Doyne, Vice President                                           board@bootstoshoes.org</strong> Mr. Doyne is a technology consultant with 20 years’ experience in creating and operating telecom, data center, and co-location facilities. He served 20 years as a US Marine officer, including combat service in Vietnam, receiving a Purple Heart. He is currently a board member of the Blue and Gold Foundation, NROTC University of Washington. Mr. Doyne effectively executed a successful transition to civilian life and through his business has interviewed, hired, and mentored numerous individuals. He continues to assist individuals with job search planning and interview skills at BTS outreach events. He additionally volunteers with the BlinkNow non-profit organization supporting their orphanage and school in Nepal.
</hr>
<strong>Russ Stromberg, Secretary/Treasurer/Founder    board@bootstoshoes.org</strong>
Mr. Stromberg is a retired U.S. Marine Corps officer, Viet Nam veteran and graduate of the U.S. Naval Academy. While in the Marine Corps, he served two tours as a test pilot and was the Commanding Officer of two AV-8B squadrons. After his retirement from the Marines in 1990, he moved to Washington state. Mr. Stromberg founded his first of several successful businesses, all of which are primarily focused on supporting a variety of military programs to include the Joint Strike Fighter Program, several unmanned aerial vehicle programs and a variety of training and logistics support programs. Mr. Stromberg has hired, managed, coached, and mentored employees and job seekers. Mr. Stromberg and his wife\'s philantropy has benefited numerous Puget Sound area non-profit organizations.
</hr>
<strong>Rick Rezabek, Board Member/Founder               board@bootstoshoes.org</strong>
Mr. Rezabek is an Aerospace Engineer with over 25 years experience in developing and delivering modern aerospace products and programs. Mr. Rezabek was the Chief Engineer of Lockheed\'s Joint Strike Fighter X-35 Demonstration Aircraft. As a program manager in the highly technical world of aerospace engineering, Mr. Rezabek has provided career guidance to many team members. He is currently working with Unmanned Aerial Vehicle (UAV) products across several manufacturers. Mr. Rezabek partnered with Mr. Stromberg to create a successful business that was able to offer many jobs to veterans. He has served on the Boots to Shoes Board of Directors since 2010.
</hr>
<strong>Mike Martinez, Board Member                               board@bootstoshoes.org</strong>
Mr. Martinez is a Veteran of the U.S. Marine Corps, and an operations &amp; logistics program manager with Starbucks, working nationally and internationally, with both wholesale and retail infrastructure. He has long served the Puget Sound community as a Blue &amp; Gold Officer and volunteer mentor for high school students seeking admission to the United States Naval Academy. Mr. Martinez earned his Master’s degree at Seattle University and his undergraduate degree from USNA. Having grown up in the Seattle area, Mr. Martinez continues to make it his home with his wife and three children. He is also active in coaching youth sports and serving on school committees. Mr. Martinez joined the Board in 2011 and supports mentor and veteran outreach activities.
</hr>
<strong>Tori Ehlert, Board Member                                       board@bootstoshoes.org</strong>
Ms. Ehlert was a military spouse for over 20 years and served as ombudsman for many military families separated from spouses who were serving in areas of conflict. Ms. Ehlert dedicated herself to the health and welfare of those families as well as raising two daughters while her own spouse was away on extended duty. She joined the BTS Board of Directors in 2011. In addition she volunteers with the Motley Zoo Animal Rescue, and serves on Redmond High School Cheer Association Board. Ms. Ehlert can frequently be seen at Military Job Fairs assisting transitioning soldiers and veterans with their mentor applications.
</hr>
<strong>Mike McGuire                                                            board@bootstoshoes.org</strong>
Mike McGuire is a retired Army officer, with 26 years active service. He had overseas assignments in Thailand, Turkey and Belgium and held a number of key positions in the US, such as a Financial Comptroller in US Army Special Operations Command, and the Comptroller of the 7th Infantry Division. Retiring to the Tacoma area, he had a second career with Ernst &amp; Young LLP, retiring as the Associate Director of Finance. He is now with Northrop Grumman working the Global Combat Support System-Army. In addition to assisting with mentor and veteran outreach with BTS since 2011, Mr. McGuire continues to mentor veterans, which he describes as a “labor of love” because it is a way of supporting America’s Veterans. Mike enjoys time with his wife and family; 3 of their 4 children have served in the active Army.', 'Board and Staff', '', 'publish', 'open', 'open', '', 'board-staff', '', '', '2014-10-04 22:09:13', '2014-10-04 22:09:13', '', 0, 'http://temp.bootstoshoes.org/?page_id=119', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-03-08 21:08:42', '2014-03-08 21:08:42', 'As a Veteran are you ready to sign up for a mentor?

Click <a href="http://bootstoshoes.org/files/application.pdf"><span style="text-decoration: underline;">HERE</span></a> to complete an application

&nbsp;

<strong>Ready to become a mentor?</strong>

Click HERE to complete an application

&nbsp;

<strong>Ready to make a donation?</strong>

Click <a title="Donate" href="http://temp.bootstoshoes.org/donate/">HERE</a> to use our easy, secure on-line donation service.

&nbsp;

<strong>Ready to volunteer for other opportunities?</strong>

Click HERE to view other volunteer needs', 'Get Involved', '', 'publish', 'open', 'open', '', 'get-involved', '', '', '2014-03-08 21:08:42', '2014-03-08 21:08:42', '', 117, 'http://temp.bootstoshoes.org/?page_id=122', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-03-08 21:22:57', '2014-03-08 21:22:57', '<em>Imagine this scenario: A transitioning veteran submits a resume on line reflecting his military leadership skills and commendations. Not only does he not receive any interviews, other than an electronic “We have received your application,” he receives no personal acknowledgement at all.</em>

<em>Or this scenario: Pursuing an opportunity with a “veteran-friendly” employer, a veteran is one of 3 candidates to interview for a single position. One candidate previously worked for the employer, and one worked for the employer’s competition. The veteran candidate has relevant experience however he is not prepared to speak of his accomplishments in their civilian terminology.</em>

Veterans, new to industry, find themselves in these situations despite their leadership skills and significant levels of experience and responsibility. A Veterans’ Employment Challenges study reported that 66% of veterans said finding a job is the greatest challenge in transitioning to civilian life. BTS mentors provide a veteran with insight into the language of civilian professions, encouragement in developing a job search plan, a sounding board and checkpoint for progress.
A mentor’s role includes providing an understanding of
• civilian job language, for example the role of a human resources professional in private industry differs from a military human resources role,
• employment sources,
• professional networking protocol (e.g. how to follow up with contacts made at a networking event),
• job search planning verses reacting to each on-line job posting, and
• encouragement throughout the process.
A mentor assists a veteran as they translate military skills and accomplishments into civilian terms, define employment objectives, and offer practical advice about how and where to network as their job search gets underway. Finally, they may coach veterans on effective job interviewing, building confidence and success.', 'Volunteer', '', 'trash', 'open', 'open', '', 'volunteer', '', '', '2014-10-04 21:59:54', '2014-10-04 21:59:54', '', 0, 'http://temp.bootstoshoes.org/?page_id=130', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2014-03-06 21:42:52', '2014-03-06 21:42:52', '', ' ', '', 'trash', 'open', 'open', '', 'veterans', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 0, 'http://temp.bootstoshoes.org/?p=154', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (158, 1, '2014-03-03 21:44:07', '2014-03-03 21:44:07', '', ' ', '', 'trash', 'open', 'open', '', 'get-involved', '', '', '2014-10-04 22:10:51', '2014-10-04 22:10:51', '', 0, 'http://temp.bootstoshoes.org/?p=158', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (208, 1, '2014-03-09 21:44:12', '2014-03-09 21:44:12', '<span style="color: #000000;">Your donation will help Veterans connect with mentors from the local business community.</span>

The costs to make those connections involve:
<ul>
	<li>community outreach to engage volunteer mentors
military job fair table fees where BTS engages</li>
	<li>Veterans mentor training workshops</li>
	<li>brochures, phones, computers and website to communicate services</li>
	<li>database maintenance for mentor</li>
	<li>Veteran match ups</li>
	<li>one on one meetings with Veteran</li>
	<li>interview practice sessions</li>
</ul>
All supported by your donations, thank you.  The Veterans thank you, too!

Boots to Shoes Foundation is a 501(c)(3) charity. Your gift is tax deductible.
<h2>Donate online</h2>
Make a secure online donation now using <a href="https://co.clickandpledge.com/sp/d1/default.aspx?wid=59847">Click &amp; Pledge</a>.
<h2>Donate by mail</h2>
Complete our donation form and make your check payable to Boots to Shoes Foundation. Mail your check and completed donation form to:

Boots to Shoes Foundation  218 Main Street #690  Kirkland, WA 98033

Have a Question about donations?

Please contact us: <a href="mailto:staff@bootstoshoes.org">staff@bootstoshoes.org</a>', 'Donate', '', 'publish', 'open', 'open', '', 'donate', '', '', '2014-03-09 21:44:12', '2014-03-09 21:44:12', '', 0, 'http://temp.bootstoshoes.org/?page_id=208', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (220, 1, '2014-03-14 02:19:34', '2014-03-14 02:19:34', '', ' ', '', 'trash', 'open', 'open', '', 'new-1', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 0, 'http://temp.bootstoshoes.org/?p=220', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (222, 1, '2014-03-14 02:21:09', '2014-03-14 02:21:09', '', ' ', '', 'trash', 'open', 'open', '', 'new-2', '', '', '2014-10-04 18:20:08', '2014-10-04 18:20:08', '', 0, 'http://temp.bootstoshoes.org/?p=222', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (225, 1, '2014-03-14 08:45:07', '0000-00-00 00:00:00', '<a href="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/03/stock-photo-16595789-stars-and-stripes-background.jpg"><img class="alignleft size-medium wp-image-216" alt="stock-photo-16595789-stars-and-stripes-background" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/03/stock-photo-16595789-stars-and-stripes-background-300x181.jpg" /></a>', 'Slideshow Test Page', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-14 08:45:07', '0000-00-00 00:00:00', '', 0, 'http://temp.bootstoshoes.org/?page_id=225', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (237, 1, '2014-03-16 21:11:42', '2014-03-16 21:11:42', 'Get involved with us to help veterans.', 'Volunteer', '', 'trash', 'open', 'open', '', 'get-involved-2', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 0, 'http://temp.bootstoshoes.org/?p=237', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (328, 1, '2014-04-17 19:33:59', '2014-04-17 19:33:59', '', 'stock-photo-23127282-doctors-during-computer-tomography-exam', '', 'trash', 'open', 'open', '', 'stock-photo-23127282-doctors-during-computer-tomography-exam', '', '', '2014-10-04 22:10:49', '2014-10-04 22:10:49', '', 0, 'http://temp.bootstoshoes.org/?p=328', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (335, 1, '2014-04-18 07:36:37', '2014-04-18 07:36:37', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through Camo2Commerce</strong>
<h2><em>"Interview savvy" - 4 hours</em></h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2><em>"Mentor savvy" - 3 hours</em></h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search. It provides background on the tools for a 21st century job search, effective mentoring competencies, and BTS protocols for mentors.

<strong>Currently available through the BTS office and location in Pierce and Thurston counties.</strong>
<h2><em><strong>"Community outreach" - 1.5 hours</strong></em></h2>
This presentation provides education and awareness to the business and professional communities on the hurdles facing current generation veterans seeking employment; And adds understanding and increased appreciation for the skills and capabilities of these thoroughly trained and motivated veteran job seekers.

<strong>Currently available upon request</strong>', 'Education', '', 'publish', 'open', 'open', '', 'education', '', '', '2014-10-04 23:38:03', '2014-10-04 23:38:03', '', 0, 'http://temp.bootstoshoes.org/?page_id=335', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (339, 1, '2014-06-24 17:23:43', '2014-06-24 17:23:43', ' <strong>What do you mean by "greater Puget Sound area"?</strong>
<p align="left">Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.</p>
<p align="left"><strong>Are there any BTS mentors outside of the Puget Sound area?</strong></p>
<p align="left">No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.</p>
<p align="left"><strong>What will a mentor do for me? Why do I need a mentor?</strong></p>
<p align="left">A mentor is a coach who will challenge and inspire you to do your best on your job search. A mentor will provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn’t considered. In addition a mentor may provide practical information regarding their profession, entry requirements, opportunities for advancement and employment outlook. The July 2010 issue of The Phoenix Word quotes U.S. Army, Lt. Col. Danny Dudek , "You have to own your fight, sign up for the resources, and follow through."</p>
<p align="left"><strong>As a Veteran, how do I know a mentor will be a good match for me?</strong></p>
<p align="left">Veterans and mentors are matched based on career interests and geography. Of course, we recognize that people don’t automatically “click.” If that is the case for either party, just let us know and the assignment can be changed.</p>
<p align="left"><strong>I don\'t have time to be a mentor, can I be supportive in some other way?</strong></p>
<p align="left">Of course! You can invite Boots to Shoes to present program information to your company or professional association or participate in a mock interview. <a title="Donate" href="http://temp.bootstoshoes.org/donate/">Donations are always welcome.</a></p>
<p align="left"><strong>How could my company get involved?</strong></p>
<p align="left">Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.</p>
<p align="left"><strong>What kind of commitment would a mentor have to make?</strong></p>
<p align="left">The commitment includes a combination of one-on-one and phone meetings two times per month for 6 months. By mutual agreement, Veterans and Mentors may continue to meet after the six month commitment, if the interaction proves beneficial.</p>
<p align="left"><strong>How much do your services cost?</strong></p>
<p align="left">Our services are provided at no cost.</p>
<p align="left"><strong>When I complete an application, how will my information be used?</strong></p>
<p align="left">Your information will only be used to connect you with a mentor or Veteran and to communicate Boots to Shoes program updates.</p>
<p align="left"><strong>How can I find out where the next event will be held?</strong></p>
<p align="left">Please call us or contact us by email at <a href="mailto:staff@bootstoshoes.org">staff@bootstoshoes.org</a> </p>
<p align="left"> <strong>Where do your volunteers (mentors and others) come from?</strong></p>
<p align="left">Here are some examples of organizations where we have presented our program and engaged volunteers:</p>
<p align="left">• American Society for Training and Development – Puget Sound</p>
<p align="left">• CBRE - Bellevue, WA</p>
<p align="left">• Columbia Bank – Tacoma, WA</p>
<p align="left">• Corsair Engineering – Kirkland, WA</p>
<p align="left">• Lake Washington SHRM – Bellevue, WA</p>
<p align="left">• Microsoft – Redmond, WA</p>
<p align="left">• Olympia Society of Human Resource Management (SHRM) – Lacey, WA</p>
<p align="left">• South Puget Sound SHRM – Tacoma, WA</p>
<p align="left">• Starbucks – Seattle, WA</p>
<p align="left">• Seattle Kiwanis – Seattle, WA</p>
<p align="left">• Target – Lacey, WA</p>
<p align="left">• The Boeing Company – Everett, WA</p>
<p align="left">• United States Marine Corp Support Group</p>
<p align="left">• Volt – Redmond, WA</p>
<p align="left">• Weyerhaeuser – Federal Way, WA</p>
&nbsp;', 'FAQs', '', 'trash', 'open', 'open', '', 'faqs-2', '', '', '2014-10-04 21:32:35', '2014-10-04 21:32:35', '', 0, 'http://temp.bootstoshoes.org/?page_id=339', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (349, 1, '2014-04-18 07:50:07', '2014-04-18 07:50:07', '<p align="left"><strong>What are Veterans saying about their Boots to Shoes experience?</strong></p>
" . . . I received the call the day before Thanksgiving, accepted . . . Thank you so much for all the help, guidance, and tools you\'ve given me through the Boots to Shoes program. I truly appreciate what you and my mentor have done to help me over the past several months. He has been a great mentor and a tremendous resource during all my endeavors. I feel that I would not have been as successful without your workshops and [my mentor] Mark\'s recommendations and insight." – Ret. LTC Army
<p align="left">" . . . set up mock interviews so I could practice selling myself to prospective employers. . . . I was able to land a wonderful job last summer with [employer]. My resume looked good, the interview was too easy and my confidence won them over." –Ret. SFC Army</p>
<p align="left">Ready to get started with a mentor? <a href="http://bootstoshoes.org/files/application.pdf">Click here.</a></p>', 'Quotes', '', 'publish', 'open', 'open', '', 'quotes', '', '', '2014-04-18 07:50:07', '2014-04-18 07:50:07', '', 0, 'http://temp.bootstoshoes.org/?page_id=349', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3921, 1, '2013-12-01 00:00:00', '2013-12-01 00:00:00', '', 'blackram', '', 'inherit', 'open', 'open', '', 'blackram-2', '', '', '2014-10-04 19:24:09', '2014-10-04 19:24:09', '', 6881, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2013/12/blackram.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (5131, 1, '2014-10-04 04:41:06', '2014-10-04 04:41:06', '', 'FAQ\'s', '', 'publish', 'open', 'open', '', '5131', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5131', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5141, 1, '2014-10-04 04:41:06', '2014-10-04 04:41:06', ' ', '', '', 'publish', 'open', 'open', '', '5141', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5141', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5151, 1, '2014-10-04 04:41:06', '2014-10-04 04:41:06', ' ', '', '', 'publish', 'open', 'open', '', '5151', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5151', 12, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5191, 1, '2014-10-04 04:41:06', '2014-10-04 04:41:06', '', 'Services', '', 'publish', 'open', 'open', '', 'services', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5191', 11, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5211, 1, '2014-03-09 01:32:20', '2014-03-09 01:32:20', '', 'Home', '', 'trash', 'closed', 'closed', '', 'home', '', '', '2014-10-04 17:45:29', '2014-10-04 17:45:29', '', 0, 'http://temp.bootstoshoes.org/?page_id=181', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5221, 1, '2014-03-09 01:32:20', '2014-03-09 01:32:20', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home-2', '', '', '2014-10-04 17:20:53', '2014-10-04 17:20:53', '', 0, 'http://temp.bootstoshoes.org/?page_id=181', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5231, 1, '2014-04-18 07:38:18', '2014-04-18 07:38:18', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
<a href="http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf">http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf</a>
<h2>Workforce Central, Tacoma</h2>
<a href="http://www.workforce-central.org/">http://www.workforce-central.org/</a>
<h2>Employer Support of the Guard and Reserve</h2>
<a href="http://www.esgr.mil/">http://www.esgr.mil/</a>
<h2>Washington Dept. of Veterans Affairs</h2>
<a href="http://www.dva.wa.gov/">http://www.dva.wa.gov/</a>
<h2>King County Veterans Program</h2>
<a href="http://www.kingcounty.gov/socialservices/veterans.aspx">http://www.kingcounty.gov/socialservices/veterans.aspx</a>
<h2>Camo2Commerce</h2>
<a href="http://www.pacmtn.org/camo-2-commerce/">http://www.pacmtn.org/camo-2-commerce/</a>
<h2>Columbia Basin College</h2>
<a href="http://www.columbiabasin.edu/">http://www.columbiabasin.edu/</a>
<h2>Veterans Training Support Center, Edmonds WA</h2>
<a href="http://veteranstrainingsupportcenter.org/">http://veteranstrainingsupportcenter.org/</a>

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;
<h2></h2>
<h2></h2>
&nbsp;

&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'publish', 'open', 'open', '', 'partners-2', '', '', '2014-10-04 23:37:09', '2014-10-04 23:37:09', '', 0, 'http://temp.bootstoshoes.org/?page_id=341', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5241, 1, '2014-04-18 07:38:18', '2014-04-18 07:38:18', '', 'Partners', '', 'trash', 'open', 'open', '', 'partners', '', '', '2014-10-04 23:04:12', '2014-10-04 23:04:12', '', 0, 'http://temp.bootstoshoes.org/?page_id=341', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5281, 1, '2014-10-04 04:41:07', '2014-10-04 04:41:07', ' ', '', '', 'publish', 'open', 'open', '', '5281', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5281', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5321, 1, '2014-10-04 04:41:07', '2014-10-04 04:41:07', ' ', '', '', 'publish', 'open', 'open', '', '5321', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5321', 13, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5331, 1, '2014-10-04 04:41:08', '2014-10-04 04:41:08', ' ', '', '', 'publish', 'open', 'open', '', '5331', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5331', 15, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5341, 1, '2014-10-04 04:41:08', '2014-10-04 04:41:08', '', 'Network', '', 'publish', 'open', 'open', '', '5341', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5341', 14, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5351, 1, '2014-10-04 16:53:17', '0000-00-00 00:00:00', '', 'Klasik Logo Image', '', 'draft', 'closed', 'closed', '', 'of-klasik_logo_image', '', '', '2014-10-04 16:53:17', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=optionsframework&p=5351', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5361, 1, '2014-10-04 16:53:17', '0000-00-00 00:00:00', '', 'Klasik Favicon', '', 'draft', 'closed', 'closed', '', 'of-klasik_favicon', '', '', '2014-10-04 16:53:17', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=optionsframework&p=5361', 0, 'optionsframework', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5371, 1, '2014-10-04 16:55:05', '2014-10-04 16:55:05', '', 'stock-photo-23127282-doctors-during-computer-tomography-exam', '', 'inherit', 'open', 'open', '', '328-revision-v1', '', '', '2014-10-04 16:55:05', '2014-10-04 16:55:05', '', 328, 'http://bootstoshoes2014.azurewebsites.net/?p=5371', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5381, 1, '2014-10-04 16:57:13', '2014-10-04 16:57:13', 'Get involved with us to help veterans.', 'Volunteer', '', 'inherit', 'open', 'open', '', '237-revision-v1', '', '', '2014-10-04 16:57:13', '2014-10-04 16:57:13', '', 237, 'http://bootstoshoes2014.azurewebsites.net/?p=5381', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5391, 1, '2014-10-04 16:58:40', '2014-10-04 16:58:40', '', ' ', '', 'inherit', 'open', 'open', '', '222-revision-v1', '', '', '2014-10-04 16:58:40', '2014-10-04 16:58:40', '', 222, 'http://bootstoshoes2014.azurewebsites.net/?p=5391', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5401, 1, '2014-10-04 17:11:33', '2014-10-04 17:11:33', '<em><strong>"The Boots to Shoes mission is to augment veterans support services for 21st century Veterans\' successful </strong></em><em style="line-height: 1.5em;"><strong>transition into civilian jobs.</strong></em><em style="line-height: 1.5em;"><strong> It serves as an </strong></em><em style="line-height: 1.5em;"><strong>example for </strong></em><em style="line-height: 1.5em;"><strong>going forward by giving back."</strong> </em><span style="line-height: 1.5em;"> </span>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans\' service to country.

<em> Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

In the words of General David Patraeus,<em> " While the military does a great job preparing our citizens to be soldiers, it does a less wonderful job preparing them to be citizens again."</em>', 'Mission', '', 'inherit', 'open', 'open', '', '40-revision-v1', '', '', '2014-10-04 17:11:33', '2014-10-04 17:11:33', '', 40, 'http://bootstoshoes2014.azurewebsites.net/?p=5401', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5411, 1, '2014-10-04 17:17:47', '2014-10-04 17:17:47', '', 'Home', '', 'inherit', 'open', 'open', '', '5221-revision-v1', '', '', '2014-10-04 17:17:47', '2014-10-04 17:17:47', '', 5221, 'http://bootstoshoes2014.azurewebsites.net/?p=5411', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5421, 1, '2014-10-04 17:17:58', '2014-10-04 17:17:58', '', 'Home', '', 'inherit', 'open', 'open', '', '5211-revision-v1', '', '', '2014-10-04 17:17:58', '2014-10-04 17:17:58', '', 5211, 'http://bootstoshoes2014.azurewebsites.net/?p=5421', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5461, 1, '2014-10-04 17:25:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 17:25:16', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5461', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5481, 1, '2014-10-04 17:37:23', '2014-10-04 17:37:23', '', 'Donor Wall', '', 'publish', 'open', 'open', '', 'donor-wall', '', '', '2014-10-04 22:15:36', '2014-10-04 22:15:36', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=5481', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5491, 1, '2014-10-04 17:37:23', '2014-10-04 17:37:23', '', 'Donor Wall', '', 'inherit', 'open', 'open', '', '5481-revision-v1', '', '', '2014-10-04 17:37:23', '2014-10-04 17:37:23', '', 5481, 'http://bootstoshoes2014.azurewebsites.net/?p=5491', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5501, 1, '2014-10-04 17:40:04', '2014-10-04 17:40:04', ' ', '', '', 'publish', 'open', 'open', '', '5501', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5501', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5511, 1, '2014-10-04 17:40:56', '2014-10-04 17:40:56', '<strong> </strong>

<strong>April 29 -30, 2014</strong>

JBLM AACAP Prep Career Day Workshops and Career Day, American Lake Conference Center, Joint Base Lewis McChord WA

<strong>May 15, 2014</strong>

Job and Resource Fair, King County Veterans Program, Washington National Guard Readiness Center, Kent WA

<strong>June 5, 2014</strong>

RecruitMilitary Job Fair, Safeco Field, Seattle WA

<strong style="line-height: 1.5em;">June 21, 2014</strong>

Veterans Resource Fair, Tacoma Dome

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Attend an Event', '', 'inherit', 'open', 'open', '', '42-revision-v1', '', '', '2014-10-04 17:40:56', '2014-10-04 17:40:56', '', 42, 'http://bootstoshoes2014.azurewebsites.net/?p=5511', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5521, 1, '2014-10-04 17:41:32', '2014-10-04 17:41:32', '<h3>Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search.</h3>
<!--more-->

<strong>A volunteer makes a six month commitment to provide:</strong>
<ul>
	<li><strong>Insight into the language of civilian professions</strong></li>
	<li><strong>Resume review and feedback</strong></li>
	<li><strong>Objective discussions of your career goals</strong></li>
	<li><strong>Interview practice</strong></li>
	<li><strong>Encourage as you develop a job search PLAN</strong></li>
	<li><strong>A sounding board and checkpoint for progress</strong></li>
	<li><strong>Appreciation for your service.</strong></li>
</ul>
<strong>Our services are available at no cost to all military branches. The service area currently includes </strong><strong>the greater Puget Sound area of Washington State.</strong>

<strong>Veteran/Mentor matches are based on career interest and geographic proximity.</strong>

<span style="font-size: 1.17em; line-height: 1.5em;">If you are ready to get started with a mentor </span><a style="font-size: 1.17em; line-height: 1.5em;" href="http://bootstoshoes.org/files/application.pdf">click here</a><span style="font-size: 1.17em; line-height: 1.5em;">. If you have questions, </span><a style="font-size: 1.17em; line-height: 1.5em;" title="Mission" href="http://temp.bootstoshoes.org/boots-to-shoes/contact/">contact us</a><span style="font-size: 1.17em; line-height: 1.5em;">.</span>

&nbsp;', 'Be a Mentor', '', 'publish', 'open', 'open', '', 'be-a-mentor', '', '', '2014-10-04 22:03:28', '2014-10-04 22:03:28', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=5521', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5531, 1, '2014-10-04 17:41:32', '2014-10-04 17:41:32', '', 'Be a Mentor', '', 'inherit', 'open', 'open', '', '5521-revision-v1', '', '', '2014-10-04 17:41:32', '2014-10-04 17:41:32', '', 5521, 'http://bootstoshoes2014.azurewebsites.net/?p=5531', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5541, 1, '2014-10-04 17:41:53', '2014-10-04 17:41:53', '', 'Other Ways to Help', '', 'publish', 'open', 'open', '', 'other-ways-to-help', '', '', '2014-10-04 17:41:53', '2014-10-04 17:41:53', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=5541', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5551, 1, '2014-10-04 17:41:53', '2014-10-04 17:41:53', '', 'Other Ways to Help', '', 'inherit', 'open', 'open', '', '5541-revision-v1', '', '', '2014-10-04 17:41:53', '2014-10-04 17:41:53', '', 5541, 'http://bootstoshoes2014.azurewebsites.net/?p=5551', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5561, 1, '2014-10-04 17:44:23', '2014-10-04 17:44:23', ' ', '', '', 'publish', 'open', 'open', '', '5561', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5561', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5571, 1, '2014-10-04 17:44:23', '2014-10-04 17:44:23', ' ', '', '', 'publish', 'open', 'open', '', '5571', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5571', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5581, 1, '2014-10-04 17:46:40', '2014-10-04 17:46:40', ' ', '', '', 'publish', 'open', 'open', '', '5581', '', '', '2014-10-04 22:12:42', '2014-10-04 22:12:42', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5581', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5591, 1, '2014-10-04 17:48:08', '2014-10-04 17:48:08', '', 'Testimonials', '', 'publish', 'open', 'open', '', 'what-they-say', '', '', '2014-10-04 21:03:20', '2014-10-04 21:03:20', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=5591', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5601, 1, '2014-10-04 17:48:08', '2014-10-04 17:48:08', '', 'What They Say', '', 'inherit', 'open', 'open', '', '5591-revision-v1', '', '', '2014-10-04 17:48:08', '2014-10-04 17:48:08', '', 5591, 'http://bootstoshoes2014.azurewebsites.net/5591-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5611, 1, '2014-10-04 17:48:32', '2014-10-04 17:48:32', ' ', '', '', 'publish', 'open', 'open', '', '5611', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5611', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5631, 1, '2014-10-04 18:07:51', '2014-10-04 18:07:51', '<a href="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/02/stock-photo-5821161-army-boots-focus-on-front-pair.jpg"><img class="alignnone size-full wp-image-4281" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/02/stock-photo-5821161-army-boots-focus-on-front-pair.jpg" alt="stock-photo-5821161-army-boots-focus-on-front-pair" width="980" height="550" /></a>', 'Home', '', 'inherit', 'open', 'open', '', '5221-autosave-v1', '', '', '2014-10-04 18:07:51', '2014-10-04 18:07:51', '', 5221, 'http://bootstoshoes2014.azurewebsites.net/5221-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5641, 1, '2014-10-04 18:16:58', '2014-10-04 18:16:58', '[caption id="attachment_86" align="alignnone" width="980"]<a href="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/02/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg"><img class="size-full wp-image-86" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/02/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg" alt="Volunteer Alt text" width="980" height="550" /></a> Volunteer[/caption]', '', '', 'trash', 'open', 'open', '', '5641', '', '', '2014-10-04 22:10:49', '2014-10-04 22:10:49', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=5641', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5651, 1, '2014-10-04 18:16:58', '2014-10-04 18:16:58', '[caption id="attachment_86" align="alignnone" width="980"]<a href="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/02/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg"><img class="size-full wp-image-86" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/02/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg" alt="Volunteer Alt text" width="980" height="550" /></a> Volunteer[/caption]', '', '', 'inherit', 'open', 'open', '', '5641-revision-v1', '', '', '2014-10-04 18:16:58', '2014-10-04 18:16:58', '', 5641, 'http://bootstoshoes2014.azurewebsites.net/5641-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5661, 1, '2014-10-04 18:43:20', '2014-10-04 18:43:20', '<a href="http://www.amazon.com"><img class="alignnone size-full wp-image-91" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/Amazon.png" alt="Amazon" width="229" height="44" /></a>', 'Sponsor Amazon', '', 'trash', 'open', 'open', '', 'sponsor-amazon', '', '', '2014-10-04 18:43:28', '2014-10-04 18:43:28', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=5661', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5671, 1, '2014-10-04 18:43:20', '2014-10-04 18:43:20', '<a href="http://www.amazon.com"><img class="alignnone size-full wp-image-91" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/Amazon.png" alt="Amazon" width="229" height="44" /></a>', 'Sponsor Amazon', '', 'inherit', 'open', 'open', '', '5661-revision-v1', '', '', '2014-10-04 18:43:20', '2014-10-04 18:43:20', '', 5661, 'http://bootstoshoes2014.azurewebsites.net/5661-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5681, 1, '2014-10-04 18:44:04', '2014-10-04 18:44:04', '<img class="alignnone wp-image-91 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Amazon.png" alt="Amazon" width="229" height="44" />', 'Amazon', '', 'publish', 'open', 'open', '', 'amazon', '', '', '2014-10-04 21:22:59', '2014-10-04 21:22:59', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&#038;p=5681', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5691, 1, '2014-10-04 18:44:04', '2014-10-04 18:44:04', '<a href="http://www.amazon.com"><img class="alignnone size-full wp-image-91" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/Amazon.png" alt="Amazon" width="229" height="44" /></a>', 'Amazon', '', 'inherit', 'open', 'open', '', '5681-revision-v1', '', '', '2014-10-04 18:44:04', '2014-10-04 18:44:04', '', 5681, 'http://bootstoshoes2014.azurewebsites.net/5681-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5701, 1, '2014-10-04 18:46:55', '2014-10-04 18:46:55', '<img class="alignnone wp-image-7681 size-thumbnail" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/cascaderunning-club-150x45.png" alt="cascaderunning-club" width="150" height="45" />', 'Cascade Running Club', '', 'publish', 'open', 'open', '', 'cascade-running-club', '', '', '2014-10-04 21:47:24', '2014-10-04 21:47:24', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&#038;p=5701', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5711, 1, '2014-10-04 18:46:55', '2014-10-04 18:46:55', '<a href="http://http://www.cascaderunningclub.com/"><img class="alignnone size-full wp-image-5081" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/04/cascaderunning-club1.png" alt="cascaderunning club" width="233" height="45" /></a>', 'Cascade Running Club', '', 'inherit', 'open', 'open', '', '5701-revision-v1', '', '', '2014-10-04 18:46:55', '2014-10-04 18:46:55', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/5701-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5721, 1, '2014-10-04 18:47:54', '2014-10-04 18:47:54', '<a href="http://www.cascaderunningclub.com/"><img class="alignnone wp-image-5081 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/04/cascaderunning-club1.png" alt="cascaderunning club" width="233" height="45" /></a>', 'Cascade Running Club', '', 'inherit', 'open', 'open', '', '5701-revision-v1', '', '', '2014-10-04 18:47:54', '2014-10-04 18:47:54', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/5701-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5731, 1, '2014-10-04 18:50:22', '2014-10-04 18:50:22', '<img class="alignnone wp-image-3791 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/unitedway.png" alt="unitedway" width="130" height="75" />', 'United Way', '', 'publish', 'open', 'open', '', 'united-way', '', '', '2014-10-04 19:00:11', '2014-10-04 19:00:11', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&#038;p=5731', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5741, 1, '2014-10-04 18:50:22', '2014-10-04 18:50:22', '<a href="http://www.unitedway.org/"><img class="alignnone size-full wp-image-3791" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/unitedway.png" alt="unitedway" width="130" height="75" /></a>', 'United Way', '', 'inherit', 'open', 'open', '', '5731-revision-v1', '', '', '2014-10-04 18:50:22', '2014-10-04 18:50:22', '', 5731, 'http://bootstoshoes2014.azurewebsites.net/5731-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5751, 1, '2014-10-04 18:50:59', '0000-00-00 00:00:00', '', 'Schultz Family Foundation', '', 'draft', 'open', 'open', '', '', '', '', '2014-10-04 18:50:59', '2014-10-04 18:50:59', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&#038;p=5751', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5761, 1, '2014-10-04 18:59:50', '2014-10-04 18:59:50', '<img class="alignnone wp-image-5081 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/04/cascaderunning-club1.png" alt="cascaderunning club" width="233" height="45" />', 'Cascade Running Club', '', 'inherit', 'open', 'open', '', '5701-revision-v1', '', '', '2014-10-04 18:59:50', '2014-10-04 18:59:50', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/5701-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5771, 1, '2014-10-04 19:00:11', '2014-10-04 19:00:11', '<img class="alignnone wp-image-3791 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/unitedway.png" alt="unitedway" width="130" height="75" />', 'United Way', '', 'inherit', 'open', 'open', '', '5731-revision-v1', '', '', '2014-10-04 19:00:11', '2014-10-04 19:00:11', '', 5731, 'http://bootstoshoes2014.azurewebsites.net/5731-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5781, 1, '2014-10-04 19:00:39', '2014-10-04 19:00:39', '<img class="alignnone wp-image-91 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/Amazon.png" alt="Amazon" width="229" height="44" />', 'Amazon', '', 'inherit', 'open', 'open', '', '5681-revision-v1', '', '', '2014-10-04 19:00:39', '2014-10-04 19:00:39', '', 5681, 'http://bootstoshoes2014.azurewebsites.net/5681-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5811, 1, '2014-10-04 19:01:32', '2014-10-04 19:01:32', '', 'Boots-to-Shoes-Logo-300x75', '', 'inherit', 'open', 'open', '', 'boots-to-shoes-logo-300x75', '', '', '2014-10-04 21:45:41', '2014-10-04 21:45:41', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Boots-to-Shoes-Logo-300x75.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (5921, 1, '2014-10-04 19:01:41', '2014-10-04 19:01:41', '', 'corsair', '', 'inherit', 'open', 'open', '', 'corsair', '', '', '2014-10-04 19:23:25', '2014-10-04 19:23:25', '', 6861, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/corsair.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (5951, 1, '2014-10-04 19:01:43', '2014-10-04 19:01:43', '', 'unitedway', '', 'inherit', 'open', 'open', '', 'unitedway', '', '', '2014-10-04 19:01:43', '2014-10-04 19:01:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/unitedway.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (6571, 1, '2014-10-04 19:03:44', '2014-10-04 19:03:44', '', 'Rick-2-609x320', '', 'inherit', 'open', 'open', '', 'rick-2-609x320', '', '', '2014-10-04 19:03:44', '2014-10-04 19:03:44', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Rick-2-609x320.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6581, 1, '2014-10-04 19:03:45', '2014-10-04 19:03:45', '', 'Rick-2-609x600', '', 'inherit', 'open', 'open', '', 'rick-2-609x600', '', '', '2014-10-04 20:24:29', '2014-10-04 20:24:29', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Rick-2-609x600.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6791, 1, '2014-10-04 19:07:49', '2014-10-04 19:07:49', '<blockquote><em>"I am pleased to report that was he a great mentor, and I ended up getting the job I wanted. He was very good at keeping me focused and making forward progress. I feel lucky to have had his experience and knowledge to guide me. If he chooses to mentor again....I recommend him highly.” </em>

- USN Veteran</blockquote>', 'USN-Veteran-2', '', 'publish', 'closed', 'closed', '', 'ret-ltc-army', '', '', '2014-10-04 21:58:23', '2014-10-04 21:58:23', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=6791', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6801, 1, '2014-10-04 19:07:49', '2014-10-04 19:07:49', '” . . . I received the call the day before Thanksgiving, accepted . . . Thank you so much for all the help, guidance, and tools you’ve given me through the Boots to Shoes program. I truly appreciate what you and my mentor have done to help me over the past several months. He has been a great mentor and a tremendous resource during all my endeavors. I feel that I would not have been as successful without your workshops and [my mentor] Mark’s recommendations and insight.” – Ret. LTC Army', 'Ret. LTC Army', '', 'inherit', 'open', 'open', '', '6791-revision-v1', '', '', '2014-10-04 19:07:49', '2014-10-04 19:07:49', '', 6791, 'http://bootstoshoes2014.azurewebsites.net/6791-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6811, 1, '2014-10-04 19:07:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 19:07:56', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&p=6811', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6821, 1, '2014-10-04 19:08:49', '2014-10-04 19:08:49', '<blockquote>”<em>My mentor\'s advice and guidance from job search to practicing interview questions has been invaluable. She has really helped me stay on track and keep focused. I couldn’t have asked for a better mentor.”</em>

– USN Veteran</blockquote>', 'USN-Veteran', '', 'publish', 'closed', 'closed', '', 'ret-sfc-army', '', '', '2014-10-04 21:57:04', '2014-10-04 21:57:04', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=6821', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6831, 1, '2014-10-04 19:08:49', '2014-10-04 19:08:49', '” . . . set up mock interviews so I could practice selling myself to prospective employers. . . . I was able to land a wonderful job last summer with [employer]. My resume looked good, the interview was too easy and my confidence won them over.” –Ret. SFC Army', 'Ret. SFC Army', '', 'inherit', 'open', 'open', '', '6821-revision-v1', '', '', '2014-10-04 19:08:49', '2014-10-04 19:08:49', '', 6821, 'http://bootstoshoes2014.azurewebsites.net/6821-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6841, 1, '2014-10-04 19:22:49', '2014-10-04 19:22:49', '<img class="alignnone size-full wp-image-22" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2013/12/pacificcont1.png" alt="pacificcont" width="216" height="75" />', 'Pacific Continental', '', 'publish', 'open', 'open', '', 'pacific-continental', '', '', '2014-10-04 21:48:53', '2014-10-04 21:48:53', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&#038;p=6841', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6851, 1, '2014-10-04 19:22:49', '2014-10-04 19:22:49', '<img class="alignnone size-full wp-image-5941" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/pacificcont.png" alt="pacificcont" width="216" height="75" />', 'Pacific Continental', '', 'inherit', 'open', 'open', '', '6841-revision-v1', '', '', '2014-10-04 19:22:49', '2014-10-04 19:22:49', '', 6841, 'http://bootstoshoes2014.azurewebsites.net/6841-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6861, 1, '2014-10-04 19:23:36', '2014-10-04 19:23:36', '<img class="alignnone size-full wp-image-5921" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/corsair.png" alt="corsair" width="130" height="75" />', 'Corsair Engineering', '', 'publish', 'open', 'open', '', 'corsair-engineering', '', '', '2014-10-04 19:23:36', '2014-10-04 19:23:36', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&#038;p=6861', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6871, 1, '2014-10-04 19:23:36', '2014-10-04 19:23:36', '<img class="alignnone size-full wp-image-5921" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/corsair.png" alt="corsair" width="130" height="75" />', 'Corsair Engineering', '', 'inherit', 'open', 'open', '', '6861-revision-v1', '', '', '2014-10-04 19:23:36', '2014-10-04 19:23:36', '', 6861, 'http://bootstoshoes2014.azurewebsites.net/6861-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6881, 1, '2014-10-04 19:23:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 19:23:41', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=sponsor&p=6881', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6891, 1, '2014-10-04 19:46:18', '2014-10-04 19:46:18', '', 'stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another', '', 'inherit', 'open', 'open', '', 'stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another', '', '', '2014-10-04 19:46:18', '2014-10-04 19:46:18', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-6014749-relay-baton-passed-by-from-one-hand-to-another.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6901, 1, '2014-10-04 19:46:19', '2014-10-04 19:46:19', '', 'stock-photo-6237791-auto-mechanic', '', 'inherit', 'open', 'open', '', 'stock-photo-6237791-auto-mechanic', '', '', '2014-10-04 19:46:19', '2014-10-04 19:46:19', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-6237791-auto-mechanic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6911, 1, '2014-10-04 19:46:20', '2014-10-04 19:46:20', '', 'stock-photo-6588831-computer-repairing', '', 'inherit', 'open', 'open', '', 'stock-photo-6588831-computer-repairing', '', '', '2014-10-04 19:46:20', '2014-10-04 19:46:20', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-6588831-computer-repairing.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6921, 1, '2014-10-04 19:46:22', '2014-10-04 19:46:22', '', 'stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work', '', 'inherit', 'open', 'open', '', 'stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work', '', '', '2014-10-04 19:46:22', '2014-10-04 19:46:22', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-6841136-in-cockpit-of-an-airplane-young-woman-pilot-at-work.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6931, 1, '2014-10-04 19:46:23', '2014-10-04 19:46:23', '', 'stock-photo-9942879-modern-storehouse', '', 'inherit', 'open', 'open', '', 'stock-photo-9942879-modern-storehouse', '', '', '2014-10-04 19:46:23', '2014-10-04 19:46:23', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-9942879-modern-storehouse.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6941, 1, '2014-10-04 19:46:25', '2014-10-04 19:46:25', '', 'stock-photo-12925726-military-handshake', '', 'inherit', 'open', 'open', '', 'stock-photo-12925726-military-handshake', '', '', '2014-10-04 19:46:25', '2014-10-04 19:46:25', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-12925726-military-handshake.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6951, 1, '2014-10-04 19:46:27', '2014-10-04 19:46:27', '', 'stock-photo-16302628-female-american-soldier', '', 'inherit', 'open', 'open', '', 'stock-photo-16302628-female-american-soldier', '', '', '2014-10-04 19:46:27', '2014-10-04 19:46:27', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-16302628-female-american-soldier.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6961, 1, '2014-10-04 19:46:29', '2014-10-04 19:46:29', '', 'stock-photo-17603464-technician-and-engineer', '', 'inherit', 'open', 'open', '', 'stock-photo-17603464-technician-and-engineer', '', '', '2014-10-04 19:46:29', '2014-10-04 19:46:29', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-17603464-technician-and-engineer.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6971, 1, '2014-10-04 19:46:30', '2014-10-04 19:46:30', '', 'stock-photo-18060019-merkel-tours-energy-production-sites', '', 'inherit', 'open', 'open', '', 'stock-photo-18060019-merkel-tours-energy-production-sites', '', '', '2014-10-04 19:46:30', '2014-10-04 19:46:30', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-18060019-merkel-tours-energy-production-sites.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6981, 1, '2014-10-04 19:46:32', '2014-10-04 19:46:32', '', 'stock-photo-18149011-it-engineers-in-network-server-room', '', 'inherit', 'open', 'open', '', 'stock-photo-18149011-it-engineers-in-network-server-room', '', '', '2014-10-04 19:46:32', '2014-10-04 19:46:32', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-18149011-it-engineers-in-network-server-room.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6991, 1, '2014-10-04 19:46:34', '2014-10-04 19:46:34', '', 'stock-photo-19078655-people-working-together-in-shipping-warehouse', '', 'inherit', 'open', 'open', '', 'stock-photo-19078655-people-working-together-in-shipping-warehouse', '', '', '2014-10-04 19:46:34', '2014-10-04 19:46:34', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-19078655-people-working-together-in-shipping-warehouse.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7001, 1, '2014-10-04 19:46:35', '2014-10-04 19:46:35', '', 'stock-photo-24756209-hydro-biologist-testing-quality-of-water', '', 'inherit', 'open', 'open', '', 'stock-photo-24756209-hydro-biologist-testing-quality-of-water', '', '', '2014-10-04 19:46:35', '2014-10-04 19:46:35', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-24756209-hydro-biologist-testing-quality-of-water.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7011, 1, '2014-10-04 19:46:37', '2014-10-04 19:46:37', '', 'stock-photo-1943540-communicating-soldier', '', 'inherit', 'open', 'open', '', 'stock-photo-1943540-communicating-soldier', '', '', '2014-10-04 19:46:37', '2014-10-04 19:46:37', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-1943540-communicating-soldier.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7021, 1, '2014-10-04 19:46:39', '2014-10-04 19:46:39', '', 'stock-photo-1985508-black-hawk', '', 'inherit', 'open', 'open', '', 'stock-photo-1985508-black-hawk', '', '', '2014-10-04 19:46:39', '2014-10-04 19:46:39', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-1985508-black-hawk.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7031, 1, '2014-10-04 19:46:41', '2014-10-04 19:46:41', '', 'stock-photo-2362750-female-engineer', '', 'inherit', 'open', 'open', '', 'stock-photo-2362750-female-engineer', '', '', '2014-10-04 19:46:41', '2014-10-04 19:46:41', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-2362750-female-engineer.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7041, 1, '2014-10-04 19:46:44', '2014-10-04 19:46:44', '', 'stock-photo-2931457-plugging-in-the-wires', '', 'inherit', 'open', 'open', '', 'stock-photo-2931457-plugging-in-the-wires', '', '', '2014-10-04 19:46:44', '2014-10-04 19:46:44', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-2931457-plugging-in-the-wires.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7051, 1, '2014-10-04 19:46:45', '2014-10-04 19:46:45', '', 'stock-photo-5928905-delivery-boy-series', '', 'inherit', 'open', 'open', '', 'stock-photo-5928905-delivery-boy-series', '', '', '2014-10-04 19:46:45', '2014-10-04 19:46:45', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-5928905-delivery-boy-series.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7061, 1, '2014-10-09 19:52:50', '2014-10-09 19:52:50', 'Kirkland, WA', 'Mentor Savvy', '', 'future', 'closed', 'closed', '', 'mentor-savvy', '', '', '2014-10-04 20:02:11', '2014-10-04 20:02:11', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=event&#038;p=7061', 0, 'event', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7071, 1, '2014-10-04 19:52:50', '2014-10-04 19:52:50', '', 'Mentor Savvy', '', 'inherit', 'open', 'open', '', '7061-revision-v1', '', '', '2014-10-04 19:52:50', '2014-10-04 19:52:50', '', 7061, 'http://bootstoshoes2014.azurewebsites.net/7061-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7081, 1, '2014-10-14 19:53:50', '2014-10-14 19:53:50', 'Tacoma, WA', 'Heroes 2 Hometown', '', 'future', 'closed', 'closed', '', 'heroes-2-hometown', '', '', '2014-10-04 20:01:58', '2014-10-04 20:01:58', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=event&#038;p=7081', 0, 'event', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7091, 1, '2014-10-04 19:53:50', '2014-10-04 19:53:50', '', 'Heroes 2 Hometown', '', 'inherit', 'open', 'open', '', '7081-revision-v1', '', '', '2014-10-04 19:53:50', '2014-10-04 19:53:50', '', 7081, 'http://bootstoshoes2014.azurewebsites.net/7081-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7101, 1, '2014-10-04 19:53:55', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 19:53:55', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=event&p=7101', 0, 'event', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7111, 1, '2014-10-14 19:54:45', '2014-10-14 19:54:45', 'JBLM', 'Northwest Edge Cohort #5 Orientation', '', 'future', 'closed', 'closed', '', 'northwest-edge-cohort-5-orientation', '', '', '2014-10-04 20:01:49', '2014-10-04 20:01:49', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=event&#038;p=7111', 0, 'event', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7121, 1, '2014-10-04 19:54:45', '2014-10-04 19:54:45', 'JBLM', 'Northwest Edge Cohort #5 Orientation ', '', 'inherit', 'open', 'open', '', '7111-revision-v1', '', '', '2014-10-04 19:54:45', '2014-10-04 19:54:45', '', 7111, 'http://bootstoshoes2014.azurewebsites.net/7111-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7131, 1, '2014-10-04 19:55:02', '2014-10-04 19:55:02', 'Tacoma, WA', 'Heroes 2 Hometown', '', 'inherit', 'open', 'open', '', '7081-revision-v1', '', '', '2014-10-04 19:55:02', '2014-10-04 19:55:02', '', 7081, 'http://bootstoshoes2014.azurewebsites.net/7081-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7141, 1, '2014-10-04 19:55:22', '2014-10-04 19:55:22', 'Kirkland, WA', 'Mentor Savvy', '', 'inherit', 'open', 'open', '', '7061-revision-v1', '', '', '2014-10-04 19:55:22', '2014-10-04 19:55:22', '', 7061, 'http://bootstoshoes2014.azurewebsites.net/7061-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7151, 1, '2014-10-04 20:02:37', '2014-10-04 20:02:37', '<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.
<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

&nbsp;

</div>
<h4>From the Boots to Shoes Foundation</h4>
<blockquote>We are grateful to our veterans and military men and women for their services to our country.</blockquote>', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2014-10-04 21:58:02', '2014-10-04 21:58:02', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=7151', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7161, 1, '2014-10-04 19:59:42', '2014-10-04 19:59:42', '<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 19:59:42', '2014-10-04 19:59:42', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7171, 1, '2014-10-04 19:59:58', '2014-10-04 19:59:58', '', 'founders', '', 'inherit', 'open', 'open', '', 'founders', '', '', '2014-10-04 19:59:58', '2014-10-04 19:59:58', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/founders.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7181, 1, '2014-10-04 20:00:33', '2014-10-04 20:00:33', 'Our Mission
&nbsp;
<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:00:33', '2014-10-04 20:00:33', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7191, 1, '2014-10-04 20:28:43', '2014-10-04 20:28:43', '<h3>Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search.</h3>
<!--more-->

<strong>A volunteer makes a six month commitment to provide:</strong>
<ul>
	<li><strong>Insight into the language of civilian professions</strong></li>
	<li><strong>Resume review and feedback</strong></li>
	<li><strong>Objective discussions of your career goals</strong></li>
	<li><strong>Interview practice</strong></li>
	<li><strong>Encourage as you develop a job search PLAN</strong></li>
	<li><strong>A sounding board and checkpoint for progress</strong></li>
	<li><strong>Appreciation for your service.</strong></li>
</ul>
<strong>Our services are available at no cost to all military branches. The service area currently includes</strong><strong>the greater Puget Sound area of Washington State.</strong>

<span style="font-size: 1.17em; line-height: 1.5em;">If you are ready to get started with a mentor </span><a style="font-size: 1.17em; line-height: 1.5em;" href="http://bootstoshoes.org/files/application.pdf">click here</a><span style="font-size: 1.17em; line-height: 1.5em;">. If you have questions, </span><a style="font-size: 1.17em; line-height: 1.5em;" title="Mission" href="http://temp.bootstoshoes.org/boots-to-shoes/contact/">contact us</a><span style="font-size: 1.17em; line-height: 1.5em;">.</span>

&nbsp;', 'Be a Mentor', '', 'inherit', 'open', 'open', '', '5521-autosave-v1', '', '', '2014-10-04 20:28:43', '2014-10-04 20:28:43', '', 5521, 'http://bootstoshoes2014.azurewebsites.net/5521-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7201, 1, '2014-10-04 20:01:35', '2014-10-04 20:01:35', '<h3>Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search.</h3>
<!--more-->

<strong>A mentor will also provide:</strong>
<ul>
	<li><strong>Insight into the language of civilian professions</strong></li>
	<li><strong>Objective discussions of your career goals</strong></li>
	<li><strong>Encourage as you develop a job search PLAN</strong></li>
	<li><strong>A sounding board and checkpoint for progress, and</strong></li>
	<li><strong>Appreciation for your service.</strong></li>
</ul>
<span style="font-size: 1.17em; line-height: 1.5em;">If you are ready to get started with a mentor </span><a style="font-size: 1.17em; line-height: 1.5em;" href="http://bootstoshoes.org/files/application.pdf">click here</a><span style="font-size: 1.17em; line-height: 1.5em;">. If you have questions, </span><a style="font-size: 1.17em; line-height: 1.5em;" title="Mission" href="http://temp.bootstoshoes.org/boots-to-shoes/contact/">contact us</a><span style="font-size: 1.17em; line-height: 1.5em;">.</span>

&nbsp;', 'Be a Mentor', '', 'inherit', 'open', 'open', '', '5521-revision-v1', '', '', '2014-10-04 20:01:35', '2014-10-04 20:01:35', '', 5521, 'http://bootstoshoes2014.azurewebsites.net/5521-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7211, 1, '2014-10-04 20:01:54', '2014-10-04 20:01:54', 'Our Mission
&nbsp;
<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans’ service to country.
 Serving Washington state greater Puget Sound area since 2010
Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:01:54', '2014-10-04 20:01:54', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7221, 1, '2014-10-04 20:04:33', '2014-10-04 20:04:33', 'Our Mission
&nbsp;
<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:04:33', '2014-10-04 20:04:33', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7231, 1, '2014-10-04 20:05:01', '2014-10-04 20:05:01', '&nbsp;
Our Mission
&nbsp;
<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:05:01', '2014-10-04 20:05:01', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7241, 1, '2014-10-04 20:06:01', '2014-10-04 20:06:01', '&nbsp;
<h3>Our Mission</h3>
<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:06:01', '2014-10-04 20:06:01', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7251, 1, '2014-10-04 20:07:34', '2014-10-04 20:07:34', '&nbsp;
<h3>Our Mission</h3>
<hr>
<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>

Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans.  BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line:  appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

&nbsp;
<h3>Our Story</h3>


', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:07:34', '2014-10-04 20:07:34', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7261, 1, '2014-10-04 20:22:46', '2014-10-04 20:22:46', '&nbsp;
<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

&nbsp;
<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

</div>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:22:46', '2014-10-04 20:22:46', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7271, 1, '2014-10-04 20:23:15', '2014-10-04 20:23:15', '&nbsp;
<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.

<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

</div>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:23:15', '2014-10-04 20:23:15', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7281, 1, '2014-10-04 20:29:47', '2014-10-04 20:29:47', '<h3>Through a combination of one-on-one meetings and phone conversations, a mentor provides business knowledge as a veteran plans and conducts a job search.</h3>
<!--more-->

<strong>A volunteer makes a six month commitment to provide:</strong>
<ul>
	<li><strong>Insight into the language of civilian professions</strong></li>
	<li><strong>Resume review and feedback</strong></li>
	<li><strong>Objective discussions of your career goals</strong></li>
	<li><strong>Interview practice</strong></li>
	<li><strong>Encourage as you develop a job search PLAN</strong></li>
	<li><strong>A sounding board and checkpoint for progress</strong></li>
	<li><strong>Appreciation for your service.</strong></li>
</ul>
<strong>Our services are available at no cost to all military branches. The service area currently includes </strong><strong>the greater Puget Sound area of Washington State.</strong>

<strong>Veteran/Mentor matches are based on career interest and geographic proximity.</strong>

<span style="font-size: 1.17em; line-height: 1.5em;">If you are ready to get started with a mentor </span><a style="font-size: 1.17em; line-height: 1.5em;" href="http://bootstoshoes.org/files/application.pdf">click here</a><span style="font-size: 1.17em; line-height: 1.5em;">. If you have questions, </span><a style="font-size: 1.17em; line-height: 1.5em;" title="Mission" href="http://temp.bootstoshoes.org/boots-to-shoes/contact/">contact us</a><span style="font-size: 1.17em; line-height: 1.5em;">.</span>

&nbsp;', 'Be a Mentor', '', 'inherit', 'open', 'open', '', '5521-revision-v1', '', '', '2014-10-04 20:29:47', '2014-10-04 20:29:47', '', 5521, 'http://bootstoshoes2014.azurewebsites.net/5521-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7291, 1, '2014-10-04 20:31:05', '0000-00-00 00:00:00', '', 'About Us', '', 'draft', 'open', 'open', '', '', '', '', '2014-10-04 20:31:05', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7291', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7301, 1, '2014-10-04 20:31:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-10-04 20:31:44', '0000-00-00 00:00:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7301', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7311, 1, '2014-10-04 20:32:20', '2014-10-04 20:32:20', ' ', '', '', 'publish', 'open', 'open', '', '7311', '', '', '2014-10-04 20:34:05', '2014-10-04 20:34:05', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7311', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7321, 1, '2014-10-04 20:32:19', '2014-10-04 20:32:19', ' ', '', '', 'publish', 'open', 'open', '', '7321', '', '', '2014-10-04 20:34:05', '2014-10-04 20:34:05', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7321', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7331, 1, '2014-10-04 20:32:19', '2014-10-04 20:32:19', '', 'FAQ\'s', '', 'publish', 'open', 'open', '', 'faqs', '', '', '2014-10-04 20:34:05', '2014-10-04 20:34:05', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7331', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7341, 1, '2014-10-04 20:34:04', '2014-10-04 20:34:04', ' ', '', '', 'publish', 'open', 'open', '', '7341', '', '', '2014-10-04 20:34:05', '2014-10-04 20:34:05', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7341', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7351, 1, '2014-10-04 20:34:05', '2014-10-04 20:34:05', '&nbsp;
<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an examp<a href="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Rick-2-609x600.jpg"><img class="alignleft size-full wp-image-6581" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Rick-2-609x600.jpg" alt="Rick-2-609x600" width="609" height="600" /></a>le for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.
<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

</div>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:34:05', '2014-10-04 20:34:05', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7361, 1, '2014-10-04 20:34:37', '2014-10-04 20:34:37', '', 'cropped-BTSlogo-DkBlue21stCen2r', '', 'inherit', 'open', 'open', '', 'cropped-btslogo-dkblue21stcen2r', '', '', '2014-10-04 20:34:37', '2014-10-04 20:34:37', '', 5351, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/cropped-BTSlogo-DkBlue21stCen2r.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (7371, 1, '2014-10-04 20:35:11', '2014-10-04 20:35:11', '&nbsp;
<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.
<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

</div>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 20:35:11', '2014-10-04 20:35:11', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7381, 1, '2014-10-04 21:34:52', '2014-10-04 21:34:52', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through CamoZCommerce</strong>
<h2><em>"Interview savvy" - 4 hours</em></h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2><em>"Mentor savvy" - 3 hours</em></h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search. It provides background on the tools for a 21st century job search, effective mentoring competencies, and BTS protocols for mentors.

<strong>Currently available through the BTS office and location in Pierce and Thurston counties.</strong>
<h2><em><strong>"Community outreach" - 1.5 hours</strong></em></h2>
This presentation provides education and awareness to the business and professional communities on the hurdles facing current generation veterans seeking employment; And adds understanding and increased appreciation for the skills and capabilities of these thor', 'Education', '', 'inherit', 'open', 'open', '', '335-autosave-v1', '', '', '2014-10-04 21:34:52', '2014-10-04 21:34:52', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7391, 1, '2014-10-04 20:47:47', '2014-10-04 20:47:47', '', 'stock-photo-1948640-churning-dust', '', 'inherit', 'open', 'open', '', 'stock-photo-1948640-churning-dust', '', '', '2014-10-04 20:47:47', '2014-10-04 20:47:47', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-1948640-churning-dust.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7401, 1, '2014-10-04 20:47:52', '2014-10-04 20:47:52', '', 'stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains', '', 'inherit', 'open', 'open', '', 'stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains', '', '', '2014-10-04 20:47:52', '2014-10-04 20:47:52', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-2583774-merlin-helicopter-patroling-cumbrian-mountains.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7411, 1, '2014-10-04 20:47:59', '2014-10-04 20:47:59', '', 'stock-photo-5821161-army-boots-focus-on-front-pair', '', 'inherit', 'open', 'open', '', 'stock-photo-5821161-army-boots-focus-on-front-pair-2', '', '', '2014-10-04 20:47:59', '2014-10-04 20:47:59', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-5821161-army-boots-focus-on-front-pair1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7421, 1, '2014-10-04 20:48:05', '2014-10-04 20:48:05', '', 'stock-photo-23127282-doctors-during-computer-tomography-exam_resized', '', 'inherit', 'open', 'open', '', 'stock-photo-23127282-doctors-during-computer-tomography-exam_resized', '', '', '2014-10-04 20:48:05', '2014-10-04 20:48:05', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/stock-photo-23127282-doctors-during-computer-tomography-exam_resized.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7431, 1, '2014-10-04 21:01:39', '2014-10-04 21:01:39', ' ', '', '', 'publish', 'open', 'open', '', '7431', '', '', '2014-10-04 22:12:42', '2014-10-04 22:12:42', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7431', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7441, 1, '2014-10-04 21:03:20', '2014-10-04 21:03:20', '', 'Testimonials', '', 'inherit', 'open', 'open', '', '5591-revision-v1', '', '', '2014-10-04 21:03:20', '2014-10-04 21:03:20', '', 5591, 'http://bootstoshoes2014.azurewebsites.net/5591-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7461, 1, '2014-10-04 21:13:59', '2014-10-04 21:13:59', '', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:13:59', '2014-10-04 21:13:59', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7471, 1, '2014-10-04 21:14:41', '2014-10-04 21:14:41', '<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.
<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

&nbsp;

</div>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 21:14:41', '2014-10-04 21:14:41', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7481, 1, '2014-10-04 21:16:07', '2014-10-04 21:16:07', '<h4>What will a mentor do for me? Why do I need a mentor?</h4>
A BTS trained mentor will meet one-on-one with you and will challenge and inspire you to do your best on your job search, provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn\'t considered. A BTS mentor may provide practical information regarding their career profession, entry requirements, opportunities for advancement and employment outlook.
<h4>As a veteran, how do I know a mentor will be a good match for me?</h4>
Veterans and mentors are matched based on location and career interest or specialty. Of course, we recognize that people don\'t automatically "click" and if that is the case for either person, let us know and we will arrange a reassignment.
<h4>How much do your services cost?</h4>
Our services are provided at no cost.
<h4><span style="font-size: 1em; line-height: 1.5em;">What do you mean by "greater Puget Sound area"?</span></h4>
Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.
<h4>Are there any BTS mentors outside of the Puget Sound area?</h4>
No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.
<h4>Where do you get volunteers? How do you recruit mentors?</h4>
We frequently make presentations at area professional associations, community groups and businesses.  Our volunteers reflect employees from many companies and disciplines in the Puget Sound region including Information Technology, Logistics, Human Resources, Finance, and Business Management.
<h4>I don\'t have time to be a mentor, can I be supportive in some other way?</h4>
Of course! You can invite Boots to Shoes to present program information to your company or professional association.  Donations are always welcome.
<h4>How could my company get involved?</h4>
Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.', 'FAQ\'s', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-04 21:16:07', '2014-10-04 21:16:07', '', 38, 'http://bootstoshoes2014.azurewebsites.net/38-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7491, 1, '2014-10-04 21:47:32', '2014-10-04 21:47:32', '<h4>What will a mentor do for me? Why do I need a mentor?</h4>
<p>A BTS trained mentor will meet one-on-one with you and will challenge and inspire you to do your best on your job search, provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn\'t considered. A BTS mentor may provide practical information regarding their career profession, entry requirements, opportunities for advancement and employment outlook.</p>
<h4>As a veteran, how do I know a mentor will be a good match for me?</h4>
<p>Veterans and mentors are matched basedhh on location and career interest or specialty. Of course, we recognize that people don\'t automatically "click" and if that is the case for either person, let us know and we will arrange a reassignment.</p>
<h4>How much do your services cost?</h4>
<p>Our services are provided at no cost.</p>
<h4><span style="font-size: 1em; line-height: 1.5em;">What do you mean by "greater Puget Sound area"?</span></h4>
<p>Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.</p>
<h4>Are there any BTS mentors outside of the Puget Sound area?</h4>
<p>No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.</p>
<h4>Where do you get volunteers? How do you recruit mentors?</h4>
<p>We frequently make presentations at area professional associations, community groups and businesses.  Our volunteers reflect employees from many companies and disciplines in the Puget Sound region including Information Technology, Logistics, Human Resources, Finance, and Business Management.</p>
<h4>I don\'t have time to be a mentor, can I be supportive in some other way?</h4>
<p>Of course! You can invite Boots to Shoes to present program information to your company or professional association.  Donations are always welcome.</p>
<h4>How could my company get involved?</h4>
<p>Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.</p>
<p>You may request BTS be added to your Company\'s donation match program.</p>
<p>Your company may sponsor BTS activities and Veteran Education.</p>
', 'FAQ\'s', '', 'inherit', 'open', 'open', '', '38-autosave-v1', '', '', '2014-10-04 21:47:32', '2014-10-04 21:47:32', '', 38, 'http://bootstoshoes2014.azurewebsites.net/38-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7501, 1, '2014-10-04 21:18:57', '2014-10-04 21:18:57', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:18:57', '2014-10-04 21:18:57', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7511, 1, '2014-10-04 21:20:03', '2014-10-04 21:20:03', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:20:03', '2014-10-04 21:20:03', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7521, 1, '2014-10-04 21:20:57', '2014-10-04 21:20:57', '', 'Amazon', '', 'inherit', 'open', 'open', '', 'amazon-2', '', '', '2014-10-04 21:20:57', '2014-10-04 21:20:57', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Amazon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (7531, 1, '2014-10-04 21:21:06', '2014-10-04 21:21:06', '<h3>Our Mission</h3>

<hr />

<blockquote><em><strong>The Boots to Shoes mission is to augment veterans support services for 21st century Veterans’ successful transition into civilian jobs. It serves as an example for going forward by giving back.</strong></em></blockquote>
Boots to Shoes (BTS) accomplishes this by engaging and training volunteers from the business community to be mentors for transitioning veterans. BTS mentors are trained to provide coaching for resumes, job search plans, interview skills and echo the bottom line: appreciation for the veterans’ service to country.

<em>Serving Washington state greater Puget Sound area since 2010</em>

Boots to Shoes Foundation seeks to honor the veteran’s service to their country by helping close the unemployment gap currently experienced by post 9/11 veterans.
<h3>Our Story</h3>

<hr />

Men and women defend our nation through a rigor, discipline and language that may seem foreign to the nation they defend. That’s where we come in. Boots to Shoes understands the military/private sector divide and the bridge by which our warriors cross it.
<div>

The founders, a retired USMC Viet Nam era Veteran and his spouse, along with a business partner, determined through experience and investigation that most Veterans do not have a career oriented civilian network.  Transitioning military service men and women, returning from extended tours of duty in the Middle East and other places around the world, get a start with government provided programs.  They receive information on benefits, on translating their skills into civilian terms for their resumes and on the general process of job searches.  Next are the multi-layered online job searches, which lack human interface.  Job fairs offer opportunities for brief conversations with people in civilian industry.    The Boots to Shoes Foundation was formed to provide mentoring and address the further challenges of the transition.  Boots to Shoes engages volunteers from the local business community who are then trained to be mentors, providing personal coaching and supporting insight into a civilian business network.

Boots to Shoes volunteer mentors participate in a three hour workshop, BTS Mentor Savvy, taught by an experienced professional.  The course prepares them for meeting their assigned Veteran or transitioning military service person and provides guidelines on giving resume feedback, discussing interview strategy, and supporting a good job search plan.   All volunteers make a six month commitment.

The Boots to Shoes Foundation is a 501(c)(3) organization with a full-time Program Director, an active Board of Directors, and other part time support staff whose time is donated by a Puget Sound business.

&nbsp;

</div>

<h4>From the Boots to Shoes Foundation</h4>


<blockquote>We are grateful to our veterans and military men and women for their services to our country.</blockquote>', 'About Us', '', 'inherit', 'open', 'open', '', '7151-revision-v1', '', '', '2014-10-04 21:21:06', '2014-10-04 21:21:06', '', 7151, 'http://bootstoshoes2014.azurewebsites.net/7151-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7541, 1, '2014-10-04 21:21:53', '2014-10-04 21:21:53', '<img class="alignnone wp-image-91 size-full" src="hhttp://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Amazon.png" alt="Amazon" width="229" height="44" />', 'Amazon', '', 'inherit', 'open', 'open', '', '5681-revision-v1', '', '', '2014-10-04 21:21:53', '2014-10-04 21:21:53', '', 5681, 'http://bootstoshoes2014.azurewebsites.net/5681-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7551, 1, '2014-10-04 21:22:59', '2014-10-04 21:22:59', '<img class="alignnone wp-image-91 size-full" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/Amazon.png" alt="Amazon" width="229" height="44" />', 'Amazon', '', 'inherit', 'open', 'open', '', '5681-revision-v1', '', '', '2014-10-04 21:22:59', '2014-10-04 21:22:59', '', 5681, 'http://bootstoshoes2014.azurewebsites.net/5681-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7561, 1, '2014-10-04 21:25:00', '2014-10-04 21:25:00', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through CamoZCommerce</strong>
<h2>"Interview savvy" - 4 hours</h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2>"Mentor savvy" - 3</h2>', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:25:00', '2014-10-04 21:25:00', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7571, 1, '2014-10-04 21:26:37', '2014-10-04 21:26:37', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through CamoZCommerce</strong>
<h2>"Interview savvy" - 4 hours</h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2>"Mentor savvy" - 3 hours</h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:26:37', '2014-10-04 21:26:37', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7581, 1, '2014-10-04 21:29:49', '2014-10-04 21:29:49', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through CamoZCommerce</strong>
<h2>"Interview savvy" - 4 hours</h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2>"Mentor savvy" - 3 hours</h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search. It provides background on the tools for a 21st century job search, effective mentoring competencies, and BTS protocols for mentors.

<strong>Currently available through the BTS office and location in Pierce and Thurston counties.</strong>', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:29:49', '2014-10-04 21:29:49', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7591, 1, '2014-10-04 21:30:08', '2014-10-04 21:30:08', '', 'Other Volunteers', '', 'publish', 'open', 'open', '', 'other-volunteers', '', '', '2014-10-04 21:30:08', '2014-10-04 21:30:08', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=7591', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7601, 1, '2014-10-04 21:30:08', '2014-10-04 21:30:08', '', 'Other Volunteers', '', 'inherit', 'open', 'open', '', '7591-revision-v1', '', '', '2014-10-04 21:30:08', '2014-10-04 21:30:08', '', 7591, 'http://bootstoshoes2014.azurewebsites.net/7591-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7611, 1, '2014-10-04 21:30:57', '2014-10-04 21:30:57', '', 'Sign Up For a Mentor', '', 'publish', 'open', 'open', '', 'sign-up-for-a-mentor', '', '', '2014-10-04 21:30:57', '2014-10-04 21:30:57', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=7611', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7621, 1, '2014-10-04 21:30:57', '2014-10-04 21:30:57', '', 'Sign Up For a Mentor', '', 'inherit', 'open', 'open', '', '7611-revision-v1', '', '', '2014-10-04 21:30:57', '2014-10-04 21:30:57', '', 7611, 'http://bootstoshoes2014.azurewebsites.net/7611-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7631, 1, '2014-10-04 21:32:11', '2014-10-04 21:32:11', '<h4>What will a mentor do for me? Why do I need a mentor?</h4>
A BTS trained mentor will meet one-on-one with you and will challenge and inspire you to do your best on your job search, provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn\'t considered. A BTS mentor may provide practical information regarding their career profession, entry requirements, opportunities for advancement and employment outlook.
<h4>As a veteran, how do I know a mentor will be a good match for me?</h4>
Veterans and mentors are matched based on location and career interest or specialty. Of course, we recognize that people don\'t automatically "click" and if that is the case for either person, let us know and we will arrange a reassignment.
<h4>How much do your services cost?</h4>
Our services are provided at no cost.
<h4><span style="font-size: 1em; line-height: 1.5em;">What do you mean by "greater Puget Sound area"?</span></h4>
Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.
<h4>Are there any BTS mentors outside of the Puget Sound area?</h4>
No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.
<h4>Where do you get volunteers? How do you recruit mentors?</h4>
We frequently make presentations at area professional associations, community groups and businesses.  Our volunteers reflect employees from many companies and disciplines in the Puget Sound region including Information Technology, Logistics, Human Resources, Finance, and Business Management.
<h4>I don\'t have time to be a mentor, can I be supportive in some other way?</h4>
Of course! You can invite Boots to Shoes to present program information to your company or professional association.  Donations are always welcome.
<h4>How could my company get involved?</h4>
Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.
<p align="left">• American Society for Training and Development – Puget Sound</p>
<p align="left">• CBRE - Bellevue, WA</p>
<p align="left">• Columbia Bank – Tacoma, WA</p>
<p align="left">• Corsair Engineering – Kirkland, WA</p>
<p align="left">• Lake Washington SHRM – Bellevue, WA</p>
<p align="left">• Microsoft – Redmond, WA</p>
<p align="left">• Olympia Society of Human Resource Management (SHRM) – Lacey, WA</p>
<p align="left">• South Puget Sound SHRM – Tacoma, WA</p>
<p align="left">• Starbucks – Seattle, WA</p>
<p align="left">• Seattle Kiwanis – Seattle, WA</p>
<p align="left">• Target – Lacey, WA</p>
<p align="left">• The Boeing Company – Everett, WA</p>
<p align="left">• United States Marine Corp Support Group</p>
<p align="left">• Volt – Redmond, WA</p>
<p align="left">• Weyerhaeuser – Federal Way, WA</p>
&nbsp;', 'FAQ\'s', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-04 21:32:11', '2014-10-04 21:32:11', '', 38, 'http://bootstoshoes2014.azurewebsites.net/38-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7641, 1, '2014-10-04 21:32:35', '2014-10-04 21:32:35', ' <strong>What do you mean by "greater Puget Sound area"?</strong>
<p align="left">Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.</p>
<p align="left"><strong>Are there any BTS mentors outside of the Puget Sound area?</strong></p>
<p align="left">No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.</p>
<p align="left"><strong>What will a mentor do for me? Why do I need a mentor?</strong></p>
<p align="left">A mentor is a coach who will challenge and inspire you to do your best on your job search. A mentor will provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn’t considered. In addition a mentor may provide practical information regarding their profession, entry requirements, opportunities for advancement and employment outlook. The July 2010 issue of The Phoenix Word quotes U.S. Army, Lt. Col. Danny Dudek , "You have to own your fight, sign up for the resources, and follow through."</p>
<p align="left"><strong>As a Veteran, how do I know a mentor will be a good match for me?</strong></p>
<p align="left">Veterans and mentors are matched based on career interests and geography. Of course, we recognize that people don’t automatically “click.” If that is the case for either party, just let us know and the assignment can be changed.</p>
<p align="left"><strong>I don\'t have time to be a mentor, can I be supportive in some other way?</strong></p>
<p align="left">Of course! You can invite Boots to Shoes to present program information to your company or professional association or participate in a mock interview. <a title="Donate" href="http://temp.bootstoshoes.org/donate/">Donations are always welcome.</a></p>
<p align="left"><strong>How could my company get involved?</strong></p>
<p align="left">Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.</p>
<p align="left"><strong>What kind of commitment would a mentor have to make?</strong></p>
<p align="left">The commitment includes a combination of one-on-one and phone meetings two times per month for 6 months. By mutual agreement, Veterans and Mentors may continue to meet after the six month commitment, if the interaction proves beneficial.</p>
<p align="left"><strong>How much do your services cost?</strong></p>
<p align="left">Our services are provided at no cost.</p>
<p align="left"><strong>When I complete an application, how will my information be used?</strong></p>
<p align="left">Your information will only be used to connect you with a mentor or Veteran and to communicate Boots to Shoes program updates.</p>
<p align="left"><strong>How can I find out where the next event will be held?</strong></p>
<p align="left">Please call us or contact us by email at <a href="mailto:staff@bootstoshoes.org">staff@bootstoshoes.org</a> </p>
<p align="left"> <strong>Where do your volunteers (mentors and others) come from?</strong></p>
<p align="left">Here are some examples of organizations where we have presented our program and engaged volunteers:</p>
<p align="left">• American Society for Training and Development – Puget Sound</p>
<p align="left">• CBRE - Bellevue, WA</p>
<p align="left">• Columbia Bank – Tacoma, WA</p>
<p align="left">• Corsair Engineering – Kirkland, WA</p>
<p align="left">• Lake Washington SHRM – Bellevue, WA</p>
<p align="left">• Microsoft – Redmond, WA</p>
<p align="left">• Olympia Society of Human Resource Management (SHRM) – Lacey, WA</p>
<p align="left">• South Puget Sound SHRM – Tacoma, WA</p>
<p align="left">• Starbucks – Seattle, WA</p>
<p align="left">• Seattle Kiwanis – Seattle, WA</p>
<p align="left">• Target – Lacey, WA</p>
<p align="left">• The Boeing Company – Everett, WA</p>
<p align="left">• United States Marine Corp Support Group</p>
<p align="left">• Volt – Redmond, WA</p>
<p align="left">• Weyerhaeuser – Federal Way, WA</p>
&nbsp;', 'FAQs', '', 'inherit', 'open', 'open', '', '339-revision-v1', '', '', '2014-10-04 21:32:35', '2014-10-04 21:32:35', '', 339, 'http://bootstoshoes2014.azurewebsites.net/339-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7651, 1, '2014-10-04 21:45:10', '2014-10-04 21:45:10', '', 'Cascade Running Club', '', 'inherit', 'open', 'open', '', '5701-autosave-v1', '', '', '2014-10-04 21:45:10', '2014-10-04 21:45:10', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/5701-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7661, 1, '2014-10-04 21:33:48', '2014-10-04 21:33:48', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through CamoZCommerce</strong>
<h2><em>"Interview savvy" - 4 hours</em></h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2><em>"Mentor savvy" - 3 hours</em></h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search. It provides background on the tools for a 21st century job search, effective mentoring competencies, and BTS protocols for mentors.

<strong>Currently available through the BTS office and location in Pierce and Thurston counties.</strong>
<h2><em><strong>"Community outreach" - 1.5 hours</strong></em></h2>
This presentation provides education and awareness to the business and professional communities on the hurdles facing current generation veterans seeking employment.', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:33:48', '2014-10-04 21:33:48', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7671, 1, '2014-10-04 21:35:43', '2014-10-04 21:35:43', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through CamoZCommerce</strong>
<h2><em>"Interview savvy" - 4 hours</em></h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2><em>"Mentor savvy" - 3 hours</em></h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search. It provides background on the tools for a 21st century job search, effective mentoring competencies, and BTS protocols for mentors.

<strong>Currently available through the BTS office and location in Pierce and Thurston counties.</strong>
<h2><em><strong>"Community outreach" - 1.5 hours</strong></em></h2>
This presentation provides education and awareness to the business and professional communities on the hurdles facing current generation veterans seeking employment; And adds understanding and increased appreciation for the skills and capabilities of these thoroughly trained and motivated veteran job seekers.

<strong>Currently available upon request</strong>', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 21:35:43', '2014-10-04 21:35:43', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7681, 1, '2014-10-04 21:45:29', '2014-10-04 21:45:29', '', 'cascaderunning-club', '', 'inherit', 'open', 'open', '', 'cascaderunning-club', '', '', '2014-10-04 21:45:29', '2014-10-04 21:45:29', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/cascaderunning-club.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (7691, 1, '2014-10-04 21:45:57', '2014-10-04 21:45:57', '<a href="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/cascaderunning-club.png"><img class="size-medium wp-image-7681 alignleft" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/cascaderunning-club.png" alt="cascaderunning-club" width="233" height="45" /></a>', 'Cascade Running Club', '', 'inherit', 'open', 'open', '', '5701-revision-v1', '', '', '2014-10-04 21:45:57', '2014-10-04 21:45:57', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/5701-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7701, 1, '2014-10-04 21:47:24', '2014-10-04 21:47:24', '<img class="alignnone wp-image-7681 size-thumbnail" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/cascaderunning-club-150x45.png" alt="cascaderunning-club" width="150" height="45" />', 'Cascade Running Club', '', 'inherit', 'open', 'open', '', '5701-revision-v1', '', '', '2014-10-04 21:47:24', '2014-10-04 21:47:24', '', 5701, 'http://bootstoshoes2014.azurewebsites.net/5701-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7711, 1, '2014-10-04 21:47:28', '2014-10-04 21:47:28', '<h4>What will a mentor do for me? Why do I need a mentor?</h4>
A BTS trained mentor will meet one-on-one with you and will challenge and inspire you to do your best on your job search, provide insight into how to navigate the civilian job search world and encourage you to explore work opportunities in areas you hadn\'t considered. A BTS mentor may provide practical information regarding their career profession, entry requirements, opportunities for advancement and employment outlook.
<h4>As a veteran, how do I know a mentor will be a good match for me?</h4>
Veterans and mentors are matched basedhh on location and career interest or specialty. Of course, we recognize that people don\'t automatically "click" and if that is the case for either person, let us know and we will arrange a reassignment.
<h4>How much do your services cost?</h4>
Our services are provided at no cost.
<h4><span style="font-size: 1em; line-height: 1.5em;">What do you mean by "greater Puget Sound area"?</span></h4>
Greater Puget Sound refers to west of the Cascade Mountains, north as far as Whidbey Island and South to Olympia.
<h4>Are there any BTS mentors outside of the Puget Sound area?</h4>
No, however, prior to leaving the area active duty military or veterans may apply and be assigned to a Puget Sound mentor. Veterans relocating to Puget Sound may apply upon their return.
<h4>Where do you get volunteers? How do you recruit mentors?</h4>
We frequently make presentations at area professional associations, community groups and businesses.  Our volunteers reflect employees from many companies and disciplines in the Puget Sound region including Information Technology, Logistics, Human Resources, Finance, and Business Management.
<h4>I don\'t have time to be a mentor, can I be supportive in some other way?</h4>
Of course! You can invite Boots to Shoes to present program information to your company or professional association.  Donations are always welcome.
<h4>How could my company get involved?</h4>
Boots to Shoes would be happy to come to your company and present information on the program. We are excited about organizations making this volunteer opportunity available to their employees.

You may request BTS be added to your Company\'s donation match program.

Your company may sponsor BTS activities and Veteran Education.', 'FAQ\'s', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-04 21:47:28', '2014-10-04 21:47:28', '', 38, 'http://bootstoshoes2014.azurewebsites.net/38-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7721, 1, '2014-10-04 21:48:53', '2014-10-04 21:48:53', '<img class="alignnone size-full wp-image-22" src="http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2013/12/pacificcont1.png" alt="pacificcont" width="216" height="75" />', 'Pacific Continental', '', 'inherit', 'open', 'open', '', '6841-revision-v1', '', '', '2014-10-04 21:48:53', '2014-10-04 21:48:53', '', 6841, 'http://bootstoshoes2014.azurewebsites.net/6841-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7731, 1, '2014-10-04 21:56:19', '2014-10-04 21:56:19', '<blockquote>” My mentor\'s”

– USN Veteran</blockquote>', 'USN-Veteran', '', 'inherit', 'open', 'open', '', '6821-autosave-v1', '', '', '2014-10-04 21:56:19', '2014-10-04 21:56:19', '', 6821, 'http://bootstoshoes2014.azurewebsites.net/6821-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7741, 1, '2014-10-04 21:57:04', '2014-10-04 21:57:04', '<blockquote>”<em>My mentor\'s advice and guidance from job search to practicing interview questions has been invaluable. She has really helped me stay on track and keep focused. I couldn’t have asked for a better mentor.”</em>

– USN Veteran</blockquote>', 'USN-Veteran', '', 'inherit', 'open', 'open', '', '6821-revision-v1', '', '', '2014-10-04 21:57:04', '2014-10-04 21:57:04', '', 6821, 'http://bootstoshoes2014.azurewebsites.net/6821-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7751, 1, '2014-10-04 21:57:25', '2014-10-04 21:57:25', '', 'blurred_lines', '', 'inherit', 'open', 'open', '', 'blurred_lines', '', '', '2014-10-04 21:57:25', '2014-10-04 21:57:25', '', 0, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/blurred_lines.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (7761, 1, '2014-10-04 21:58:21', '2014-10-04 21:58:21', '<blockquote><em>"I am pleased to report that was he a great mentor, and I ended up getting the job I wanted. He was very good at keeping me focused and making forward progress. I feel lucky to have had his experience and knowledge to guide me. If he chooses to mentor again....I recommend him highly.” </em>

- USN Veteran</blockquote>', 'USN-Veteran-2', '', 'inherit', 'open', 'open', '', '6791-autosave-v1', '', '', '2014-10-04 21:58:21', '2014-10-04 21:58:21', '', 6791, 'http://bootstoshoes2014.azurewebsites.net/6791-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7771, 1, '2014-10-04 21:58:23', '2014-10-04 21:58:23', '<blockquote><em>"I am pleased to report that was he a great mentor, and I ended up getting the job I wanted. He was very good at keeping me focused and making forward progress. I feel lucky to have had his experience and knowledge to guide me. If he chooses to mentor again....I recommend him highly.” </em>

- USN Veteran</blockquote>', 'USN-Veteran-2', '', 'inherit', 'open', 'open', '', '6791-revision-v1', '', '', '2014-10-04 21:58:23', '2014-10-04 21:58:23', '', 6791, 'http://bootstoshoes2014.azurewebsites.net/6791-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7781, 1, '2014-10-04 21:59:17', '2014-10-04 21:59:17', '<blockquote><em>"My mentor had his co-workers interview me. The practice gave me confidence at my real interview and I got the job! Thank you, Boots to Shoes. "</em>

- USA Veteran</blockquote>', 'USA-Veteran', '', 'publish', 'open', 'open', '', 'usa-veteran', '', '', '2014-10-04 21:59:17', '2014-10-04 21:59:17', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=7781', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7791, 1, '2014-10-04 21:59:17', '2014-10-04 21:59:17', '<blockquote><em>"My mentor had his co-workers interview me. The practice gave me confidence at my real interview and I got the job! Thank you, Boots to Shoes. "</em>

- USA Veteran</blockquote>', 'USA-Veteran', '', 'inherit', 'open', 'open', '', '7781-revision-v1', '', '', '2014-10-04 21:59:17', '2014-10-04 21:59:17', '', 7781, 'http://bootstoshoes2014.azurewebsites.net/7781-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7801, 1, '2014-10-04 22:00:04', '2014-10-04 22:00:04', '<blockquote><em>"I have a job now because of BTS advice. It made the difference."</em>

- USMC Veteran</blockquote>', 'USMC-Veteran', '', 'publish', 'open', 'open', '', 'usmc-veteran', '', '', '2014-10-04 22:00:04', '2014-10-04 22:00:04', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=7801', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7811, 1, '2014-10-04 21:59:54', '2014-10-04 21:59:54', '<em>Imagine this scenario: A transitioning veteran submits a resume on line reflecting his military leadership skills and commendations. Not only does he not receive any interviews, other than an electronic “We have received your application,” he receives no personal acknowledgement at all.</em>

<em>Or this scenario: Pursuing an opportunity with a “veteran-friendly” employer, a veteran is one of 3 candidates to interview for a single position. One candidate previously worked for the employer, and one worked for the employer’s competition. The veteran candidate has relevant experience however he is not prepared to speak of his accomplishments in their civilian terminology.</em>

Veterans, new to industry, find themselves in these situations despite their leadership skills and significant levels of experience and responsibility. A Veterans’ Employment Challenges study reported that 66% of veterans said finding a job is the greatest challenge in transitioning to civilian life. BTS mentors provide a veteran with insight into the language of civilian professions, encouragement in developing a job search plan, a sounding board and checkpoint for progress.
A mentor’s role includes providing an understanding of
• civilian job language, for example the role of a human resources professional in private industry differs from a military human resources role,
• employment sources,
• professional networking protocol (e.g. how to follow up with contacts made at a networking event),
• job search planning verses reacting to each on-line job posting, and
• encouragement throughout the process.
A mentor assists a veteran as they translate military skills and accomplishments into civilian terms, define employment objectives, and offer practical advice about how and where to network as their job search gets underway. Finally, they may coach veterans on effective job interviewing, building confidence and success.', 'Volunteer', '', 'inherit', 'open', 'open', '', '130-revision-v1', '', '', '2014-10-04 21:59:54', '2014-10-04 21:59:54', '', 130, 'http://bootstoshoes2014.azurewebsites.net/130-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7821, 1, '2014-10-04 22:00:04', '2014-10-04 22:00:04', '<blockquote><em>"I have a job now because of BTS advice. It made the difference."</em>

- USMC Veteran</blockquote>', 'USMC-Veteran', '', 'inherit', 'open', 'open', '', '7801-revision-v1', '', '', '2014-10-04 22:00:04', '2014-10-04 22:00:04', '', 7801, 'http://bootstoshoes2014.azurewebsites.net/7801-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7831, 1, '2014-10-04 22:00:45', '2014-10-04 22:00:45', '<blockquote><em>"Having a Boots to Shoes mentor is the best thing that has ever happened to me."</em>

- USA Veteran, who sent 6 more to BTS for mentors.</blockquote>', 'USA-Veteran-2', '', 'publish', 'open', 'open', '', 'usa-veteran-2', '', '', '2014-10-04 22:00:45', '2014-10-04 22:00:45', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=7831', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7841, 1, '2014-10-04 22:00:45', '2014-10-04 22:00:45', '<blockquote><em>"Having a Boots to Shoes mentor is the best thing that has ever happened to me."</em>

- USA Veteran, who sent 6 more to BTS for mentors.</blockquote>', 'USA-Veteran-2', '', 'inherit', 'open', 'open', '', '7831-revision-v1', '', '', '2014-10-04 22:00:45', '2014-10-04 22:00:45', '', 7831, 'http://bootstoshoes2014.azurewebsites.net/7831-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7851, 1, '2014-10-04 22:01:42', '2014-10-04 22:01:42', '<blockquote><em>“I just thought I\'d give you an update now that I\'ve interviewed with Microsoft.  It went amazingly well, I got three offers from different departments within Microsoft and just accepted a junior Software Development Engineer job with Microsoft Office! I just wanted to thank you for setting me up with my mentor, his expertise and professionalism were instrumental to my success during my interviews.  The quality of mentor this program provided cannot be overstated, and once I get my legs under me at Microsoft, I am strongly considering volunteering myself.  Thanks again, both for what you\'ve done for me and what you are continuing to do for veterans.” </em>

<em>- USA Veteran</em></blockquote>', 'USA-Veteran-3', '', 'publish', 'open', 'open', '', 'usa-veteran-3', '', '', '2014-10-04 22:01:42', '2014-10-04 22:01:42', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=7851', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7861, 1, '2014-10-04 22:01:42', '2014-10-04 22:01:42', '<blockquote><em>“I just thought I\'d give you an update now that I\'ve interviewed with Microsoft.  It went amazingly well, I got three offers from different departments within Microsoft and just accepted a junior Software Development Engineer job with Microsoft Office! I just wanted to thank you for setting me up with my mentor, his expertise and professionalism were instrumental to my success during my interviews.  The quality of mentor this program provided cannot be overstated, and once I get my legs under me at Microsoft, I am strongly considering volunteering myself.  Thanks again, both for what you\'ve done for me and what you are continuing to do for veterans.” </em>

<em>- USA Veteran</em></blockquote>', 'USA-Veteran-3', '', 'inherit', 'open', 'open', '', '7851-revision-v1', '', '', '2014-10-04 22:01:42', '2014-10-04 22:01:42', '', 7851, 'http://bootstoshoes2014.azurewebsites.net/7851-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7871, 1, '2014-10-04 22:03:32', '2014-10-04 22:03:32', '<blockquote>“Your organization definitely made a huge impact on my ability to find a job and ease the transition process over the past couple of months. My mentor did a great job helping me figure out what skills I was strong and weak in, tweaking my resume, and also provided me with a personality test that ended up confirming my gut feeling of where I want to see myself in the years to come.

Thank you again for all your help and I\'ll keep you posted as I progress into this new world of "civilian life".

- USA Veteran</blockquote>', 'USA-Veteran-4', '', 'publish', 'open', 'open', '', 'usa-veteran-4', '', '', '2014-10-04 22:04:02', '2014-10-04 22:04:02', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?post_type=testimonial&#038;p=7871', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7881, 1, '2014-10-04 22:03:32', '2014-10-04 22:03:32', '<blockquote>“Your organization definitely made a huge impact on my ability to find a job and ease the transition process over the past couple of months. My mentor did a great job helping me figure out what skills I was strong and weak in, tweaking my resume, and also provided me with a personality test that ended up confirming my gut feeling of where I want to see myself in the years to come.

Thank you again for all your help and I\'ll keep you posted as I progress into this new world of "civilian life".

- USA Veteran</blockquote>', 'USA-Veteran-', '', 'inherit', 'open', 'open', '', '7871-revision-v1', '', '', '2014-10-04 22:03:32', '2014-10-04 22:03:32', '', 7871, 'http://bootstoshoes2014.azurewebsites.net/7871-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7891, 1, '2014-10-04 22:04:02', '2014-10-04 22:04:02', '<blockquote>“Your organization definitely made a huge impact on my ability to find a job and ease the transition process over the past couple of months. My mentor did a great job helping me figure out what skills I was strong and weak in, tweaking my resume, and also provided me with a personality test that ended up confirming my gut feeling of where I want to see myself in the years to come.

Thank you again for all your help and I\'ll keep you posted as I progress into this new world of "civilian life".

- USA Veteran</blockquote>', 'USA-Veteran-4', '', 'inherit', 'open', 'open', '', '7871-revision-v1', '', '', '2014-10-04 22:04:02', '2014-10-04 22:04:02', '', 7871, 'http://bootstoshoes2014.azurewebsites.net/7871-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7901, 1, '2014-10-04 22:05:24', '0000-00-00 00:00:00', '', 'Volunteer', '', 'draft', 'open', 'open', '', '', '', '', '2014-10-04 22:05:24', '2014-10-04 22:05:24', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=7901', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7911, 1, '2014-10-04 22:09:13', '2014-10-04 22:09:13', '<strong>Tricia Stromberg, President/Founder                         board@bootstoshoes.org</strong>
Ms. Stromberg is a retired Boeing Engineer and Associate Technical Fellow. Her engineering career centered on military aircraft systems and spanned all services; from the Army Cobra Helicopter to the Air Force F-22. Also, 20 some years as a Marine Corps spouse brought her into close contact with the everyday challenges faced by families whose military member is sent into harm’s way. Throughout her career, Ms. Stromberg has interviewed, hired, and managed and mentored numerous individuals in career transition. She has over 14 years serving on non-profit\' Boards of Directors including 7 years as President of Seattle’s Spectrum Dance Theater and now serving as the Boots to Shoes Foundation President since 2010.
</hr>
<strong>Ed Doyne, Vice President                                           board@bootstoshoes.org</strong> Mr. Doyne is a technology consultant with 20 years’ experience in creating and operating telecom, data center, and co-location facilities. He served 20 years as a US Marine officer, including combat service in Vietnam, receiving a Purple Heart. He is currently a board member of the Blue and Gold Foundation, NROTC University of Washington. Mr. Doyne effectively executed a successful transition to civilian life and through his business has interviewed, hired, and mentored numerous individuals. He continues to assist individuals with job search planning and interview skills at BTS outreach events. He additionally volunteers with the BlinkNow non-profit organization supporting their orphanage and school in Nepal.
</hr>
<strong>Russ Stromberg, Secretary/Treasurer/Founder    board@bootstoshoes.org</strong>
Mr. Stromberg is a retired U.S. Marine Corps officer, Viet Nam veteran and graduate of the U.S. Naval Academy. While in the Marine Corps, he served two tours as a test pilot and was the Commanding Officer of two AV-8B squadrons. After his retirement from the Marines in 1990, he moved to Washington state. Mr. Stromberg founded his first of several successful businesses, all of which are primarily focused on supporting a variety of military programs to include the Joint Strike Fighter Program, several unmanned aerial vehicle programs and a variety of training and logistics support programs. Mr. Stromberg has hired, managed, coached, and mentored employees and job seekers. Mr. Stromberg and his wife\'s philantropy has benefited numerous Puget Sound area non-profit organizations.
</hr>
<strong>Rick Rezabek, Board Member/Founder               board@bootstoshoes.org</strong>
Mr. Rezabek is an Aerospace Engineer with over 25 years experience in developing and delivering modern aerospace products and programs. Mr. Rezabek was the Chief Engineer of Lockheed\'s Joint Strike Fighter X-35 Demonstration Aircraft. As a program manager in the highly technical world of aerospace engineering, Mr. Rezabek has provided career guidance to many team members. He is currently working with Unmanned Aerial Vehicle (UAV) products across several manufacturers. Mr. Rezabek partnered with Mr. Stromberg to create a successful business that was able to offer many jobs to veterans. He has served on the Boots to Shoes Board of Directors since 2010.
</hr>
<strong>Mike Martinez, Board Member                               board@bootstoshoes.org</strong>
Mr. Martinez is a Veteran of the U.S. Marine Corps, and an operations &amp; logistics program manager with Starbucks, working nationally and internationally, with both wholesale and retail infrastructure. He has long served the Puget Sound community as a Blue &amp; Gold Officer and volunteer mentor for high school students seeking admission to the United States Naval Academy. Mr. Martinez earned his Master’s degree at Seattle University and his undergraduate degree from USNA. Having grown up in the Seattle area, Mr. Martinez continues to make it his home with his wife and three children. He is also active in coaching youth sports and serving on school committees. Mr. Martinez joined the Board in 2011 and supports mentor and veteran outreach activities.
</hr>
<strong>Tori Ehlert, Board Member                                       board@bootstoshoes.org</strong>
Ms. Ehlert was a military spouse for over 20 years and served as ombudsman for many military families separated from spouses who were serving in areas of conflict. Ms. Ehlert dedicated herself to the health and welfare of those families as well as raising two daughters while her own spouse was away on extended duty. She joined the BTS Board of Directors in 2011. In addition she volunteers with the Motley Zoo Animal Rescue, and serves on Redmond High School Cheer Association Board. Ms. Ehlert can frequently be seen at Military Job Fairs assisting transitioning soldiers and veterans with their mentor applications.
</hr>
<strong>Mike McGuire                                                            board@bootstoshoes.org</strong>
Mike McGuire is a retired Army officer, with 26 years active service. He had overseas assignments in Thailand, Turkey and Belgium and held a number of key positions in the US, such as a Financial Comptroller in US Army Special Operations Command, and the Comptroller of the 7th Infantry Division. Retiring to the Tacoma area, he had a second career with Ernst &amp; Young LLP, retiring as the Associate Director of Finance. He is now with Northrop Grumman working the Global Combat Support System-Army. In addition to assisting with mentor and veteran outreach with BTS since 2011, Mr. McGuire continues to mentor veterans, which he describes as a “labor of love” because it is a way of supporting America’s Veterans. Mike enjoys time with his wife and family; 3 of their 4 children have served in the active Army.', 'Board and Staff', '', 'inherit', 'open', 'open', '', '119-revision-v1', '', '', '2014-10-04 22:09:13', '2014-10-04 22:09:13', '', 119, 'http://bootstoshoes2014.azurewebsites.net/119-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7921, 1, '2014-10-04 22:11:32', '2014-10-04 22:11:32', '', 'Volunteer', '', 'publish', 'open', 'open', '', 'volunteer', '', '', '2014-10-04 22:12:43', '2014-10-04 22:12:43', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7921', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7931, 1, '2014-10-04 22:10:49', '2014-10-04 22:10:49', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-10-04 22:10:49', '2014-10-04 22:10:49', '', 1, 'http://bootstoshoes2014.azurewebsites.net/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7941, 1, '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', ' ', '', 'inherit', 'open', 'open', '', '220-revision-v1', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 220, 'http://bootstoshoes2014.azurewebsites.net/220-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7951, 1, '2014-10-04 22:10:50', '2014-10-04 22:10:50', '<a href="http://temp.bootstoshoes.org/wp-content/uploads/2014/03/IMG_9212.jpg"> </a>', ' ', '', 'inherit', 'open', 'open', '', '103-revision-v1', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 103, 'http://bootstoshoes2014.azurewebsites.net/103-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7961, 1, '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', ' ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-10-04 22:10:50', '2014-10-04 22:10:50', '', 154, 'http://bootstoshoes2014.azurewebsites.net/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7971, 1, '2014-10-04 22:10:51', '2014-10-04 22:10:51', '', ' ', '', 'inherit', 'open', 'open', '', '115-revision-v1', '', '', '2014-10-04 22:10:51', '2014-10-04 22:10:51', '', 115, 'http://bootstoshoes2014.azurewebsites.net/115-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7981, 1, '2014-10-04 22:10:51', '2014-10-04 22:10:51', '', ' ', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-10-04 22:10:51', '2014-10-04 22:10:51', '', 158, 'http://bootstoshoes2014.azurewebsites.net/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7991, 1, '2014-10-04 22:11:44', '2014-10-04 22:11:44', '', 'Slideshow Pic 1 - Boots', '', 'publish', 'open', 'open', '', 'slideshow-pic-1-boots', '', '', '2014-10-04 22:11:45', '2014-10-04 22:11:45', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=7991', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8001, 1, '2014-10-04 22:11:45', '2014-10-04 22:11:45', '', 'Slideshow Pic 1 - Boots', '', 'inherit', 'open', 'open', '', '7991-revision-v1', '', '', '2014-10-04 22:11:45', '2014-10-04 22:11:45', '', 7991, 'http://bootstoshoes2014.azurewebsites.net/7991-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8011, 1, '2014-10-04 01:13:02', '2014-10-04 01:13:02', '', 'Slideshow Image 2 - Career 1', '', 'publish', 'open', 'open', '', 'slideshow-image-2-career-1', '', '', '2014-10-04 23:03:32', '2014-10-04 23:03:32', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=8011', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8021, 1, '2014-10-04 22:13:02', '2014-10-04 22:13:02', '', 'Slideshow Image 2 - Career 1', '', 'inherit', 'open', 'open', '', '8011-revision-v1', '', '', '2014-10-04 22:13:02', '2014-10-04 22:13:02', '', 8011, 'http://bootstoshoes2014.azurewebsites.net/8011-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8031, 1, '2014-10-03 22:14:13', '2014-10-03 22:14:13', '', 'Slideshow Image 3 - Helicopter', '', 'publish', 'open', 'open', '', 'slideshow-image-3-helicopter', '', '', '2014-10-04 23:03:02', '2014-10-04 23:03:02', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=8031', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8041, 1, '2014-10-04 22:14:05', '2014-10-04 22:14:05', '', 'Donor Wall', '', 'inherit', 'open', 'open', '', '5481-autosave-v1', '', '', '2014-10-04 22:14:05', '2014-10-04 22:14:05', '', 5481, 'http://bootstoshoes2014.azurewebsites.net/5481-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8051, 1, '2014-10-04 22:14:13', '2014-10-04 22:14:13', '', 'Slideshow Image 3 - Helicopter', '', 'inherit', 'open', 'open', '', '8031-revision-v1', '', '', '2014-10-04 22:14:13', '2014-10-04 22:14:13', '', 8031, 'http://bootstoshoes2014.azurewebsites.net/8031-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8061, 1, '2014-10-02 22:15:15', '2014-10-02 22:15:15', '', 'Slideshow Image 4 - Career 2', '', 'publish', 'closed', 'closed', '', 'slideshow-image-4-career-2', '', '', '2014-10-04 22:50:00', '2014-10-04 22:50:00', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=8061', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8071, 1, '2014-10-04 22:15:15', '2014-10-04 22:15:15', '', 'Slideshow Image 4 - Career 2', '', 'inherit', 'open', 'open', '', '8061-revision-v1', '', '', '2014-10-04 22:15:15', '2014-10-04 22:15:15', '', 8061, 'http://bootstoshoes2014.azurewebsites.net/8061-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8081, 1, '2014-10-01 22:47:31', '2014-10-01 22:47:31', '', 'Slideshow Image 5 - Hummer', '', 'publish', 'closed', 'closed', '', 'slideshow-image-5-hummer', '', '', '2014-10-04 22:50:19', '2014-10-04 22:50:19', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?p=8081', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8091, 1, '2014-10-04 22:47:25', '2014-10-04 22:47:25', '', 'Slideshow Image 5 - Hummer', '', 'inherit', 'open', 'open', '', '8081-revision-v1', '', '', '2014-10-04 22:47:25', '2014-10-04 22:47:25', '', 8081, 'http://bootstoshoes2014.azurewebsites.net/8081-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8101, 1, '2014-10-04 23:36:16', '2014-10-04 23:36:16', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
<a href="http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf">http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf</a>
<h2>Workforce Central, Tacoma</h2>
<a href="http://www.workforce-central.org/">http://www.workforce-central.org/</a>
<h2>Employer Support of the Guard and Reserve</h2>
<a href="http://www.esgr.mil/">http://www.esgr.mil/</a>
<h2>Washington Dept. of Veterans Affairs</h2>
<a href="http://www.dva.wa.gov/">http://www.dva.wa.gov/</a>
<h2>King County Veterans Program</h2>
<a href="http://www.kingcounty.gov/socialservices/veterans.aspx">http://www.kingcounty.gov/socialservices/veterans.aspx</a>
<h2>Camo2Commerce</h2>
<a href="http://www.pacmtn.org/camo-2-commerce/">http://www.pacmtn.org/camo-2-commerce/</a>
<h2>Columbia Basin College</h2>
<a href="http://www.columbiabasin.edu/">http://www.columbiabasin.edu/</a>
<h2>Veterans Training Support Center,</h2>
&nbsp;

&nbsp;

&nbsp;
<h2></h2>
<h2></h2>
&nbsp;

&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-autosave-v1', '', '', '2014-10-04 23:36:16', '2014-10-04 23:36:16', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8111, 1, '2014-10-04 23:02:01', '2014-10-04 23:02:01', '<h3><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP)</strong></h3>', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:02:01', '2014-10-04 23:02:01', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8121, 1, '2014-10-04 23:02:42', '2014-10-04 23:02:42', '<h3><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) <a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a></strong></h3>', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:02:42', '2014-10-04 23:02:42', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8131, 1, '2014-10-04 23:04:12', '2014-10-04 23:04:12', '', 'Partners', '', 'inherit', 'open', 'open', '', '5241-revision-v1', '', '', '2014-10-04 23:04:12', '2014-10-04 23:04:12', '', 5241, 'http://bootstoshoes2014.azurewebsites.net/5241-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8141, 1, '2014-10-04 23:10:18', '2014-10-04 23:10:18', '', 'Events', '', 'publish', 'open', 'open', '', 'events-2', '', '', '2014-10-04 23:10:18', '2014-10-04 23:10:18', '', 0, 'http://bootstoshoes2014.azurewebsites.net/?page_id=8141', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8151, 1, '2014-10-04 23:09:51', '2014-10-04 23:09:51', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:09:51', '2014-10-04 23:09:51', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8161, 1, '2014-10-04 23:10:18', '2014-10-04 23:10:18', '', 'Events', '', 'inherit', 'open', 'open', '', '8141-revision-v1', '', '', '2014-10-04 23:10:18', '2014-10-04 23:10:18', '', 8141, 'http://bootstoshoes2014.azurewebsites.net/8141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8171, 1, '2014-10-04 23:17:47', '2014-10-04 23:17:47', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:17:47', '2014-10-04 23:17:47', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8181, 1, '2014-10-04 23:26:09', '2014-10-04 23:26:09', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:26:09', '2014-10-04 23:26:09', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8191, 1, '2014-10-04 23:28:05', '2014-10-04 23:28:05', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
<a href="http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf">http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf</a>
<h2>Workforce Central, Tacoma</h2>
<a href="http://www.workforce-central.org/">http://www.workforce-central.org/</a>
<h2></h2>
&nbsp;

&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:28:05', '2014-10-04 23:28:05', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8201, 1, '2014-10-04 23:32:21', '2014-10-04 23:32:21', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
<a href="http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf">http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf</a>
<h2>Workforce Central, Tacoma</h2>
<a href="http://www.workforce-central.org/">http://www.workforce-central.org/</a>
<h2>Employer Support of the Guard and Reserve</h2>
<a href="http://www.esgr.mil/">http://www.esgr.mil/</a>
<h2>Washington Dept. of Veterans Affairs</h2>
<a href="http://www.dva.wa.gov/">http://www.dva.wa.gov/</a>

&nbsp;
<h2></h2>
<h2></h2>
&nbsp;

&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:32:21', '2014-10-04 23:32:21', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8211, 1, '2014-10-04 23:35:09', '2014-10-04 23:35:09', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
<a href="http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf">http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf</a>
<h2>Workforce Central, Tacoma</h2>
<a href="http://www.workforce-central.org/">http://www.workforce-central.org/</a>
<h2>Employer Support of the Guard and Reserve</h2>
<a href="http://www.esgr.mil/">http://www.esgr.mil/</a>
<h2>Washington Dept. of Veterans Affairs</h2>
<a href="http://www.dva.wa.gov/">http://www.dva.wa.gov/</a>
<h2>King County Veterans Program</h2>
<a href="http://www.kingcounty.gov/socialservices/veterans.aspx">http://www.kingcounty.gov/socialservices/veterans.aspx</a>
<h2>Camo2Commerce</h2>
<a href="http://www.pacmtn.org/camo-2-commerce/">http://www.pacmtn.org/camo-2-commerce/</a>

&nbsp;

&nbsp;

&nbsp;
<h2></h2>
<h2></h2>
&nbsp;

&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:35:09', '2014-10-04 23:35:09', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8221, 1, '2014-10-04 23:37:09', '2014-10-04 23:37:09', '<h2><strong>Joint Base Lewis Mchord, Army Airman Career Alumni Program (AACAP) </strong></h2>
<a href="http://www.lewis-mcchord.army.mil/dhr/acap/">http://www.lewis-mcchord.army.mil/dhr/acap/</a>
<h2>Tacoma Chamber of Commerce</h2>
<a href="http://www.tacomachamber.org/">http://www.tacomachamber.org/</a>
<h2>Heroes to Hometown, Tacoma WA</h2>
<a href="http://www.waheroestohometowns.org/">http://www.waheroestohometowns.org/</a>
<h2>Hire Americas Heroes, Redmond WA</h2>
<a href="http://hireamericasheroes.org/">http://hireamericasheroes.org/</a>
<h2>Marine Support Group, Bellevue WA</h2>
<a href="http://www.wamarines.org/">http://www.wamarines.org/</a>
<h2>Marine for Life, Seattle WA</h2>
<a href="http://www.linkedin.com/groups/Marine-Life-Seattle-4973505">http://www.linkedin.com/groups/Marine-Life-Seattle-4973505</a>
<h2>Operation Good Jobs/Goodwill, Tacoma WA</h2>
<a href="https://www.goodwillwa.org/category/tacoma-goodwill-jobs/">https://www.goodwillwa.org/category/tacoma-goodwill-jobs/</a>
<h2>Pierce College Veterans Center of Excellence, Tacoma WA</h2>
<a href="http://www.pierce.ctc.edu/dist/veterans/cevss/">http://www.pierce.ctc.edu/dist/veterans/cevss/</a>
<h2>Rally Point/6, Tacoma WA</h2>
<a href="http://theunfinishedmission.org/">http://theunfinishedmission.org/</a>
<h2>Washington Sate Governors Military Transition Council</h2>
<a href="http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf">http://www.psrc.org/assets/10309/WDP20131120Present-WAMilitaryTransitionCouncil.pdf</a>
<h2>Workforce Central, Tacoma</h2>
<a href="http://www.workforce-central.org/">http://www.workforce-central.org/</a>
<h2>Employer Support of the Guard and Reserve</h2>
<a href="http://www.esgr.mil/">http://www.esgr.mil/</a>
<h2>Washington Dept. of Veterans Affairs</h2>
<a href="http://www.dva.wa.gov/">http://www.dva.wa.gov/</a>
<h2>King County Veterans Program</h2>
<a href="http://www.kingcounty.gov/socialservices/veterans.aspx">http://www.kingcounty.gov/socialservices/veterans.aspx</a>
<h2>Camo2Commerce</h2>
<a href="http://www.pacmtn.org/camo-2-commerce/">http://www.pacmtn.org/camo-2-commerce/</a>
<h2>Columbia Basin College</h2>
<a href="http://www.columbiabasin.edu/">http://www.columbiabasin.edu/</a>
<h2>Veterans Training Support Center, Edmonds WA</h2>
<a href="http://veteranstrainingsupportcenter.org/">http://veteranstrainingsupportcenter.org/</a>

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;
<h2></h2>
<h2></h2>
&nbsp;

&nbsp;
<h2></h2>
&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;', 'Network', '', 'inherit', 'open', 'open', '', '5231-revision-v1', '', '', '2014-10-04 23:37:09', '2014-10-04 23:37:09', '', 5231, 'http://bootstoshoes2014.azurewebsites.net/5231-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8231, 1, '2014-10-04 23:38:03', '2014-10-04 23:38:03', '<h2><em><strong>"Making the most of your elevator pitch" - 2 hours</strong></em></h2>
The workshop objective is to teach the participants how to develop a short introduction that highlights the career goals, applicable skills and leaves the listener with "tell me more".

<strong>Currently available through Camo2Commerce</strong>
<h2><em>"Interview savvy" - 4 hours</em></h2>
This workshop provides a deepdive and hands on practice in the art of effective interviewing, including "tell me about yourself", unspoken objections, and question candidates should ask.

<strong>Currently available through ABLM Northwest Edge</strong>
<h2><em>"Mentor savvy" - 3 hours</em></h2>
This workshop, specifically for BTS volunteers, provides an overview of the challenges facing transitioning military as they begin their new career search. It provides background on the tools for a 21st century job search, effective mentoring competencies, and BTS protocols for mentors.

<strong>Currently available through the BTS office and location in Pierce and Thurston counties.</strong>
<h2><em><strong>"Community outreach" - 1.5 hours</strong></em></h2>
This presentation provides education and awareness to the business and professional communities on the hurdles facing current generation veterans seeking employment; And adds understanding and increased appreciation for the skills and capabilities of these thoroughly trained and motivated veteran job seekers.

<strong>Currently available upon request</strong>', 'Education', '', 'inherit', 'open', 'open', '', '335-revision-v1', '', '', '2014-10-04 23:38:03', '2014-10-04 23:38:03', '', 335, 'http://bootstoshoes2014.azurewebsites.net/335-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8281, 1, '2014-10-05 00:10:57', '2014-10-05 00:10:57', '', 'Events', '', 'inherit', 'open', 'open', '', '8141-autosave-v1', '', '', '2014-10-05 00:10:57', '2014-10-05 00:10:57', '', 8141, 'http://bootstoshoes2014.azurewebsites.net/8141-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8291, 1, '2014-10-05 00:13:07', '2014-10-05 00:13:07', '', 'BTSlogo', '', 'inherit', 'open', 'open', '', 'btslogo', '', '', '2014-10-05 00:14:43', '2014-10-05 00:14:43', '', 5351, 'http://bootstoshoes2014.azurewebsites.net/wp-content/uploads/2014/10/BTSlogo.png', 0, 'attachment', 'image/png', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (35 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (103, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (115, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (154, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (158, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (220, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (222, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (222, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (237, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (328, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5131, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5141, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5151, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5191, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5281, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5321, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5331, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5341, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5501, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5561, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5571, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5581, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5611, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5641, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7311, 51, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7321, 51, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7331, 51, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7341, 51, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7431, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7921, 31, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7991, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (8011, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (8031, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (8061, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (8081, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (5 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (21, 21, 'category', '', 1, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (31, 31, 'nav_menu', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (51, 51, 'nav_menu', '', 0, 4) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (5 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (11, 'HomePageLowerTabs', 'homepagelowertabs', 0) ; 
INSERT INTO `wp_terms` VALUES (21, 'ShowInSlideShow', 'showinslideshow', 0) ; 
INSERT INTO `wp_terms` VALUES (31, 'BTS-Menu', 'bts-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (51, 'Footer Menu', 'footer-menu', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=551 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (55 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'nickname', 'BTSuser1') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (31, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (41, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (51, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (61, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (71, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (81, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (91, 1, 'wp_capabilities', 'a:14:{s:13:"administrator";b:1;s:15:"membershipadmin";b:1;s:24:"membershipadmindashboard";b:1;s:22:"membershipadminmembers";b:1;s:21:"membershipadminlevels";b:1;s:28:"membershipadminsubscriptions";b:1;s:22:"membershipadmincoupons";b:1;s:24:"membershipadminpurchases";b:1;s:29:"membershipadmincommunications";b:1;s:21:"membershipadmingroups";b:1;s:20:"membershipadminpings";b:1;s:23:"membershipadmingateways";b:1;s:22:"membershipadminoptions";b:1;s:32:"membershipadminupdatepermissions";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (101, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (111, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (121, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (122, 1, 'session_tokens', 'a:57:{s:64:"04ee488cee2abe270889d0d95a483041d837fd533b69e744d6bf03f85eb6bd6b";i:1412562795;s:64:"d4ecdbfb7c0febaca6dcc00168501c8179e79541392ba664d01763b3f139f9b7";i:1413600821;s:64:"5f573591aa2ee28b129a4519ca39d64d0b6ba93eba56893e95d331cbbcef3d18";i:1412564067;s:64:"b42a8d4ded6df2e6a2fa72572ab14a1f7376b63f72d5616eb9c3952ba6be34d2";i:1412564156;s:64:"dfd13d054101de553cc1f56506ac50aa83342ca0fe8d003d39d4d66047dfa0df";i:1412564255;s:64:"fdca1e7ad290bb37fc80fba4be0db8cbbce7c1c54a89f22dc9cb3ad696dc24bc";i:1412564445;s:64:"42476acbc6d5006338f27d30d74c61de79f43f5c36e763cdf90749e70e159295";i:1413602891;s:64:"6537607081bc7cc88cc5ec8014f1adeae83a79b96e28915cb9237b1f9a82ca06";i:1413607517;s:64:"2b4470380d020f7e78f36f08cb714d71227f06f56574dcadb5069c5c8d0786a9";i:1413649775;s:64:"3d08e991b5626c1ae730c5e827562c12b9b06e74415e561bd77d82d03726f3d0";i:1413650059;s:64:"6107bbfcf422d80f471b2258e7835af851357f26b4b4454338893904ed51e290";i:1413650856;s:64:"baf59f5b1b5820a205d7be1ffa9d80446b90451c5f2cbb6512f4721068615468";i:1413651760;s:64:"46c61978a146e2e639d8e57c4d0b7c933fcdf5279051a6e413ad2a37f7a1bc99";i:1413651774;s:64:"5ac696cc4ce2de1390261b3d397fb51ce3d808b5d13ee6b6cabe63d3e34dfe54";i:1413655903;s:64:"8314a937122392449cfa24c50318de0c648e351bb508eb1eb9f64dd3e1073b1a";i:1413660297;s:64:"d5d68e0539b26bdbca93bbd8d0c7cb5e4958ac68966038b20783c0e5cbac4869";i:1413661436;s:64:"b230f74ceafb8f2856b4951a36868ebc211c87e950c1a4b9b4d9f4ab1dc48d8f";i:1413661815;s:64:"163f2e3f55fd0bd36c29a57772667fe32d3aff7b3da8536ac3138ef519eca36f";i:1413662036;s:64:"d6019f2b30e9c8ec2036dd2e93eaa6b90df34711681e4ed59b7bfc793b5d174d";i:1413662727;s:64:"807ada62be8c42aae8579d685d577b9343e01d374eb61b61eefbaab78faa1a68";i:1413662729;s:64:"ccec0594ce878906f8397a1784dfd20f287027c32f67be093cf8cb318156a81d";i:1413663324;s:64:"fe0ec8ffa63009c30b9744f0c74594beacebf2b1321358acf8cf5dbb3a53db26";i:1413665914;s:64:"0444cee8de89f68cd1ed336132c0ef338862e17fe1582a2004195c8b8d4af130";i:1413666384;s:64:"3f5c64a579f00c46ee1596dfba0bf2ce726acd79f8b27845e0e32ca1dc8c7dff";i:1413666684;s:64:"2a5e42767f33e3ace6cb35435cddf733059f29dbf9e4be536c6630c6d5290d82";i:1413666706;s:64:"2ae2a48b4f7d363a1293f00cdbd0147619cfcd46c93fb3f76b4470ddc2fbb84e";i:1413667424;s:64:"eeb80daf9bf03b9fcc7f49dfa5ac636187fd8813b2606858585fbf7a6c15d4a5";i:1413667439;s:64:"36be86a91e7f469f01a3bd6029db8f8a0f94bdd08d5072d1438f44ef5543e762";i:1413668082;s:64:"4039cc19514e40fbde246fe32589489deae69cbdca52fdec4af498d3e1c9708d";i:1413668661;s:64:"06adcd7b9f5e15271d439de6dd12f6d83f53675f3f9079d04546b99395153345";i:1413668662;s:64:"1bdf6ab7a8ae2aba694dede3abfd497e07e2b1ba43821ee35f749536223e79cc";i:1413668681;s:64:"5aae5421fe8966ac755a213d4b8b4505cb07588313928af735c4285702bd74ba";i:1413668978;s:64:"3233306d35fca6280a53ca5ea90d6a6dbb671b63292e47ba372d310ef1698969";i:1413670177;s:64:"c5f5d240d5aa7ea17e3b59a4ae622f2711ef838daa863adb5a844b42a10261cb";i:1413670184;s:64:"fca7f7fc5d69ac9f0742c7dde1b9531cc2e7ce7b605b52968b8e2118536a76d8";i:1413670253;s:64:"7bf07a210dfbc75b09ad533ba4d0886fe3a6c74be8e45b41afcadcae1387e69d";i:1413670255;s:64:"d1870b24fd9c3c1e0e13c66bdf2cd509431773f9cb4cf598cc34e6e82bf8ffe3";i:1413670295;s:64:"7108c91406f86f335e2e228f38f84dc7310ddeb98ea92941f385d63f27abb607";i:1413670299;s:64:"5c326fe9d390d38b2e2b7515d660c855407f63c04c10e66ee42717a2c4de9257";i:1413670299;s:64:"4f6ab9487f97c6c3c2097c55481313e191053ee4d731dd70b817ae27ea6a2a1c";i:1413671908;s:64:"61c2d98b68e2875faf4b5634237a1af14b91e49a1ff744a2f5b53b4761cfdb6c";i:1413672025;s:64:"eb4d620d554122b39aa06b2db06d1df05722d8fe565645b80a6d8c5aacc6cf14";i:1413672493;s:64:"7f51b68d955177a4c4f619e350a21ada4a13bc82e97ee95bfeb3b7d17b783a29";i:1413672494;s:64:"4316e3df9ced97206b3e848c30e36e1e5170949057e9266e3ecedf3c4f2b504f";i:1413673963;s:64:"d3e30a1962e5c63222bfe60772d0beffd2eb236599cf295bed3eaf4ac5201dbb";i:1413673993;s:64:"85177d1631b29543b26916a583d7f8942817e2736c64e115be7c480cb8c69a50";i:1413674985;s:64:"40439d1ad0bd3f2c2f7a10fe60ec06e0c969b841b83e775b1226d55865c2d896";i:1413676539;s:64:"c1140ba2ae57945db3ebe1bf3c0fcac37ec631539a74e59f95a753d5d352a0bd";i:1413676574;s:64:"885c39da115c288ba42c3234a771476e4eacf6feac7c039b1e874033091c4ed0";i:1413676577;s:64:"aca06d9fe8ab9b3e57752198026045ee05ef52e5d19e08bdd7e1514d1d43374f";i:1413676580;s:64:"aef04f7c92fd71a173f61eda5375b8ad16644b6c1c6f2d4562c3b039bb9c6db2";i:1413676580;s:64:"a95cefef6d590599da16a85fd76bcf3e124ffc0b556c5848f4940f6f895d3292";i:1413676646;s:64:"0e2c907950dafe0fa884106f6be851df3904105f4909737d406108c19850a5bd";i:1413676672;s:64:"444df4d19a9a9ca6177ebe7d832199191cbcae6b74dfa838f72b12f15830d928";i:1413676704;s:64:"2135c7b42f8e515bdb0c28e95265575c479e9aaacaad1a498fd1d3fdbd1d604e";i:1413676705;s:64:"da4ff9de7f0a0dc1c1b165ea1d1c4cfcd696e431baefefd4ab6c0a260fae968a";i:1413677469;s:64:"50023e75964351b2776eeeae2381b17da07ac3559782d67ae158dd668791d629";i:1412481108;}') ; 
INSERT INTO `wp_usermeta` VALUES (131, 1, 'session_tokens', 'a:57:{s:64:"04ee488cee2abe270889d0d95a483041d837fd533b69e744d6bf03f85eb6bd6b";i:1412562795;s:64:"d4ecdbfb7c0febaca6dcc00168501c8179e79541392ba664d01763b3f139f9b7";i:1413600821;s:64:"5f573591aa2ee28b129a4519ca39d64d0b6ba93eba56893e95d331cbbcef3d18";i:1412564067;s:64:"b42a8d4ded6df2e6a2fa72572ab14a1f7376b63f72d5616eb9c3952ba6be34d2";i:1412564156;s:64:"dfd13d054101de553cc1f56506ac50aa83342ca0fe8d003d39d4d66047dfa0df";i:1412564255;s:64:"fdca1e7ad290bb37fc80fba4be0db8cbbce7c1c54a89f22dc9cb3ad696dc24bc";i:1412564445;s:64:"42476acbc6d5006338f27d30d74c61de79f43f5c36e763cdf90749e70e159295";i:1413602891;s:64:"6537607081bc7cc88cc5ec8014f1adeae83a79b96e28915cb9237b1f9a82ca06";i:1413607517;s:64:"2b4470380d020f7e78f36f08cb714d71227f06f56574dcadb5069c5c8d0786a9";i:1413649775;s:64:"3d08e991b5626c1ae730c5e827562c12b9b06e74415e561bd77d82d03726f3d0";i:1413650059;s:64:"6107bbfcf422d80f471b2258e7835af851357f26b4b4454338893904ed51e290";i:1413650856;s:64:"baf59f5b1b5820a205d7be1ffa9d80446b90451c5f2cbb6512f4721068615468";i:1413651760;s:64:"46c61978a146e2e639d8e57c4d0b7c933fcdf5279051a6e413ad2a37f7a1bc99";i:1413651774;s:64:"5ac696cc4ce2de1390261b3d397fb51ce3d808b5d13ee6b6cabe63d3e34dfe54";i:1413655903;s:64:"8314a937122392449cfa24c50318de0c648e351bb508eb1eb9f64dd3e1073b1a";i:1413660297;s:64:"d5d68e0539b26bdbca93bbd8d0c7cb5e4958ac68966038b20783c0e5cbac4869";i:1413661436;s:64:"b230f74ceafb8f2856b4951a36868ebc211c87e950c1a4b9b4d9f4ab1dc48d8f";i:1413661815;s:64:"163f2e3f55fd0bd36c29a57772667fe32d3aff7b3da8536ac3138ef519eca36f";i:1413662036;s:64:"d6019f2b30e9c8ec2036dd2e93eaa6b90df34711681e4ed59b7bfc793b5d174d";i:1413662727;s:64:"807ada62be8c42aae8579d685d577b9343e01d374eb61b61eefbaab78faa1a68";i:1413662729;s:64:"ccec0594ce878906f8397a1784dfd20f287027c32f67be093cf8cb318156a81d";i:1413663324;s:64:"fe0ec8ffa63009c30b9744f0c74594beacebf2b1321358acf8cf5dbb3a53db26";i:1413665914;s:64:"0444cee8de89f68cd1ed336132c0ef338862e17fe1582a2004195c8b8d4af130";i:1413666384;s:64:"3f5c64a579f00c46ee1596dfba0bf2ce726acd79f8b27845e0e32ca1dc8c7dff";i:1413666684;s:64:"2a5e42767f33e3ace6cb35435cddf733059f29dbf9e4be536c6630c6d5290d82";i:1413666706;s:64:"2ae2a48b4f7d363a1293f00cdbd0147619cfcd46c93fb3f76b4470ddc2fbb84e";i:1413667424;s:64:"eeb80daf9bf03b9fcc7f49dfa5ac636187fd8813b2606858585fbf7a6c15d4a5";i:1413667439;s:64:"36be86a91e7f469f01a3bd6029db8f8a0f94bdd08d5072d1438f44ef5543e762";i:1413668082;s:64:"4039cc19514e40fbde246fe32589489deae69cbdca52fdec4af498d3e1c9708d";i:1413668661;s:64:"06adcd7b9f5e15271d439de6dd12f6d83f53675f3f9079d04546b99395153345";i:1413668662;s:64:"1bdf6ab7a8ae2aba694dede3abfd497e07e2b1ba43821ee35f749536223e79cc";i:1413668681;s:64:"5aae5421fe8966ac755a213d4b8b4505cb07588313928af735c4285702bd74ba";i:1413668978;s:64:"3233306d35fca6280a53ca5ea90d6a6dbb671b63292e47ba372d310ef1698969";i:1413670177;s:64:"c5f5d240d5aa7ea17e3b59a4ae622f2711ef838daa863adb5a844b42a10261cb";i:1413670184;s:64:"fca7f7fc5d69ac9f0742c7dde1b9531cc2e7ce7b605b52968b8e2118536a76d8";i:1413670253;s:64:"7bf07a210dfbc75b09ad533ba4d0886fe3a6c74be8e45b41afcadcae1387e69d";i:1413670255;s:64:"d1870b24fd9c3c1e0e13c66bdf2cd509431773f9cb4cf598cc34e6e82bf8ffe3";i:1413670295;s:64:"7108c91406f86f335e2e228f38f84dc7310ddeb98ea92941f385d63f27abb607";i:1413670299;s:64:"5c326fe9d390d38b2e2b7515d660c855407f63c04c10e66ee42717a2c4de9257";i:1413670299;s:64:"4f6ab9487f97c6c3c2097c55481313e191053ee4d731dd70b817ae27ea6a2a1c";i:1413671908;s:64:"61c2d98b68e2875faf4b5634237a1af14b91e49a1ff744a2f5b53b4761cfdb6c";i:1413672025;s:64:"eb4d620d554122b39aa06b2db06d1df05722d8fe565645b80a6d8c5aacc6cf14";i:1413672493;s:64:"7f51b68d955177a4c4f619e350a21ada4a13bc82e97ee95bfeb3b7d17b783a29";i:1413672494;s:64:"4316e3df9ced97206b3e848c30e36e1e5170949057e9266e3ecedf3c4f2b504f";i:1413673963;s:64:"d3e30a1962e5c63222bfe60772d0beffd2eb236599cf295bed3eaf4ac5201dbb";i:1413673993;s:64:"85177d1631b29543b26916a583d7f8942817e2736c64e115be7c480cb8c69a50";i:1413674985;s:64:"40439d1ad0bd3f2c2f7a10fe60ec06e0c969b841b83e775b1226d55865c2d896";i:1413676539;s:64:"c1140ba2ae57945db3ebe1bf3c0fcac37ec631539a74e59f95a753d5d352a0bd";i:1413676574;s:64:"885c39da115c288ba42c3234a771476e4eacf6feac7c039b1e874033091c4ed0";i:1413676577;s:64:"aca06d9fe8ab9b3e57752198026045ee05ef52e5d19e08bdd7e1514d1d43374f";i:1413676580;s:64:"aef04f7c92fd71a173f61eda5375b8ad16644b6c1c6f2d4562c3b039bb9c6db2";i:1413676580;s:64:"a95cefef6d590599da16a85fd76bcf3e124ffc0b556c5848f4940f6f895d3292";i:1413676646;s:64:"0e2c907950dafe0fa884106f6be851df3904105f4909737d406108c19850a5bd";i:1413676672;s:64:"444df4d19a9a9ca6177ebe7d832199191cbcae6b74dfa838f72b12f15830d928";i:1413676704;s:64:"2135c7b42f8e515bdb0c28e95265575c479e9aaacaad1a498fd1d3fdbd1d604e";i:1413676705;s:64:"da4ff9de7f0a0dc1c1b165ea1d1c4cfcd696e431baefefd4ab6c0a260fae968a";i:1413677469;s:64:"50023e75964351b2776eeeae2381b17da07ac3559782d67ae158dd668791d629";i:1412481108;}') ; 
INSERT INTO `wp_usermeta` VALUES (132, 1, 'wp_dashboard_quick_press_last_post_id', '12') ; 
INSERT INTO `wp_usermeta` VALUES (141, 1, 'wp_dashboard_quick_press_last_post_id', '21') ; 
INSERT INTO `wp_usermeta` VALUES (151, 1, 'membership_permissions_updated', 'yes') ; 
INSERT INTO `wp_usermeta` VALUES (161, 1, 'meta-box-order_settings_page_backup', 'a:3:{s:4:"side";s:36:"metabox-authorization,metabox-status";s:6:"normal";s:16:"metabox-advanced";s:8:"advanced";s:15:"metabox-logfile";}') ; 
INSERT INTO `wp_usermeta` VALUES (171, 1, 'closedpostboxes_settings_page_backup', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (181, 1, 'metaboxhidden_settings_page_backup', 'a:1:{i:0;s:15:"metabox-logfile";}') ; 
INSERT INTO `wp_usermeta` VALUES (191, 11, 'nickname', 'lisal') ; 
INSERT INTO `wp_usermeta` VALUES (201, 11, 'first_name', 'Lisa') ; 
INSERT INTO `wp_usermeta` VALUES (211, 11, 'last_name', 'Liebfried') ; 
INSERT INTO `wp_usermeta` VALUES (221, 11, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (231, 11, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (241, 11, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (251, 11, 'admin_color', 'ectoplasm') ; 
INSERT INTO `wp_usermeta` VALUES (261, 11, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (271, 11, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (281, 11, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (291, 11, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (301, 11, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (321, 1, 'aam_contextual_menu', '1') ; 
INSERT INTO `wp_usermeta` VALUES (331, 1, 'wp_aam_activity', 'a:11:{i:1412399114;a:1:{s:6:"action";s:5:"login";}i:1412399118;a:1:{s:6:"action";s:5:"login";}i:1412439379;a:1:{s:6:"action";s:5:"login";}i:1412439639;a:1:{s:6:"action";s:5:"login";}i:1412440177;a:1:{s:6:"action";s:5:"login";}i:1412440273;a:1:{s:6:"action";s:5:"login";}i:1412440459;a:1:{s:6:"action";s:5:"login";}i:1412441256;a:1:{s:6:"action";s:5:"login";}i:1412441596;a:1:{s:6:"action";s:5:"login";}i:1412441629;a:1:{s:6:"action";s:5:"login";}i:1412441754;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (341, 1, 'nav_menu_recently_edited', '31') ; 
INSERT INTO `wp_usermeta` VALUES (351, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (361, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (371, 1, 'wp_user-settings', 'imgsize=medium&align=none&libraryContent=browse&editor=tinymce&urlbutton=none&posts_list_mode=excerpt&hidetb=1&mfold=o') ; 
INSERT INTO `wp_usermeta` VALUES (381, 1, 'wp_user-settings-time', '1412465252') ; 
INSERT INTO `wp_usermeta` VALUES (391, 1, 'closedpostboxes_page', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (401, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (411, 1, 'wp_media_library_mode', 'list') ; 
INSERT INTO `wp_usermeta` VALUES (421, 21, 'nickname', 'Boardy') ; 
INSERT INTO `wp_usermeta` VALUES (431, 21, 'first_name', 'Board') ; 
INSERT INTO `wp_usermeta` VALUES (441, 21, 'last_name', 'Member') ; 
INSERT INTO `wp_usermeta` VALUES (451, 21, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (461, 21, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (471, 21, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (481, 21, 'admin_color', 'ectoplasm') ; 
INSERT INTO `wp_usermeta` VALUES (491, 21, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (501, 21, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (511, 21, 'wp_capabilities', 'a:1:{s:20:"privatecontentviewer";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (521, 21, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (531, 21, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://bootstoshoes2014.azurewebsites.net MySQL database backup
#
# Generated: Sunday 5. October 2014 03:03 UTC
# Hostname: us-cdbr-azure-west-a.cloudapp.net
# Database: `bootstoAfOeRhDnp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_communications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_coupons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_levelmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_member_payments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_news`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_membership_rules`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_ping_history`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_pings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscription_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptionmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_subscriptions_levels`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_m_urlgroups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (3 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'BTSuser1', '$P$BAzHCMHdSv3S.OG4iLzvC9aw/mml870', 'btsuser1', 'durkinch@gmail.com', '', '2014-10-04 02:32:30', '', 0, 'BTSuser1') ; 
INSERT INTO `wp_users` VALUES (11, 'lisal', '$P$B0tx5ozFLUeFtihPIS3xkZX56wySG01', 'lisal', 'lisa_leibfried@hotmail.com', '', '2014-10-04 03:40:16', '', 0, 'Lisa Liebfried') ; 
INSERT INTO `wp_users` VALUES (21, 'Boardy', '$P$BJFM7qjGq/ujjfUAcW2AG8Z7jNYzKK1', 'boardy', 'blah@gmail.com', '', '2014-10-04 23:37:18', '', 0, 'Board Member') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

